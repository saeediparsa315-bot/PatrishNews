# راهنمای Deploy پاتریش نیوز v4

## 🎯 مشکل اصلی که این نسخه حل می‌کنه

خطای `attempt to write a readonly database` که باعث می‌شد:
- ✅ Login موفق می‌شه (چون SELECT کار می‌کنه)
- ❌ Session ذخیره نمی‌شه (چون INSERT روی دیتابیس readonly ممنوعه)
- ❌ کاربر فکر می‌کنه لاگین خرابه، دوباره به صفحه ورود برمی‌گرده

## ✅ راه‌حل‌های این نسخه

### ۱. تشخیص خودکار و fix permission
`src/lib/db.ts` حالا:
- خودکار `chmod 777` می‌کنه روی پوشه db
- خودکار `chmod 666` می‌کنه روی فایل db
- اگه مسیر اصلی قابل نوشتن نبود، `/tmp/patrish-db/` رو به‌عنوان fallback استفاده می‌کنه
- اگه هیچ جا قابل نوشتن نبود، خطای واضح می‌ده

### ۲. Endpoint جدید: `/api/diagnose`
دیاگنوستیک کامل:
- مسیر دیتابیس و permission‌ها
- تست write واقعی
- تشخیص خودکار مشکل
- پیشنهاد راه‌حل

### ۳. خطاهای واضح در login/register
اگه دیتابیس readonly باشه، دقیقاً می‌گه چیکار کنی.

### ۴. اسکریپت `fix-permissions.sh`
اجرا کنی، خودکار همه permission‌ها رو درست می‌کنه.

---

## 🚀 مراحل Deploy

### قدم ۱: آپلود فایل‌ها
فایل zip v4 رو روی هاست آپلود کن و extract کن.

### قدم ۲: fix permissions (مهم!)
```bash
chmod +x scripts/fix-permissions.sh
./scripts/fix-permissions.sh
```

اگه خطا داد:
```bash
sudo ./scripts/fix-permissions.sh
```

### قدم ۳: نصب وابستگی‌ها
```bash
npm install --legacy-peer-deps
```

### قدم ۴: راه‌اندازی دیتابیس
```bash
node scripts/setup.js
```

این اسکریپت:
- ✅ permission‌ها رو دوباره چک می‌کنه
- ✅ prisma generate اجرا می‌کنه
- ✅ prisma db push اجرا می‌کنه (ساخت table‌ها)
- ✅ ادمین پیش‌فرض می‌سازه
- ✅ تست write می‌کنه

### قدم ۵: build
```bash
npm run build
```

### قدم ۶: اجرا
```bash
NODE_ENV=production npm start
```

### قدم ۷: تست
این URL‌ها رو باز کن:

1. **`/api/diagnose`** - دیاگنوستیک کامل (مهم!)
2. **`/api/health`** - وضعیت کلی
3. **`/api/setup`** - راه‌اندازی ادمین اگه نشده

---

## 🔍 اگه بازم مشکل داشتید

### مشکل ۱: خطای "readonly database"

```bash
# اجرا کن
sudo chmod -R 777 db uploads
sudo chown -R $(whoami) db uploads

# یا اسکریپت
sudo ./scripts/fix-permissions.sh
```

بعد `/api/diagnose` رو باز کن و ببین `writeTest` چی می‌گه.

### مشکل ۲: فایل دیتابیس قابل نوشتن نیست

```bash
# اگه فایل db از قبل با root ساخته شده
sudo chown $(whoami) db/production.db
sudo chmod 666 db/production.db
```

### مشکل ۳: در Docker

اگه از Docker استفاده می‌کنی، volume mount کن:

```bash
docker run -d \
  -p 3000:3000 \
  -v $(pwd)/db:/app/db \
  -v $(pwd)/uploads:/app/uploads \
  --name patrish-news \
  patrish-news
```

قبلش مطمئن شو پوشه‌های محلی قابل نوشتن هستن:
```bash
mkdir -p db uploads
chmod -R 777 db uploads
```

### مشکل ۴: با PM2

```bash
# اگه PM2 با user دیگه‌ای اجرا می‌شه
sudo chown -R pm2user:pm2user db uploads
sudo chmod -R 755 db uploads
```

---

## 📋 چک‌لیست نهایی

قبل از تست ورود، این‌ها رو چک کن:

- [ ] `./scripts/fix-permissions.sh` اجرا شده
- [ ] `node scripts/setup.js` اجرا شده و "✅ Write دیتابیس کار می‌کنه" گفته
- [ ] `npm run build` بدون خطا اجرا شده
- [ ] `NODE_ENV=production npm start` اجرا شده
- [ ] `/api/diagnose` باز شده و `writeTest` می‌گه "✅ write کار می‌کنه"
- [ ] `/api/health` باز شده و `writeTest` می‌گه "✅ write کار می‌کنه"

اگه همه این‌ها ✅ بودن، login باید کار کنه!

---

## 🔑 اطلاعات ورود پیش‌فرض

- **ایمیل:** `admin@news24.ir`
- **رمز عبور:** `admin123`

**حتماً بعد از اولین ورود، رمز رو از `/profile` تغییر بده.**

---

## 🆕 تفاوت با v3

| تغییر | v3 | v4 |
|------|----|----|
| Permission دیتابیس | دستی | خودکار chmod |
| Fallback مسیر | نه | /tmp/patrish-db |
| Endpoint diagnose | ❌ | ✅ `/api/diagnose` |
| خطای واضح readonly | نه | ✅ |
| اسکریپت fix-permissions | ❌ | ✅ |
| Setup تست write | ❌ | ✅ |
| Docker USER | root | node |

---

## 📞 دیباگ

اگه بازم مشکل داشتی، این اطلاعات رو برام بفرست:

1. خروجی `/api/diagnose` (به صورت JSON)
2. خروجی `node scripts/setup.js`
3. خروجی `ls -la db/`
4. خروجی `whoami` و `id`

با این اطلاعات دقیقاً می‌گم مشکل کجاست.
