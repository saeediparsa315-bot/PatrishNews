# راهنمای رفع مشکلات پاتریش نیوز

## مشکلات رفع شده

### ۱. مشکل ورود (Login) و ثبت‌نام (Register)

**علت اصلی:** مسیر دیتابیس SQLite ناپایدار بود. وقتی `DATABASE_URL` به `/app/db/production.db` تنظیم شده بود (مخصوص Docker)، ولی روی هاست عادی این مسیر موجود نبود، کد قبلی به `/tmp/db/production.db` fallback می‌کرد که **در هر restart سرور گم می‌شد**!

**راه‌حل:**
- `src/lib/db.ts`: مسیر پایدار `process.cwd()/db/production.db` به‌عنوان اولویت اول
- اضافه شدن `ensureSchema()` که در runtime با `CREATE TABLE IF NOT EXISTS` تمام table‌ها رو می‌سازه
- `instrumentation.ts` در startup سرور schema رو اعمال می‌کنه

### ۲. مشکل `require('crypto')` در auth.ts

در Next.js 16 با ESM، `require()` مشکل ایجاد می‌کرد. تغییر به `import * as crypto from 'crypto'`.

### ۳. مشکل cookie سشن

`secure: false` در همه حالت‌ها تنظیم شده بود. اضافه شدن متغیر `COOKIE_SECURE` در `.env`.

### ۴. مشکل آپلود تصویر (Failed to find Server Action)

**علت اصلی:** endpoint `/api/upload` اصلاً وجود نداشت! وقتی Next.js یک درخواست FormData به یک endpoint که وجود نداره بفرسته، خطای عجیب "Failed to find Server Action" می‌ده.

**راه‌حل:**
- ساخت `/api/upload` endpoint که تصاویر رو ذخیره می‌کنه
- ساخت `/api/files/[filename]` endpoint برای سرو کردن فایل‌های آپلود شده
- نکته: در Next.js standalone، فایل‌های public/uploads در runtime سرو نمی‌شن، بنابراین همیشه از `/api/files/` استفاده می‌کنیم

### ۵. مشکل credentials در fetch‌ها

بسیاری از fetch‌های client-side `credentials: 'include'` نداشتن، که باعث می‌شد cookie سشن در بعضی هاست‌ها فرستاده نشه. همه fetch‌ها به `credentials: 'include'` ارتقا داده شدن.

### ۶. بهبود slug برای فارسی

تابع slugify قبلی فقط چند حرف فارسی رو تبدیل می‌کرد. حالا تمام حروف فارسی رو به انگلیسی تبدیل می‌کنه (مثلاً "خبر تستی" → "khabr-testy").

---

## نحوه deploy روی هاست

### روش ۱: اجرای مستقیم با Node.js (پیشنهادی)

```bash
# ۱. آپلود فایل‌ها روی هاست
# ۲. نصب وابستگی‌ها
npm install --legacy-peer-deps

# ۳. ساخت پروژه
npm run build

# ۴. اجرای سرور
NODE_ENV=production npm start
# یا
NODE_ENV=production node .next/standalone/server.js
```

### روش ۲: اجرا با Docker

```bash
docker build -t patrish-news .
docker run -p 3000:3000 -v $(pwd)/db:/app/db -v $(pwd)/uploads:/app/uploads patrish-news
```

---

## نحوه ورود به پنل مدیریت

بعد از deploy، به یکی از روش‌های زیر admin رو راه‌اندازی کنید:

### روش ۱: خودکار (پیشنهادی)
به آدرس `https://yourdomain.com/api/setup` برید.

بعد با این اطلاعات وارد بشید:
- **ایمیل:** `admin@news24.ir`
- **رمز عبور:** `admin123`

### روش ۲: ریست رمز ادمین
اگه رمز ادمین رو فراموش کردید، به آدرس `https://yourdomain.com/api/setup?resetPassword=1` برید.

---

## دیباگ سریع

### بررسی سلامت سیستم
به آدرس `https://yourdomain.com/api/health` برید.

### تست آپلود
به آدرس `https://yourdomain.com/api/upload` (با GET) برید تا وضعیت endpoint رو ببینید.

---

## نکات مهم

۱. **اولین ورود:** حتماً بعد از اولین ورود، رمز عبور ادمین رو از پنل کاربری تغییر بدید.

۲. **پوشه‌های مهم برای backup:**
- `db/` - دیتابیس SQLite
- `uploads/` - تصاویر آپلود شده
- `public/uploads/` - کپی تصاویر (در صورت وجود)

۳. **هاست‌های با reverse proxy:** `COOKIE_SECURE=false` نگه دارید.

۴. **هاست‌های با HTTPS مستقیم:** می‌تونید `COOKIE_SECURE=true` تنظیم کنید.

۵. **حداکثر حجم آپلود:** ۱۰ مگابایت (قابل تغییر در `src/app/api/upload/route.ts`).

۶. **فرمت‌های مجاز آپلود:** jpg, jpeg, png, gif, webp, svg, bmp, ico.

---

## فایل‌های تغییر یافته/اضافه شده

| فایل | تغییر |
|------|-------|
| `src/lib/db.ts` | مسیر پایدار + `ensureSchema()` |
| `src/lib/auth.ts` | `import crypto` + cookie بهتر |
| `src/lib/auto-seed.ts` | استفاده از `db.ts` مشترک |
| `src/lib/settings.ts` | اضافه شدن `ensureSchema()` |
| `src/lib/persian.ts` | بهبود `slugify` برای فارسی |
| `src/app/api/auth/login/route.ts` | auto-setup قوی‌تر |
| `src/app/api/auth/register/route.ts` | مدیریت خطای بهتر |
| `src/app/api/setup/route.ts` | اضافه شدن `?resetPassword=1` |
| `src/app/api/health/route.ts` | endpoint جدید برای دیباگ |
| **`src/app/api/upload/route.ts`** | **endpoint جدید برای آپلود تصویر** |
| **`src/app/api/files/[filename]/route.ts`** | **endpoint جدید برای سرو فایل‌ها** |
| `src/components/auth-forms.tsx` | ذخیره توکن در cookie + localStorage |
| `src/components/site-header.tsx` | پاک کردن cookie در logout |
| `src/components/article-actions.tsx` | اضافه شدن `credentials: 'include'` |
| `src/components/comments-section.tsx` | اضافه شدن `credentials: 'include'` |
| `src/components/profile-form.tsx` | اضافه شدن `credentials: 'include'` |
| `src/components/admin/article-form.tsx` | اضافه شدن `credentials: 'include'` |
| `src/components/admin/article-table.tsx` | اضافه شدن `credentials: 'include'` |
| `src/components/admin/rich-text-editor.tsx` | اضافه شدن `credentials: 'include'` |
| `src/components/admin/users-manager.tsx` | اضافه شدن `credentials: 'include'` |
| `src/components/admin/tags-manager.tsx` | اضافه شدن `credentials: 'include'` |
| `src/components/admin/categories-manager.tsx` | اضافه شدن `credentials: 'include'` |
| `src/components/admin/settings-manager.tsx` | اضافه شدن `credentials: 'include'` |
| `src/components/admin/comments-manager.tsx` | اضافه شدن `credentials: 'include'` |
| `src/components/admin/layout-editor.tsx` | اضافه شدن `credentials: 'include'` |
| `instrumentation.ts` | اعمال schema در startup |
| `next.config.ts` | رفع warning‌ها + header‌های API + body size |
| `package.json` | حذف `prisma db push` از prebuild |
| `Dockerfile` | حذف `prisma db push` در build |
| `.env`, `.env.production`, `.env.example` | مسیر پایدار + `COOKIE_SECURE` |

---

## تست نهایی انجام شده

تمام صفحات و endpoint‌های زیر تست شده و کار می‌کنند:

### صفحات عمومی
- ✅ صفحه اصلی (`/`)
- ✅ صفحه ورود (`/login`)
- ✅ صفحه ثبت‌نام (`/register`)
- ✅ صفحه تماس (`/contact`)
- ✅ صفحه درباره (`/about`)
- ✅ صفحه اخبار فوری (`/breaking`)
- ✅ صفحه ترندینگ (`/trending`)
- ✅ صفحه آخرین اخبار (`/latest`)
- ✅ صفحه جستجو (`/search`)
- ✅ صفحه ذخیره‌ها (`/bookmarks`)
- ✅ صفحه پروفایل (`/profile`)

### صفحات ادمین
- ✅ پنل ادمین (`/admin`)
- ✅ مدیریت اخبار (`/admin/articles`)
- ✅ ساخت خبر جدید (`/admin/articles/new`)
- ✅ مدیریت دسته‌ها (`/admin/categories`)
- ✅ مدیریت برچسب‌ها (`/admin/tags`)
- ✅ مدیریت نظرات (`/admin/comments`)
- ✅ مدیریت کاربران (`/admin/users`)
- ✅ تنظیمات (`/admin/settings`)
- ✅ بک‌آپ (`/admin/backup`)
- ✅ چیدمان (`/admin/layout`)
- ✅ لاگ‌ها (`/admin/audit-logs`)
- ✅ آمار (`/admin/analytics`)

### API endpoints
- ✅ `/api/health`
- ✅ `/api/setup`
- ✅ `/api/auth/login`
- ✅ `/api/auth/register`
- ✅ `/api/auth/logout`
- ✅ `/api/auth/me`
- ✅ `/api/upload` (آپلود تصویر)
- ✅ `/api/files/[filename]` (سرو فایل)
- ✅ `/api/articles` (GET, POST)
- ✅ `/api/articles/[slug]` (GET, PUT, DELETE)
- ✅ `/api/articles/layout` (PUT)
- ✅ `/api/categories` (GET, POST)
- ✅ `/api/categories/[id]` (PUT, DELETE)
- ✅ `/api/tags` (GET, POST)
- ✅ `/api/tags/[id]` (PUT, DELETE)
- ✅ `/api/comments` (GET, POST)
- ✅ `/api/comments/[id]` (PUT, DELETE)
- ✅ `/api/likes` (POST)
- ✅ `/api/bookmarks` (GET, POST)
- ✅ `/api/users` (GET, POST)
- ✅ `/api/settings` (GET, PUT)
- ✅ `/api/stats` (GET)
- ✅ `/api/stats/public` (GET)
- ✅ `/api/backup/export` (GET)
- ✅ `/api/backup/import` (POST)
- ✅ `/api/audit-logs` (GET)
