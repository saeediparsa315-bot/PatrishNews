/**
 * Auto-seed: فقط schema رو اعمال می‌کنه در startup.
 *
 * نکته مهم: این فایل ادمین نمی‌سازه!
 * ادمین فقط از طریق /api/setup ساخته می‌شه.
 * این فقط اطمینان می‌ده که table‌ها وجود دارن.
 */

import { ensureSchema } from '@/lib/db'

export async function autoSeed() {
  try {
    await ensureSchema()
    console.log('[Auto-seed] Schema اعمال شد')
  } catch (e) {
    console.error('[Auto-seed] خطا:', (e as Error).message?.substring(0, 200))
  }
}
