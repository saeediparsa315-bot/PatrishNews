import { db, ensureSchema } from '@/lib/db'

// Get site setting
export async function getSetting(key: string): Promise<string | null> {
  try {
    await ensureSchema()
    const setting = await db.siteSetting.findUnique({ where: { key } })
    return setting?.value ?? null
  } catch (e) {
    console.error('[Settings] getSetting error:', (e as Error).message?.substring(0, 150))
    return null
  }
}

export async function setSetting(key: string, value: string): Promise<void> {
  await ensureSchema()
  await db.siteSetting.upsert({
    where: { key },
    update: { value },
    create: { key, value },
  })
}

export async function getAllSettings(): Promise<Record<string, string>> {
  await ensureSchema()
  const settings = await db.siteSetting.findMany()
  return Object.fromEntries(settings.map(s => [s.key, s.value]))
}

export const DEFAULT_SETTINGS = {
  site_name: 'پاتریش نیوز',
  site_description: 'دنیای تکنولوژی، ساده و به‌روز',
  site_logo_text: 'پاتریش',
  primary_color: '#7C3AED',
  accent_color: '#06B6D4',
  footer_text: '© ۱۴۰۵ پاتریش نیوز - تمامی حقوق محفوظ است',
  social_twitter: '',
  social_telegram: 'https://t.me/PCnewsF',
  social_instagram: '',
  social_youtube: '',
  contact_email: 'info@patrishnews.ir',
  comments_enabled: 'true',
  comments_require_approval: 'true',
  default_seo_title: 'پاتریش نیوز | اخبار روز دنیا، تکنولوژی و گیم',
  default_seo_description: 'جدیدترین اخبار جهان، تکنولوژی، گیم، علم، ورزش و سرگرمی را در پاتریش نیوز دنبال کنید',
  default_seo_keywords: 'اخبار,تکنولوژی,گیم,علم,ورزش,سرگرمی,پاتریش نیوز',
}

export async function ensureDefaultSettings(): Promise<void> {
  try {
    await ensureSchema()
    for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
      const exists = await db.siteSetting.findUnique({ where: { key } })
      if (!exists) {
        try {
          await db.siteSetting.create({ data: { key, value } })
        } catch {}
      }
    }
  } catch (e) {
    console.error('[Settings] ensureDefaultSettings error:', (e as Error).message?.substring(0, 150))
  }
}

export async function logAction(
  userId: string | null,
  action: string,
  entity: string,
  entityId?: string | null,
  details?: string,
  ip?: string
): Promise<void> {
  try {
    await ensureSchema()
    await db.auditLog.create({
      data: { userId, action, entity, entityId: entityId || undefined, details, ip },
    }).catch(() => {})
  } catch {}
}
