import { PrismaClient } from '@prisma/client'
import { mkdirSync, existsSync, writeFileSync, unlinkSync, chmodSync, statSync } from 'fs'
import { resolve, dirname, join } from 'path'

/**
 * دیتابیس - نسخه ۴
 *
 * تفاوت با v3:
 * ۱. اگه مسیر اصلی readonly بود، خودکار chmod می‌کنه
 * ۲. اگه بازم نشد، مسیرهای دیگه رو امتحان می‌کنه (با priority)
 * ۳. اگه هیچ جا قابل نوشتن نبود، خطای واضح می‌ده
 *
 * اولویت مسیرها:
 * ۱. process.cwd()/db/production.db (پیشنهادی)
 * ۲. /tmp/patrish-db/production.db (آخرین راه - در restart گم می‌شه)
 */

// مسیر اصلی
const PRIMARY_DB_DIR = join(process.cwd(), 'db')
const PRIMARY_DB_FILE = join(PRIMARY_DB_DIR, 'production.db')

// مسیر fallback (در tmp)
const TMP_DB_DIR = '/tmp/patrish-db'
const TMP_DB_FILE = join(TMP_DB_DIR, 'production.db')

/**
 * تست قابل نوشتن بودن یک مسیر
 */
function isDirWritable(dir: string): boolean {
  try {
    if (!existsSync(dir)) {
      mkdirSync(dir, { recursive: true })
    }
    const testFile = join(dir, '.write_test_' + Date.now())
    writeFileSync(testFile, 'test')
    unlinkSync(testFile)
    return true
  } catch {
    return false
  }
}

/**
 * تلاش برای قابل نوشتن کردن یک مسیر
 */
function tryMakeWritable(dir: string): boolean {
  try {
    if (!existsSync(dir)) {
      mkdirSync(dir, { recursive: true })
    }

    // chmod 777 روی پوشه
    try { chmodSync(dir, 0o777) } catch {}

    // chmod روی فایل دیتابیس اگه وجود داره
    const dbFile = join(dir, 'production.db')
    if (existsSync(dbFile)) {
      try { chmodSync(dbFile, 0o666) } catch {}
    }

    // تست
    return isDirWritable(dir)
  } catch {
    return false
  }
}

/**
 * پیدا کردن مسیر قابل نوشتن برای دیتابیس
 */
function findWritableDbPath(): { url: string; dir: string; file: string; isFallback: boolean } {
  // اگه DATABASE_URL از env برای Postgres/MySQL هست، از همون استفاده کن
  const envUrl = process.env.DATABASE_URL
  if (envUrl && (envUrl.startsWith('postgres') || envUrl.startsWith('mysql'))) {
    return { url: envUrl, dir: '', file: '', isFallback: false }
  }

  // اولویت ۱: process.cwd()/db/
  if (tryMakeWritable(PRIMARY_DB_DIR)) {
    console.log('[DB] مسیر اصلی قابل نوشتن است:', PRIMARY_DB_DIR)
    return {
      url: `file:${PRIMARY_DB_FILE}`,
      dir: PRIMARY_DB_DIR,
      file: PRIMARY_DB_FILE,
      isFallback: false,
    }
  }

  console.warn('[DB] ⚠️ مسیر اصلی قابل نوشتن نیست:', PRIMARY_DB_DIR)
  console.warn('[DB] تلاش با مسیر fallback...')

  // اولویت ۲: /tmp/patrish-db/
  if (tryMakeWritable(TMP_DB_DIR)) {
    console.warn('[DB] ⚠️ استفاده از مسیر fallback:', TMP_DB_DIR)
    console.warn('[DB] ⚠️ هشدار: این مسیر در restart گم می‌شه!')
    return {
      url: `file:${TMP_DB_FILE}`,
      dir: TMP_DB_DIR,
      file: TMP_DB_FILE,
      isFallback: true,
    }
  }

  // هیچ جا قابل نوشتن نیست
  throw new Error(
    `[DB] ❌ هیچ مسیر قابل نوشتن برای دیتابیس پیدا نشد!\n` +
    `مسیرهای امتحان شده:\n` +
    `  - ${PRIMARY_DB_DIR} (readonly)\n` +
    `  - ${TMP_DB_DIR} (readonly)\n\n` +
    `راه‌حل:\n` +
    `  ۱. پوشه db رو قابل نوشتن کنید: chmod -R 777 db\n` +
    `  ۲. یا owner رو عوض کنید: chown -R $(whoami) db\n` +
    `  ۳. یا روی هاست، پوشه db رو با volume mount قابل نوشتن کنید`
  )
}

// پیدا کردن مسیر و ست کردن DATABASE_URL
const DB_INFO = findWritableDbPath()
process.env.DATABASE_URL = DB_INFO.url

// لاگ مسیر نهایی
if (DB_INFO.isFallback) {
  console.warn('[DB] ⚠️ DATABASE_URL:', DB_INFO.url, '(FALLBACK)')
} else {
  console.log('[DB] DATABASE_URL:', DB_INFO.url)
}

// Prisma Client singleton
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
  __schemaReady?: boolean
  __schemaPromise?: Promise<void>
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ['error'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db

// اطلاعاتی برای diagnostic
export const dbInfo = {
  url: DB_INFO.url,
  dir: DB_INFO.dir,
  file: DB_INFO.file,
  isFallback: DB_INFO.isFallback,
}

// SCHEMA SQL - همان v3
const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS "User" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "email" TEXT NOT NULL,
    "username" TEXT NOT NULL,
    "passwordHash" TEXT NOT NULL,
    "name" TEXT,
    "avatar" TEXT,
    "role" TEXT NOT NULL DEFAULT 'USER',
    "isBlocked" BOOLEAN NOT NULL DEFAULT false,
    "emailVerified" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS "User_email_key" ON "User"("email");
CREATE UNIQUE INDEX IF NOT EXISTS "User_username_key" ON "User"("username");

CREATE TABLE IF NOT EXISTS "Category" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "description" TEXT,
    "color" TEXT NOT NULL DEFAULT '#7C3AED',
    "icon" TEXT,
    "order" INTEGER NOT NULL DEFAULT 0,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "parentId" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("parentId") REFERENCES "Category"("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "Category_name_key" ON "Category"("name");
CREATE UNIQUE INDEX IF NOT EXISTS "Category_slug_key" ON "Category"("slug");
CREATE INDEX IF NOT EXISTS "Category_parentId_idx" ON "Category"("parentId");

CREATE TABLE IF NOT EXISTS "Tag" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "color" TEXT NOT NULL DEFAULT '#7C3AED',
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX IF NOT EXISTS "Tag_name_key" ON "Tag"("name");
CREATE UNIQUE INDEX IF NOT EXISTS "Tag_slug_key" ON "Tag"("slug");

CREATE TABLE IF NOT EXISTS "Article" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "title" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "excerpt" TEXT,
    "content" TEXT NOT NULL DEFAULT '',
    "coverImage" TEXT,
    "categoryId" TEXT NOT NULL,
    "authorId" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'DRAFT',
    "isFeatured" BOOLEAN NOT NULL DEFAULT false,
    "isBreaking" BOOLEAN NOT NULL DEFAULT false,
    "isHomepage" BOOLEAN NOT NULL DEFAULT false,
    "isMainHeadline" BOOLEAN NOT NULL DEFAULT false,
    "layoutMode" TEXT NOT NULL DEFAULT 'DEFAULT',
    "displayOrder" INTEGER NOT NULL DEFAULT 0,
    "position" INTEGER NOT NULL DEFAULT 0,
    "readingTime" INTEGER NOT NULL DEFAULT 1,
    "viewCount" INTEGER NOT NULL DEFAULT 0,
    "likeCount" INTEGER NOT NULL DEFAULT 0,
    "commentCount" INTEGER NOT NULL DEFAULT 0,
    "scheduledAt" DATETIME,
    "publishedAt" DATETIME,
    "metaTitle" TEXT,
    "metaDescription" TEXT,
    "metaKeywords" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("categoryId") REFERENCES "Category"("id"),
    FOREIGN KEY ("authorId") REFERENCES "User"("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "Article_slug_key" ON "Article"("slug");
CREATE INDEX IF NOT EXISTS "Article_categoryId_idx" ON "Article"("categoryId");
CREATE INDEX IF NOT EXISTS "Article_authorId_idx" ON "Article"("authorId");
CREATE INDEX IF NOT EXISTS "Article_status_idx" ON "Article"("status");
CREATE INDEX IF NOT EXISTS "Article_publishedAt_idx" ON "Article"("publishedAt");
CREATE INDEX IF NOT EXISTS "Article_isHomepage_idx" ON "Article"("isHomepage");
CREATE INDEX IF NOT EXISTS "Article_isMainHeadline_idx" ON "Article"("isMainHeadline");
CREATE INDEX IF NOT EXISTS "Article_isBreaking_idx" ON "Article"("isBreaking");
CREATE INDEX IF NOT EXISTS "Article_layoutMode_idx" ON "Article"("layoutMode");
CREATE INDEX IF NOT EXISTS "Article_position_idx" ON "Article"("position");

CREATE TABLE IF NOT EXISTS "_ArticleToTag" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL,
    FOREIGN KEY ("A") REFERENCES "Article"("id") ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY ("B") REFERENCES "Tag"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE INDEX IF NOT EXISTS "_ArticleToTag_B_index" ON "_ArticleToTag"("B");
CREATE INDEX IF NOT EXISTS "_ArticleToTag_A_index" ON "_ArticleToTag"("A");
CREATE UNIQUE INDEX IF NOT EXISTS "_ArticleToTag_AB_unique" ON "_ArticleToTag"("A", "B");

CREATE TABLE IF NOT EXISTS "Comment" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "content" TEXT NOT NULL,
    "articleId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "parentId" TEXT,
    "status" TEXT NOT NULL DEFAULT 'PENDING',
    "likeCount" INTEGER NOT NULL DEFAULT 0,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("articleId") REFERENCES "Article"("id") ON DELETE CASCADE,
    FOREIGN KEY ("userId") REFERENCES "User"("id"),
    FOREIGN KEY ("parentId") REFERENCES "Comment"("id") ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS "Comment_articleId_idx" ON "Comment"("articleId");
CREATE INDEX IF NOT EXISTS "Comment_userId_idx" ON "Comment"("userId");
CREATE INDEX IF NOT EXISTS "Comment_status_idx" ON "Comment"("status");
CREATE INDEX IF NOT EXISTS "Comment_parentId_idx" ON "Comment"("parentId");

CREATE TABLE IF NOT EXISTS "Like" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "articleId" TEXT,
    "commentId" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE,
    FOREIGN KEY ("articleId") REFERENCES "Article"("id") ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS "Like_userId_articleId_key" ON "Like"("userId", "articleId");
CREATE INDEX IF NOT EXISTS "Like_articleId_idx" ON "Like"("articleId");

CREATE TABLE IF NOT EXISTS "Bookmark" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "articleId" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE,
    FOREIGN KEY ("articleId") REFERENCES "Article"("id") ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS "Bookmark_userId_articleId_key" ON "Bookmark"("userId", "articleId");
CREATE INDEX IF NOT EXISTS "Bookmark_userId_idx" ON "Bookmark"("userId");

CREATE TABLE IF NOT EXISTS "NewsletterSub" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "email" TEXT NOT NULL,
    "userId" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "token" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("userId") REFERENCES "User"("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "NewsletterSub_email_key" ON "NewsletterSub"("email");
CREATE UNIQUE INDEX IF NOT EXISTS "NewsletterSub_token_key" ON "NewsletterSub"("token");

CREATE TABLE IF NOT EXISTS "Session" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "expiresAt" DATETIME NOT NULL,
    "ip" TEXT,
    "userAgent" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE
);
CREATE UNIQUE INDEX IF NOT EXISTS "Session_token_key" ON "Session"("token");
CREATE INDEX IF NOT EXISTS "Session_userId_idx" ON "Session"("userId");
CREATE INDEX IF NOT EXISTS "Session_token_idx" ON "Session"("token");

CREATE TABLE IF NOT EXISTS "AuditLog" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "userId" TEXT,
    "action" TEXT NOT NULL,
    "entity" TEXT NOT NULL,
    "entityId" TEXT,
    "details" TEXT,
    "ip" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY ("userId") REFERENCES "User"("id")
);
CREATE INDEX IF NOT EXISTS "AuditLog_userId_idx" ON "AuditLog"("userId");
CREATE INDEX IF NOT EXISTS "AuditLog_entity_idx" ON "AuditLog"("entity");

CREATE TABLE IF NOT EXISTS "SiteSetting" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "key" TEXT NOT NULL,
    "value" TEXT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS "SiteSetting_key_key" ON "SiteSetting"("key");
`

export async function ensureSchema(): Promise<void> {
  if (globalForPrisma.__schemaReady) return
  if (globalForPrisma.__schemaPromise) return globalForPrisma.__schemaPromise

  globalForPrisma.__schemaPromise = (async () => {
    try {
      // اطمینان از قابل نوشتن بودن قبل از schema
      if (DB_INFO.dir && !isDirWritable(DB_INFO.dir)) {
        // تلاش مجدد برای chmod
        if (!tryMakeWritable(DB_INFO.dir)) {
          throw new Error(`پوشه دیتابیس قابل نوشتن نیست: ${DB_INFO.dir}`)
        }
      }

      const statements = SCHEMA_SQL.split(';').map(s => s.trim()).filter(s => s.length > 0)
      for (const stmt of statements) {
        try {
          await db.$executeRawUnsafe(stmt + ';')
        } catch (e) {
          const msg = (e as Error).message
          if (!msg.includes('already exists')) {
            // اگه خطای readonly بود، خطای واضح بده
            if (msg.includes('readonly') || msg.includes('read-only')) {
              throw new Error(
                `دیتابیس readonly است! مسیر: ${DB_INFO.dir}\n` +
                `راه‌حل: chmod -R 777 ${DB_INFO.dir}`
              )
            }
            console.warn('[DB] Schema statement warning:', msg.substring(0, 150))
          }
        }
      }
      globalForPrisma.__schemaReady = true
      console.log('[DB] Schema اعمال شد - دیتابیس آماده است')
    } catch (e) {
      console.error('[DB] خطا در اعمال schema:', (e as Error).message?.substring(0, 300))
      globalForPrisma.__schemaPromise = undefined
      throw e
    }
  })()

  return globalForPrisma.__schemaPromise
}
