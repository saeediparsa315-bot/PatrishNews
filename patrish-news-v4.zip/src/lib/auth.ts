import { db, ensureSchema } from '@/lib/db'
import { cookies, headers } from 'next/headers'
import type { SessionUser, Role } from '@/lib/types'
import * as crypto from 'crypto'

const SESSION_COOKIE = 'news_session'
const AUTH_HEADER = 'x-auth-token'
const SESSION_DURATION_DAYS = 30

function generateToken(): string {
  return Array.from(crypto.getRandomValues(new Uint8Array(32)))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
}

export function hashPassword(password: string): string {
  return crypto
    .createHash('sha256')
    .update(password + 'news_salt_2024')
    .digest('hex')
}

export function verifyPassword(password: string, hash: string): boolean {
  try {
    return hashPassword(password) === hash
  } catch {
    return false
  }
}

/**
 * تعیین secure cookie
 *
 * مشکل قبلی: COOKIE_SECURE=true در همه هاست‌ها ست نمی‌شد
 * و گاهی reverse proxy باعث می‌شد secure cookie ست نشه
 *
 * راه‌حل: خودکار تشخیص بده
 * - در production همیشه secure: true (HTTPS)
 * - ولی اگه SITE_URL با http:// شروع بشه، secure: false
 */
function shouldUseSecureCookie(): boolean {
  // اگه صریحاً false شده، false
  if (process.env.COOKIE_SECURE === 'false') return false

  // اگه صریحاً true شده، true
  if (process.env.COOKIE_SECURE === 'true') return true

  // در production، HTTPS فرض می‌کنیم (هاست‌های مدرن همگی HTTPS دارن)
  if (process.env.NODE_ENV === 'production') {
    // ولی اگه SITE_URL صریحاً http:// هست، false
    const siteUrl = process.env.NEXT_PUBLIC_BASE_URL || ''
    if (siteUrl.startsWith('http://')) return false
    return true
  }

  // در development: false
  return false
}

/**
 * تعیین sameSite
 * - در production: 'lax' (سازگار با cross-site navigation)
 * - اگه iframe یا cross-origin باشه، 'none' لازمه ولی نیاز به secure داره
 */
function getSameSite(): 'lax' | 'none' {
  // برای iframe‌ها و subdomain‌ها، none بهتره ولی نیاز به secure داره
  if (process.env.COOKIE_SAMESITE === 'none' && shouldUseSecureCookie()) {
    return 'none'
  }
  return 'lax'
}

export async function createSession(userId: string): Promise<string> {
  await ensureSchema()

  const token = generateToken()
  const expiresAt = new Date()
  expiresAt.setDate(expiresAt.getDate() + SESSION_DURATION_DAYS)

  await db.session.create({
    data: {
      userId,
      token,
      expiresAt,
    },
  })

  const cookieStore = await cookies()
  const secure = shouldUseSecureCookie()
  const sameSite = getSameSite()

  console.log(`[Auth] ایجاد سشن - secure: ${secure}, sameSite: ${sameSite}`)

  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure,
    sameSite,
    path: '/',
    expires: expiresAt,
  })

  return token
}

export async function destroySession(): Promise<void> {
  const cookieStore = await cookies()
  const token = cookieStore.get(SESSION_COOKIE)?.value

  let headerToken: string | undefined = token
  if (!headerToken) {
    try {
      const headerStore = await headers()
      headerToken = headerStore.get(AUTH_HEADER) || undefined
    } catch {}
  }

  if (headerToken) {
    await db.session.deleteMany({ where: { token: headerToken } }).catch(() => {})
  }

  cookieStore.delete(SESSION_COOKIE)
}

export async function getCurrentUser(): Promise<SessionUser | null> {
  try {
    await ensureSchema()

    const cookieStore = await cookies()
    let token = cookieStore.get(SESSION_COOKIE)?.value

    // Fallback: Authorization header (برای iframe‌ها)
    if (!token) {
      try {
        const headerStore = await headers()
        token = headerStore.get(AUTH_HEADER) || undefined
      } catch {}
    }

    if (!token) return null

    const session = await db.session.findUnique({
      where: { token },
      include: {
        user: {
          select: {
            id: true,
            email: true,
            username: true,
            name: true,
            avatar: true,
            role: true,
            isBlocked: true,
          },
        },
      },
    })

    if (!session) return null
    if (session.expiresAt < new Date()) {
      await db.session.delete({ where: { id: session.id } }).catch(() => {})
      return null
    }
    if (session.user.isBlocked) return null

    return {
      id: session.user.id,
      email: session.user.email,
      username: session.user.username,
      name: session.user.name,
      avatar: session.user.avatar,
      role: session.user.role as Role,
    }
  } catch (e) {
    console.error('[Auth] getCurrentUser error:', (e as Error).message?.substring(0, 200))
    return null
  }
}

export async function requireAuth(): Promise<SessionUser> {
  const user = await getCurrentUser()
  if (!user) throw new Error('UNAUTHORIZED')
  return user
}

export async function requireAdmin(): Promise<SessionUser> {
  const user = await requireAuth()
  if (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN') {
    throw new Error('FORBIDDEN')
  }
  return user
}

export async function requireSuperAdmin(): Promise<SessionUser> {
  const user = await requireAuth()
  if (user.role !== 'SUPER_ADMIN') throw new Error('FORBIDDEN')
  return user
}

export function canPostNews(role: Role): boolean {
  return role === 'SUPER_ADMIN'
}

export function canManageUsers(role: Role): boolean {
  return role === 'SUPER_ADMIN'
}

export function canModerateComments(role: Role): boolean {
  return role === 'SUPER_ADMIN' || role === 'ADMIN'
}

export { AUTH_HEADER, SESSION_COOKIE }
