// Global app types
export type Role = 'SUPER_ADMIN' | 'ADMIN' | 'USER'

export interface SessionUser {
  id: string
  email: string
  username: string
  name: string | null
  avatar: string | null
  role: Role
}

export interface ApiResponse<T = unknown> {
  success: boolean
  data?: T
  error?: string
  message?: string
}

export interface ArticleWithRelations {
  id: string
  title: string
  slug: string
  excerpt: string | null
  content: string
  coverImage: string | null
  categoryId: string
  authorId: string
  status: string
  isFeatured: boolean
  isBreaking: boolean
  isHomepage: boolean
  isMainHeadline: boolean
  layoutMode: string       // DEFAULT | MANUAL
  displayOrder: number
  position: number         // 0-7 (0 = بدون موقعیت)
  readingTime: number
  viewCount: number
  likeCount: number
  commentCount: number
  scheduledAt: Date | null
  publishedAt: Date | null
  metaTitle: string | null
  metaDescription: string | null
  metaKeywords: string | null
  createdAt: Date
  updatedAt: Date
  category?: {
    id: string
    name: string
    slug: string
    color: string
    icon: string | null
  } | null
  author?: {
    id: string
    username: string
    name: string | null
    avatar: string | null
  } | null
  tags?: { id: string; name: string; slug: string; color: string }[]
  _count?: {
    comments: number
    likes: number
    bookmarks: number
  }
}

export const CATEGORY_ICONS = [
  { value: 'Globe', label: 'جهان' },
  { value: 'Cpu', label: 'تکنولوژی' },
  { value: 'Gamepad2', label: 'گیم' },
  { value: 'Clapperboard', label: 'سرگرمی' },
  { value: 'FlaskConical', label: 'علمی' },
  { value: 'Trophy', label: 'ورزشی' },
  { value: 'Bitcoin', label: 'اقتصاد' },
  { value: 'HeartPulse', label: 'سلامت' },
  { value: 'Rocket', label: 'فضایی' },
  { value: 'Newspaper', label: 'عمومی' },
]

export const CATEGORY_COLORS = [
  '#7C3AED', // violet
  '#06B6D4', // cyan
  '#F43F5E', // rose
  '#F59E0B', // amber
  '#10B981', // emerald
  '#3B82F6', // blue
  '#EC4899', // pink
  '#8B5CF6', // purple
  '#14B8A6', // teal
  '#F97316', // orange
]
