// Persian utility functions

const persianMonths = [
  'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
  'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'
]

const persianDays = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه']

// Convert English digits to Persian
export function toPersianDigits(input: string | number): string {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹']
  return String(input).replace(/\d/g, d => persianDigits[parseInt(d)])
}

// Convert Persian/Arabic digits to English
export function toEnglishDigits(input: string): string {
  return input
    .replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
}

// Format date to Persian (Jalali) - approximate calculation
export function formatPersianDate(date: Date | string): string {
  const d = new Date(date)
  const jalali = gregorianToJalali(d.getFullYear(), d.getMonth() + 1, d.getDate())

  const dayName = persianDays[d.getDay()]
  return `${dayName} ${toPersianDigits(jalali[2])} ${persianMonths[jalali[1] - 1]} ${toPersianDigits(jalali[0])}`
}

// Format date to short Persian format
export function formatPersianShort(date: Date | string): string {
  const d = new Date(date)
  const jalali = gregorianToJalali(d.getFullYear(), d.getMonth() + 1, d.getDate())
  return `${toPersianDigits(jalali[2])} ${persianMonths[jalali[1] - 1]} ${toPersianDigits(jalali[0])}`
}

// Format relative time (e.g., "۲ ساعت پیش")
export function formatRelativeTime(date: Date | string): string {
  const d = new Date(date)
  const now = new Date()
  const diffMs = now.getTime() - d.getTime()
  const diffSec = Math.floor(diffMs / 1000)
  const diffMin = Math.floor(diffSec / 60)
  const diffHour = Math.floor(diffMin / 60)
  const diffDay = Math.floor(diffHour / 24)
  const diffWeek = Math.floor(diffDay / 7)
  const diffMonth = Math.floor(diffDay / 30)

  if (diffSec < 60) return 'همین حالا'
  if (diffMin < 60) return `${toPersianDigits(diffMin)} دقیقه پیش`
  if (diffHour < 24) return `${toPersianDigits(diffHour)} ساعت پیش`
  if (diffDay < 7) return `${toPersianDigits(diffDay)} روز پیش`
  if (diffWeek < 4) return `${toPersianDigits(diffWeek)} هفته پیش`
  if (diffMonth < 12) return `${toPersianDigits(diffMonth)} ماه پیش`
  return formatPersianShort(d)
}

// Format time (HH:MM)
export function formatTime(date: Date | string): string {
  const d = new Date(date)
  const hours = d.getHours().toString().padStart(2, '0')
  const minutes = d.getMinutes().toString().padStart(2, '0')
  return `${toPersianDigits(hours)}:${toPersianDigits(minutes)}`
}

// Gregorian to Jalali conversion
function gregorianToJalali(gy: number, gm: number, gd: number): [number, number, number] {
  const g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334]
  let jy: number
  if (gy > 1600) {
    jy = 979
    gy -= 1600
  } else {
    jy = 0
    gy -= 621
  }
  const gy2 = gm > 2 ? gy + 1 : gy
  let days =
    365 * gy +
    Math.floor((gy2 + 3) / 4) -
    Math.floor((gy2 + 99) / 100) +
    Math.floor((gy2 + 399) / 400) -
    80 +
    gd +
    g_d_m[gm - 1]
  jy += 33 * Math.floor(days / 12053)
  days %= 12053
  jy += 4 * Math.floor(days / 1461)
  days %= 1461
  if (days > 365) {
    jy += Math.floor((days - 1) / 365)
    days = (days - 1) % 365
  }
  const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30)
  const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30)
  return [jy, jm, jd]
}

// Format number with thousand separators (Persian)
export function formatNumber(n: number): string {
  return toPersianDigits(n.toLocaleString('en-US'))
}

// Estimate reading time in minutes
export function calculateReadingTime(content: string): number {
  // Average reading speed: ~200 words per minute for Persian
  const words = content.trim().split(/\s+/).length
  return Math.max(1, Math.ceil(words / 200))
}

// Generate slug from Persian/English title
export function slugify(text: string): string {
  // For Persian text, use a comprehensive transliteration
  const hasPersian = /[\u0600-\u06FF]/.test(text)
  if (hasPersian) {
    // Transliterate Persian letters to English
    const persianMap: Record<string, string> = {
      'آ': 'a', 'ا': 'a', 'أ': 'a', 'إ': 'a',
      'ب': 'b', 'پ': 'p', 'ت': 't', 'ث': 's',
      'ج': 'j', 'چ': 'ch', 'ح': 'h', 'خ': 'kh',
      'د': 'd', 'ذ': 'z', 'ر': 'r', 'ز': 'z',
      'ژ': 'zh', 'س': 's', 'ش': 'sh', 'ص': 's',
      'ض': 'z', 'ط': 't', 'ظ': 'z', 'ع': 'a',
      'غ': 'gh', 'ف': 'f', 'ق': 'gh', 'ک': 'k',
      'گ': 'g', 'ل': 'l', 'م': 'm', 'ن': 'n',
      'و': 'v', 'ه': 'h', 'ی': 'y', 'ئ': 'y',
      'ء': 'a',
      '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
      '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9',
    }

    let cleaned = text
    // First replace each Persian character
    for (const [persian, english] of Object.entries(persianMap)) {
      cleaned = cleaned.replace(new RegExp(persian, 'g'), english)
    }
    // Remove any remaining non-ASCII chars
    cleaned = cleaned
      .replace(/[^a-zA-Z0-9\s-]/g, '')
      .trim()
      .toLowerCase()
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .substring(0, 60)

    const suffix = Math.random().toString(36).substring(2, 6)
    return `${cleaned || 'article'}-${suffix}`
  }
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .substring(0, 80)
}

// Truncate text
export function truncate(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return text.substring(0, maxLength).trim() + '...'
}

// Strip HTML tags
export function stripHtml(html: string): string {
  return html
    .replace(/<[^>]*>/g, '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .trim()
}
