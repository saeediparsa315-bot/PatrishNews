import type { MetadataRoute } from 'next'

// در زمان build، دیتابیس ممکن است موجود نباشد
// پس فقط صفحات استاتیک رو در sitemap قرار می‌دهیم
// صفحات داینامیک (اخبار و دسته‌ها) در زمان اجرا توسط سرور اضافه می‌شوند

export const dynamic = 'force-dynamic'

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || 'https://patrishnews.ir'

  const staticPages: MetadataRoute.Sitemap = [
    { url: `${baseUrl}/`, lastModified: new Date(), changeFrequency: 'hourly', priority: 1 },
    { url: `${baseUrl}/about`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.7 },
    { url: `${baseUrl}/contact`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.7 },
    { url: `${baseUrl}/search`, lastModified: new Date(), changeFrequency: 'daily', priority: 0.6 },
    { url: `${baseUrl}/latest`, lastModified: new Date(), changeFrequency: 'hourly', priority: 0.8 },
    { url: `${baseUrl}/trending`, lastModified: new Date(), changeFrequency: 'hourly', priority: 0.8 },
    { url: `${baseUrl}/breaking`, lastModified: new Date(), changeFrequency: 'hourly', priority: 0.9 },
  ]

  // صفحات داینامیک (اخبار و دسته‌ها) در زمان اجرا اضافه می‌شوند
  // چون در زمان build دیتابیس ممکن است موجود نباشد
  return staticPages
}
