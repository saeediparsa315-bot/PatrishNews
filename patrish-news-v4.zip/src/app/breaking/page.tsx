import { redirect } from 'next/navigation'

export default function BreakingPage() {
  redirect('/search?type=breaking')
}
