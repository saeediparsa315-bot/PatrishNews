import { redirect } from 'next/navigation'

export default function LatestPage() {
  redirect('/search?type=latest')
}
