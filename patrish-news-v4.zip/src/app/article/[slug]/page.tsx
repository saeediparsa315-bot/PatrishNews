import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { ArticleActions } from '@/components/article-actions'
import { CommentsSection } from '@/components/comments-section'
import { ArticleCard } from '@/components/article-card'
import { ReadingProgress } from '@/components/reading-progress'
import { formatPersianDate, formatNumber, toPersianDigits } from '@/lib/persian'
import { Clock, Eye, MessageCircle, Calendar, ChevronLeft, Tag } from 'lucide-react'

export const revalidate = 60

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const article = await db.article.findUnique({
    where: { slug },
    select: { title: true, excerpt: true, metaTitle: true, metaDescription: true, coverImage: true },
  })

  if (!article) return { title: 'خبر یافت نشد' }

  return {
    title: article.metaTitle || article.title,
    description: article.metaDescription || article.excerpt || '',
    openGraph: {
      title: article.title,
      description: article.excerpt || '',
      images: article.coverImage ? [article.coverImage] : undefined,
    },
  }
}

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const user = await getCurrentUser()

  const [categories, article] = await Promise.all([
    db.category.findMany({
      where: { isActive: true, parentId: null },
      orderBy: { order: 'asc' },
    }),
    db.article.findUnique({
      where: { slug },
      include: {
        category: { select: { id: true, name: true, slug: true, color: true, icon: true } },
        author: { select: { id: true, username: true, name: true, avatar: true } },
        tags: { select: { id: true, name: true, slug: true, color: true } },
      },
    }),
  ])

  if (!article || (article.status !== 'PUBLISHED' && !(user && (user.role === 'ADMIN' || user.role === 'SUPER_ADMIN')))) {
    notFound()
  }

  // Increment view count
  await db.article.update({
    where: { id: article.id },
    data: { viewCount: { increment: 1 } },
  })

  // Get user interactions
  let userInteractions = { liked: false, bookmarked: false }
  if (user) {
    const [like, bookmark] = await Promise.all([
      db.like.findUnique({
        where: { userId_articleId: { userId: user.id, articleId: article.id } },
      }),
      db.bookmark.findUnique({
        where: { userId_articleId: { userId: user.id, articleId: article.id } },
      }),
    ])
    userInteractions = { liked: !!like, bookmarked: !!bookmark }
  }

  // Get approved comments
  const comments = await db.comment.findMany({
    where: { articleId: article.id, status: 'APPROVED', parentId: null },
    include: {
      user: { select: { id: true, username: true, name: true, avatar: true } },
      replies: {
        where: { status: 'APPROVED' },
        include: {
          user: { select: { id: true, username: true, name: true, avatar: true } },
        },
        orderBy: { createdAt: 'asc' },
      },
    },
    orderBy: { createdAt: 'desc' },
  })

  // Related articles
  const related = await db.article.findMany({
    where: {
      status: 'PUBLISHED',
      categoryId: article.categoryId,
      NOT: { id: article.id },
    },
    include: {
      category: { select: { id: true, name: true, slug: true, color: true, icon: true } },
    },
    take: 3,
    orderBy: { publishedAt: 'desc' },
  })

  return (
    <div className="min-h-screen flex flex-col">
      <ReadingProgress />
      <SiteHeader user={user} categories={categories} />

      <main className="flex-1">
        <article className="container mx-auto px-4 py-6 sm:py-8 max-w-4xl">
          {/* Breadcrumb */}
          <nav className="flex items-center gap-1 text-sm text-muted-foreground mb-6 flex-wrap">
            <Link href="/" className="hover:text-foreground">خانه</Link>
            <ChevronLeft className="size-3" />
            {article.category && (
              <>
                <Link href={`/category/${article.category.slug}`} className="hover:text-foreground">
                  {article.category.name}
                </Link>
                <ChevronLeft className="size-3" />
              </>
            )}
            <span className="text-foreground line-clamp-1">{article.title}</span>
          </nav>

          {/* Category badge */}
          {article.category && (
            <Link
              href={`/category/${article.category.slug}`}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md text-sm font-semibold mb-4"
              style={{
                backgroundColor: `${article.category.color}20`,
                color: article.category.color,
              }}
            >
              {article.category.name}
            </Link>
          )}

          {/* Title */}
          <h1 className="text-2xl sm:text-4xl font-bold leading-tight mb-4">
            {article.title}
          </h1>

          {/* Excerpt */}
          {article.excerpt && (
            <p className="text-lg text-muted-foreground leading-relaxed mb-6">
              {article.excerpt}
            </p>
          )}

          {/* Meta info */}
          <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground pb-6 border-b border-border/40 mb-6">
            {article.author && (
              <div className="flex items-center gap-2">
                <div className="size-8 rounded-full bg-primary/15 flex items-center justify-center text-xs font-bold text-primary">
                  {(article.author.name || article.author.username).charAt(0)}
                </div>
                <span className="font-medium text-foreground">
                  {article.author.name || article.author.username}
                </span>
              </div>
            )}
            <div className="flex items-center gap-1.5">
              <Calendar className="size-4" />
              {formatPersianDate(article.publishedAt || article.createdAt)}
            </div>
            <div className="flex items-center gap-1.5">
              <Clock className="size-4" />
              {toPersianDigits(article.readingTime)} دقیقه مطالعه
            </div>
            {user && (user.role === 'ADMIN' || user.role === 'SUPER_ADMIN') && (
              <div className="flex items-center gap-1.5">
                <Eye className="size-4" />
                {formatNumber(article.viewCount)} بازدید
              </div>
            )}
            <div className="flex items-center gap-1.5">
              <MessageCircle className="size-4" />
              {toPersianDigits(article.commentCount)} نظر
            </div>
          </div>

          {/* Cover image */}
          {article.coverImage && (
            <div className="relative aspect-[16/9] mb-8 overflow-hidden rounded-xl bg-muted">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={article.coverImage}
                alt={article.title}
                className="absolute inset-0 size-full object-cover"
                loading="eager"
              />
            </div>
          )}

          {/* Content */}
          <div
            className="article-content mb-8"
            dangerouslySetInnerHTML={{ __html: article.content }}
          />

          {/* Tags */}
          {article.tags.length > 0 && (
            <div className="flex flex-wrap items-center gap-2 mb-6">
              <Tag className="size-4 text-muted-foreground" />
              {article.tags.map(tag => (
                <Link
                  key={tag.id}
                  href={`/search?q=${encodeURIComponent(tag.name)}`}
                  className="px-3 py-1 rounded-md text-xs font-medium border hover:bg-muted transition-colors"
                  style={{ borderColor: `${tag.color}40`, color: tag.color }}
                >
                  {tag.name}
                </Link>
              ))}
            </div>
          )}

          {/* Actions */}
          <ArticleActions
            articleId={article.id}
            initialLikes={article.likeCount}
            initialLiked={userInteractions.liked}
            initialBookmarked={userInteractions.bookmarked}
            isLoggedIn={!!user}
          />

          {/* Author info */}
          {article.author && (
            <div className="mt-8 p-5 rounded-xl border bg-card flex items-center gap-4">
              <div className="size-14 rounded-full bg-primary/15 flex items-center justify-center text-lg font-bold text-primary">
                {(article.author.name || article.author.username).charAt(0)}
              </div>
              <div>
                <div className="text-sm text-muted-foreground">نوشته شده توسط</div>
                <div className="font-semibold text-lg">{article.author.name || article.author.username}</div>
              </div>
            </div>
          )}

          {/* Related articles */}
          {related.length > 0 && (
            <section className="mt-12">
              <h2 className="text-xl font-bold mb-6">اخبار مرتبط</h2>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {related.map(a => (
                  <ArticleCard key={a.id} article={a} variant="compact" />
                ))}
              </div>
            </section>
          )}

          {/* Comments */}
          <CommentsSection
            articleId={article.id}
            comments={comments}
            isLoggedIn={!!user}
          />
        </article>
      </main>

      <SiteFooter />
    </div>
  )
}
