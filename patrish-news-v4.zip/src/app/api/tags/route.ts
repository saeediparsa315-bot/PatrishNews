import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { slugify } from '@/lib/persian'
import { logAction } from '@/lib/settings'

// GET /api/tags
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const search = searchParams.get('search')

    const where = search ? { name: { contains: search } } : {}

    const tags = await db.tag.findMany({
      where,
      include: { _count: { select: { articles: { where: { status: 'PUBLISHED' } } } } },
      orderBy: { name: 'asc' },
      take: 100,
    })

    return NextResponse.json({ success: true, data: tags })
  } catch (e) {
    console.error('GET /api/tags error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

// POST /api/tags
export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ success: false, error: 'فقط سوپر ادمین' }, { status: 403 })
    }

    const body = await req.json()
    const { name, color } = body

    if (!name) {
      return NextResponse.json({ success: false, error: 'نام الزامی است' }, { status: 400 })
    }

    // Check existing
    const existing = await db.tag.findUnique({ where: { slug: slugify(name) } })
    if (existing) {
      return NextResponse.json({ success: true, data: existing })
    }

    const tag = await db.tag.create({
      data: { name, slug: slugify(name), color: color || '#7C3AED' },
    })

    await logAction(user.id, 'CREATE', 'TAG', tag.id, `Name: ${name}`)
    return NextResponse.json({ success: true, data: tag })
  } catch (e) {
    console.error('POST /api/tags error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
