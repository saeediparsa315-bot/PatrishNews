import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser, canManageUsers, hashPassword } from '@/lib/auth'
import { logAction } from '@/lib/settings'

// GET /api/users - List users (admin only)
export async function GET(req: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 403 })
    }

    const { searchParams } = new URL(req.url)
    const search = searchParams.get('search')
    const role = searchParams.get('role')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = Math.min(parseInt(searchParams.get('limit') || '20'), 50)

    const where: Record<string, unknown> = {}
    if (search) {
      where.OR = [
        { email: { contains: search } },
        { username: { contains: search } },
        { name: { contains: search } },
      ]
    }
    if (role) where.role = role

    const [total, users] = await Promise.all([
      db.user.count({ where }),
      db.user.findMany({
        where,
        select: {
          id: true,
          email: true,
          username: true,
          name: true,
          avatar: true,
          role: true,
          isBlocked: true,
          createdAt: true,
          _count: {
            select: {
              articles: true,
              comments: true,
              bookmarks: true,
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
    ])

    return NextResponse.json({
      success: true,
      data: users,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    })
  } catch (e) {
    console.error('GET /api/users error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

// POST /api/users - Update user role (only super admin)
export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user || !canManageUsers(user.role as 'SUPER_ADMIN' | 'ADMIN' | 'USER')) {
      return NextResponse.json({ success: false, error: 'فقط سوپر ادمین' }, { status: 403 })
    }

    const body = await req.json()
    const { userId, action, value } = body

    if (!userId || !action) {
      return NextResponse.json({ success: false, error: 'پارامتر ناقص' }, { status: 400 })
    }

    const target = await db.user.findUnique({ where: { id: userId } })
    if (!target) {
      return NextResponse.json({ success: false, error: 'کاربر یافت نشد' }, { status: 404 })
    }

    // Prevent super admin from blocking/altering themselves
    if (target.id === user.id && action !== 'UPDATE_PROFILE') {
      return NextResponse.json({ success: false, error: 'نمی‌توانید خودتان را تغییر دهید' }, { status: 400 })
    }

    // Prevent demoting last super admin
    if (target.role === 'SUPER_ADMIN' && action === 'SET_ROLE' && value !== 'SUPER_ADMIN') {
      const superAdminCount = await db.user.count({ where: { role: 'SUPER_ADMIN' } })
      if (superAdminCount <= 1) {
        return NextResponse.json(
          { success: false, error: 'حداقل یک سوپر ادمین باید باقی بماند' },
          { status: 400 }
        )
      }
    }

    let updated
    switch (action) {
      case 'SET_ROLE':
        updated = await db.user.update({
          where: { id: userId },
          data: { role: value },
        })
        await logAction(user.id, 'CHANGE_ROLE', 'USER', userId, `Role: ${value}`)
        break

      case 'BLOCK':
        updated = await db.user.update({
          where: { id: userId },
          data: { isBlocked: true },
        })
        await logAction(user.id, 'BLOCK', 'USER', userId)
        // Delete all sessions
        await db.session.deleteMany({ where: { userId } }).catch(() => {})
        break

      case 'UNBLOCK':
        updated = await db.user.update({
          where: { id: userId },
          data: { isBlocked: false },
        })
        await logAction(user.id, 'UNBLOCK', 'USER', userId)
        break

      case 'DELETE':
        if (target.role === 'SUPER_ADMIN') {
          return NextResponse.json(
            { success: false, error: 'سوپر ادمین قابل حذف نیست' },
            { status: 400 }
          )
        }
        await db.user.delete({ where: { id: userId } })
        await logAction(user.id, 'DELETE', 'USER', userId, `Email: ${target.email}`)
        return NextResponse.json({ success: true })

      case 'UPDATE_PROFILE':
        if (target.id !== user.id) {
          return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 403 })
        }
        const updateData: Record<string, unknown> = {}
        if (body.name !== undefined) updateData.name = body.name
        if (body.username !== undefined) updateData.username = body.username
        if (body.avatar !== undefined) updateData.avatar = body.avatar
        if (body.password) {
          if (body.password.length < 6) {
            return NextResponse.json(
              { success: false, error: 'رمز عبور باید حداقل ۶ کاراکتر باشد' },
              { status: 400 }
            )
          }
          updateData.passwordHash = hashPassword(body.password)
        }
        updated = await db.user.update({
          where: { id: userId },
          data: updateData,
          select: {
            id: true, email: true, username: true, name: true, avatar: true, role: true,
          },
        })
        break

      default:
        return NextResponse.json({ success: false, error: 'Invalid action' }, { status: 400 })
    }

    return NextResponse.json({ success: true, data: updated })
  } catch (e) {
    console.error('POST /api/users error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
