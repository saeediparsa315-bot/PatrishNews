import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { logAction } from '@/lib/settings'

// POST /api/backup/import - بازیابی از فایل بک‌آپ
export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ success: false, error: 'فقط سوپر ادمین' }, { status: 403 })
    }

    const body = await req.json()
    const backup = body

    if (!backup || !backup.meta || !backup.data) {
      return NextResponse.json({ success: false, error: 'فایل بک‌آپ نامعتبر' }, { status: 400 })
    }

    const { data } = backup

    // اعتبارسنجی نسخه
    if (backup.meta.version !== '1.0') {
      return NextResponse.json({ success: false, error: 'نسخه بک‌آپ پشتیبانی نمی‌شود' }, { status: 400 })
    }

    // ⚠️ هشدار: این عملیات تمام داده‌های فعلی را جایگزین می‌کند
    // ترتیب مهم است: اول جداول بدون وابستگی، بعد جداول با وابستگی

    // ۱. پاک‌سازی داده‌های فعلی (به ترتیب معکوس وابستگی)
    await db.session.deleteMany()
    await db.auditLog.deleteMany()
    await db.bookmark.deleteMany()
    await db.like.deleteMany()
    await db.comment.deleteMany()
    await db.article.deleteMany()
    await db.tag.deleteMany()
    await db.category.deleteMany()
    await db.user.deleteMany()
    await db.siteSetting.deleteMany()

    // ۲. بازیابی کاربران
    if (data.users && data.users.length > 0) {
      for (const u of data.users) {
        await db.user.create({
          data: {
            id: u.id,
            email: u.email,
            username: u.username,
            passwordHash: u.passwordHash,
            name: u.name,
            avatar: u.avatar,
            role: u.role,
            isBlocked: u.isBlocked || false,
            emailVerified: u.emailVerified || null,
            createdAt: new Date(u.createdAt),
            updatedAt: new Date(u.updatedAt),
          },
        })
      }
    }

    // ۳. بازیابی تنظیمات سایت
    if (data.siteSettings && data.siteSettings.length > 0) {
      for (const s of data.siteSettings) {
        await db.siteSetting.create({
          data: {
            id: s.id,
            key: s.key,
            value: s.value,
          },
        })
      }
    }

    // ۴. بازیابی دسته‌بندی‌ها
    if (data.categories && data.categories.length > 0) {
      for (const c of data.categories) {
        await db.category.create({
          data: {
            id: c.id,
            name: c.name,
            slug: c.slug,
            description: c.description,
            color: c.color,
            icon: c.icon,
            order: c.order,
            isActive: c.isActive,
            parentId: c.parentId || null,
            createdAt: new Date(c.createdAt),
            updatedAt: new Date(c.updatedAt),
          },
        })
      }
    }

    // ۵. بازیابی برچسب‌ها
    if (data.tags && data.tags.length > 0) {
      for (const t of data.tags) {
        await db.tag.create({
          data: {
            id: t.id,
            name: t.name,
            slug: t.slug,
            color: t.color,
            createdAt: new Date(t.createdAt),
          },
        })
      }
    }

    // ۶. بازیابی اخبار
    if (data.articles && data.articles.length > 0) {
      for (const a of data.articles) {
        await db.article.create({
          data: {
            id: a.id,
            title: a.title,
            slug: a.slug,
            excerpt: a.excerpt,
            content: a.content,
            coverImage: a.coverImage,
            categoryId: a.categoryId,
            authorId: a.authorId,
            status: a.status,
            isFeatured: a.isFeatured || false,
            isBreaking: a.isBreaking || false,
            isHomepage: a.isHomepage || false,
            isMainHeadline: a.isMainHeadline || false,
            layoutMode: a.layoutMode || 'DEFAULT',
            displayOrder: a.displayOrder || 0,
            position: a.position || 0,
            readingTime: a.readingTime || 1,
            viewCount: a.viewCount || 0,
            likeCount: a.likeCount || 0,
            commentCount: a.commentCount || 0,
            scheduledAt: a.scheduledAt ? new Date(a.scheduledAt) : null,
            publishedAt: a.publishedAt ? new Date(a.publishedAt) : null,
            metaTitle: a.metaTitle,
            metaDescription: a.metaDescription,
            metaKeywords: a.metaKeywords,
            createdAt: new Date(a.createdAt),
            updatedAt: new Date(a.updatedAt),
          },
        })
      }
    }

    // ۷. بازیابی روابط article-tag
    if (data.articleTags && data.articleTags.length > 0) {
      for (const at of data.articleTags) {
        const articleId = at.A || at.articleId
        const tagId = at.B || at.tagId
        if (articleId && tagId) {
          await db.$executeRaw`INSERT OR IGNORE INTO _ArticleToTag (A, B) VALUES (${articleId}, ${tagId})`
        }
      }
    }

    // ۸. بازیابی نظرات
    if (data.comments && data.comments.length > 0) {
      for (const c of data.comments) {
        await db.comment.create({
          data: {
            id: c.id,
            content: c.content,
            articleId: c.articleId,
            userId: c.userId,
            parentId: c.parentId || null,
            status: c.status || 'PENDING',
            likeCount: c.likeCount || 0,
            createdAt: new Date(c.createdAt),
            updatedAt: new Date(c.updatedAt),
          },
        })
      }
    }

    // ۹. بازیابی لایک‌ها
    if (data.likes && data.likes.length > 0) {
      for (const l of data.likes) {
        await db.like.create({
          data: {
            id: l.id,
            userId: l.userId,
            articleId: l.articleId,
            commentId: l.commentId,
            createdAt: new Date(l.createdAt),
          },
        })
      }
    }

    // ۱۰. بازیابی بوک‌مارک‌ها
    if (data.bookmarks && data.bookmarks.length > 0) {
      for (const b of data.bookmarks) {
        await db.bookmark.create({
          data: {
            id: b.id,
            userId: b.userId,
            articleId: b.articleId,
            createdAt: new Date(b.createdAt),
          },
        })
      }
    }

    // ۱۱. بازیابی نشست‌ها (اختیاری - ممکنه نیاز به重新login داشته باشن)
    // نشست‌ها رو بازیابی نمی‌کنیم چون ممکنه منقضی شده باشن

    // ۱۲. بازیابی لاگ‌ها
    if (data.auditLogs && data.auditLogs.length > 0) {
      for (const log of data.auditLogs) {
        await db.auditLog.create({
          data: {
            id: log.id,
            userId: log.userId,
            action: log.action,
            entity: log.entity,
            entityId: log.entityId,
            details: log.details,
            ip: log.ip,
            createdAt: new Date(log.createdAt),
          },
        })
      }
    }

    await logAction(user.id, 'BACKUP_IMPORT', 'DATABASE', null, `Imported backup from ${backup.meta.exportedAt}`)

    return NextResponse.json({
      success: true,
      message: 'بک‌آپ با موفقیت بازیابی شد',
      data: backup.meta.counts,
    })
  } catch (e) {
    console.error('Backup import error:', e)
    return NextResponse.json({ success: false, error: 'خطا در بازیابی بک‌آپ: ' + (e instanceof Error ? e.message : '') }, { status: 500 })
  }
}
