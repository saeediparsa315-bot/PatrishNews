import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { logAction } from '@/lib/settings'

// GET /api/backup/export - بک‌آپ‌گیری از کل دیتابیس
export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ success: false, error: 'فقط سوپر ادمین' }, { status: 403 })
    }

    // جمع‌آوری تمام داده‌ها
    const [
      users, categories, tags, articles, comments,
      likes, bookmarks, sessions, auditLogs, siteSettings,
      articleTags,
    ] = await Promise.all([
      db.user.findMany(),
      db.category.findMany(),
      db.tag.findMany(),
      db.article.findMany(),
      db.comment.findMany(),
      db.like.findMany(),
      db.bookmark.findMany(),
      db.session.findMany(),
      db.auditLog.findMany(),
      db.siteSetting.findMany(),
      // رابطه article-tag (جدول واسط)
      db.$queryRaw`SELECT * FROM _ArticleToTag`,
    ])

    // ساخت فایل بک‌آپ
    const backup = {
      meta: {
        version: '1.0',
        exportedAt: new Date().toISOString(),
        exportedBy: user.email,
        counts: {
          users: users.length,
          categories: categories.length,
          tags: tags.length,
          articles: articles.length,
          comments: comments.length,
          likes: likes.length,
          bookmarks: bookmarks.length,
          sessions: sessions.length,
          auditLogs: auditLogs.length,
          siteSettings: siteSettings.length,
          articleTags: Array.isArray(articleTags) ? articleTags.length : 0,
        },
      },
      data: {
        users: users.map(u => ({
          ...u,
          passwordHash: u.passwordHash, // رمزهای عبور هش شده حفظ می‌شوند
        })),
        categories,
        tags,
        articles,
        comments,
        likes,
        bookmarks,
        sessions,
        auditLogs,
        siteSettings,
        articleTags: Array.isArray(articleTags) ? articleTags : [],
      },
    }

    await logAction(user.id, 'BACKUP_EXPORT', 'DATABASE', null, `Exported ${articles.length} articles, ${users.length} users`)

    const filename = `patrish-backup-${new Date().toISOString().slice(0, 10)}.json`

    return new NextResponse(JSON.stringify(backup, null, 2), {
      headers: {
        'Content-Type': 'application/json; charset=utf-8',
        'Content-Disposition': `attachment; filename="${filename}"`,
      },
    })
  } catch (e) {
    console.error('Backup export error:', e)
    return NextResponse.json({ success: false, error: 'خطا در بک‌آپ‌گیری' }, { status: 500 })
  }
}
