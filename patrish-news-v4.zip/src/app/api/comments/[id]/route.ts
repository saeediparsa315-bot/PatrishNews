import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser, canModerateComments } from '@/lib/auth'
import { logAction } from '@/lib/settings'

// PUT /api/comments/[id] - Update status (approve/reject) or content
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const comment = await db.comment.findUnique({ where: { id } })
    if (!comment) {
      return NextResponse.json({ success: false, error: 'یافت نشد' }, { status: 404 })
    }

    const updateData: Record<string, unknown> = {}

    // Status change - admin only
    if (body.status) {
      if (!canModerateComments(user.role as 'SUPER_ADMIN' | 'ADMIN' | 'USER')) {
        return NextResponse.json({ success: false, error: 'دسترسی غیرمجاز' }, { status: 403 })
      }
      const oldStatus = comment.status
      updateData.status = body.status

      // Update article comment count if status changed to/from APPROVED
      if (oldStatus !== body.status) {
        const delta = body.status === 'APPROVED' ? 1 : (oldStatus === 'APPROVED' ? -1 : 0)
        if (delta !== 0) {
          await db.article.update({
            where: { id: comment.articleId },
            data: { commentCount: { increment: delta } },
          })
        }
      }
    }

    // Content change - owner only
    if (body.content !== undefined) {
      if (comment.userId !== user.id && !canModerateComments(user.role as 'SUPER_ADMIN' | 'ADMIN' | 'USER')) {
        return NextResponse.json({ success: false, error: 'دسترسی غیرمجاز' }, { status: 403 })
      }
      updateData.content = body.content
    }

    const updated = await db.comment.update({ where: { id }, data: updateData })
    await logAction(user.id, 'UPDATE', 'COMMENT', id, `Status: ${body.status || 'content'}`)

    return NextResponse.json({ success: true, data: updated })
  } catch (e) {
    console.error('PUT /api/comments/[id] error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

// DELETE /api/comments/[id]
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const comment = await db.comment.findUnique({ where: { id } })
    if (!comment) {
      return NextResponse.json({ success: false, error: 'یافت نشد' }, { status: 404 })
    }

    const canDelete =
      comment.userId === user.id ||
      canModerateComments(user.role as 'SUPER_ADMIN' | 'ADMIN' | 'USER')

    if (!canDelete) {
      return NextResponse.json({ success: false, error: 'دسترسی غیرمجاز' }, { status: 403 })
    }

    if (comment.status === 'APPROVED') {
      await db.article.update({
        where: { id: comment.articleId },
        data: { commentCount: { decrement: 1 } },
      })
    }

    await db.comment.delete({ where: { id } })
    await logAction(user.id, 'DELETE', 'COMMENT', id)

    return NextResponse.json({ success: true })
  } catch (e) {
    console.error('DELETE /api/comments/[id] error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
