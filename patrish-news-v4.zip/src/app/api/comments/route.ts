import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser, canModerateComments } from '@/lib/auth'
import { getSetting } from '@/lib/settings'

// GET /api/comments?articleId=...&status=...
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const articleId = searchParams.get('articleId')
    const status = searchParams.get('status')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = Math.min(parseInt(searchParams.get('limit') || '20'), 50)

    const user = await getCurrentUser()
    const isAdmin = user && canModerateComments(user.role as 'SUPER_ADMIN' | 'ADMIN' | 'USER')

    const where: Record<string, unknown> = {}
    if (articleId) where.articleId = articleId
    if (status && isAdmin) where.status = status
    else where.status = 'APPROVED'

    const [total, comments] = await Promise.all([
      db.comment.count({ where }),
      db.comment.findMany({
        where,
        include: {
          user: { select: { id: true, username: true, name: true, avatar: true } },
          article: { select: { id: true, title: true, slug: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
    ])

    return NextResponse.json({
      success: true,
      data: comments,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    })
  } catch (e) {
    console.error('GET /api/comments error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

// POST /api/comments
export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'برای نظر دادن وارد شوید' }, { status: 401 })
    }

    const commentsEnabled = await getSetting('comments_enabled')
    if (commentsEnabled === 'false') {
      return NextResponse.json({ success: false, error: 'نظرات غیرفعال است' }, { status: 403 })
    }

    const body = await req.json()
    const { content, articleId, parentId } = body

    if (!content || !articleId) {
      return NextResponse.json({ success: false, error: 'محتوای نظر و خبر الزامی است' }, { status: 400 })
    }

    if (content.length > 1000) {
      return NextResponse.json({ success: false, error: 'نظر بیش از حد طولانی است' }, { status: 400 })
    }

    // Check article exists
    const article = await db.article.findUnique({ where: { id: articleId } })
    if (!article || article.status !== 'PUBLISHED') {
      return NextResponse.json({ success: false, error: 'خبر یافت نشد' }, { status: 404 })
    }

    // Determine status
    const requireApproval = await getSetting('comments_require_approval')
    const status = requireApproval === 'false' ? 'APPROVED' : 'PENDING'

    const comment = await db.comment.create({
      data: {
        content,
        articleId,
        userId: user.id,
        parentId: parentId || null,
        status,
      },
      include: {
        user: { select: { id: true, username: true, name: true, avatar: true } },
      },
    })

    if (status === 'APPROVED') {
      await db.article.update({
        where: { id: articleId },
        data: { commentCount: { increment: 1 } },
      })
    }

    return NextResponse.json({ success: true, data: comment })
  } catch (e) {
    console.error('POST /api/comments error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
