import { NextResponse } from 'next/server'
import { destroySession, getCurrentUser, AUTH_HEADER } from '@/lib/auth'
import { logAction } from '@/lib/settings'

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser()
    if (user) {
      await logAction(user.id, 'LOGOUT', 'USER', user.id)
    }
    await destroySession()
    return NextResponse.json({ success: true })
  } catch (e) {
    return NextResponse.json({ success: false, error: 'خطا در خروج' }, { status: 500 })
  }
}
