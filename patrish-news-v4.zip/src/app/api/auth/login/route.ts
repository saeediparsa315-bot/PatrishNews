import { NextRequest, NextResponse } from 'next/server'
import { db, ensureSchema, dbInfo } from '@/lib/db'
import { createSession, hashPassword, verifyPassword } from '@/lib/auth'
import { logAction } from '@/lib/settings'

/**
 * POST /api/auth/login
 *
 * فقط login می‌کنه. هیچ auto-create انجام نمیده.
 * در صورت خطای readonly، خطای واضح می‌ده.
 */
export async function POST(req: NextRequest) {
  try {
    await ensureSchema()

    const body = await req.json()
    const { email, password } = body

    if (!email || !password) {
      return NextResponse.json(
        { success: false, error: 'ایمیل و رمز عبور الزامی هستند' },
        { status: 400 }
      )
    }

    const normalizedEmail = email.toLowerCase().trim()

    const user = await db.user.findUnique({
      where: { email: normalizedEmail },
    })

    if (!user) {
      return NextResponse.json(
        { success: false, error: 'ایمیل یا رمز عبور اشتباه است' },
        { status: 401 }
      )
    }

    if (!verifyPassword(password, user.passwordHash)) {
      return NextResponse.json(
        { success: false, error: 'ایمیل یا رمز عبور اشتباه است' },
        { status: 401 }
      )
    }

    if (user.isBlocked) {
      return NextResponse.json(
        { success: false, error: 'حساب کاربری شما مسدود شده است' },
        { status: 403 }
      )
    }

    // ساخت session - اینجا ممکنه خطای readonly بده
    let token: string
    try {
      token = await createSession(user.id)
    } catch (sessionError) {
      const msg = (sessionError as Error).message
      console.error('[Login] خطا در ساخت session:', msg)

      if (msg.includes('readonly') || msg.includes('read-only')) {
        return NextResponse.json(
          {
            success: false,
            error: 'دیتابیس readonly است! نمی‌تونم session بسازم. اجرا کنید: chmod -R 777 ' + dbInfo.dir,
            errorCode: 'DB_READONLY',
            dbDir: dbInfo.dir,
          },
          { status: 500 }
        )
      }

      throw sessionError
    }

    try {
      await logAction(user.id, 'LOGIN', 'USER', user.id)
    } catch (e) {
      // log خطا نباید login رو متوقف کنه
      console.warn('[Login] logAction خطا:', (e as Error).message)
    }

    return NextResponse.json({
      success: true,
      data: {
        id: user.id,
        email: user.email,
        username: user.username,
        name: user.name,
        avatar: user.avatar,
        role: user.role,
      },
      token,
    })
  } catch (e) {
    console.error('Login error:', e)
    const msg = e instanceof Error ? e.message : ''

    // تشخیص خطای readonly
    if (msg.includes('readonly') || msg.includes('read-only')) {
      return NextResponse.json(
        {
          success: false,
          error: 'دیتابیس readonly است! لطفاً /api/diagnose رو ببینید',
          errorCode: 'DB_READONLY',
        },
        { status: 500 }
      )
    }

    return NextResponse.json(
      { success: false, error: 'خطا در ورود. اگه تازه deploy کردید، به /api/setup برید. جزئیات: ' + msg.substring(0, 150) },
      { status: 500 }
    )
  }
}
