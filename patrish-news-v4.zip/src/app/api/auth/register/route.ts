import { NextRequest, NextResponse } from 'next/server'
import { db, ensureSchema, dbInfo } from '@/lib/db'
import { createSession, hashPassword } from '@/lib/auth'
import { logAction } from '@/lib/settings'

export async function POST(req: NextRequest) {
  try {
    await ensureSchema()

    const body = await req.json()
    const { email, username, password, name } = body

    if (!email || !username || !password) {
      return NextResponse.json(
        { success: false, error: 'ایمیل، نام کاربری و رمز عبور الزامی هستند' },
        { status: 400 }
      )
    }

    if (password.length < 6) {
      return NextResponse.json(
        { success: false, error: 'رمز عبور باید حداقل ۶ کاراکتر باشد' },
        { status: 400 }
      )
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { success: false, error: 'فرمت ایمیل صحیح نیست' },
        { status: 400 }
      )
    }

    const normalizedEmail = email.toLowerCase().trim()
    const normalizedUsername = username.trim()

    const existing = await db.user.findFirst({
      where: {
        OR: [{ email: normalizedEmail }, { username: normalizedUsername }],
      },
    })

    if (existing) {
      if (existing.email === normalizedEmail) {
        return NextResponse.json(
          { success: false, error: 'این ایمیل قبلاً ثبت شده است' },
          { status: 400 }
        )
      }
      return NextResponse.json(
        { success: false, error: 'این نام کاربری قبلاً گرفته شده است' },
        { status: 400 }
      )
    }

    const userCount = await db.user.count()
    const role = userCount === 0 ? 'SUPER_ADMIN' : 'USER'

    // ساخت کاربر - ممکنه خطای readonly بده
    let user
    try {
      user = await db.user.create({
        data: {
          email: normalizedEmail,
          username: normalizedUsername,
          passwordHash: hashPassword(password),
          name: name || normalizedUsername,
          role,
        },
      })
    } catch (createError) {
      const msg = (createError as Error).message
      if (msg.includes('readonly') || msg.includes('read-only')) {
        return NextResponse.json(
          {
            success: false,
            error: 'دیتابیس readonly است! نمی‌تونم کاربر بسازم. اجرا کنید: chmod -R 777 ' + dbInfo.dir,
            errorCode: 'DB_READONLY',
            dbDir: dbInfo.dir,
          },
          { status: 500 }
        )
      }
      throw createError
    }

    const token = await createSession(user.id)
    try {
      await logAction(user.id, 'REGISTER', 'USER', user.id, `Role: ${role}`)
    } catch {}

    return NextResponse.json({
      success: true,
      data: {
        id: user.id,
        email: user.email,
        username: user.username,
        name: user.name,
        role: user.role,
      },
      token,
    })
  } catch (e) {
    console.error('Register error:', e)
    const msg = e instanceof Error ? e.message : ''

    if (msg.includes('readonly') || msg.includes('read-only')) {
      return NextResponse.json(
        {
          success: false,
          error: 'دیتابیس readonly است! لطفاً /api/diagnose رو ببینید',
          errorCode: 'DB_READONLY',
        },
        { status: 500 }
      )
    }

    return NextResponse.json(
      { success: false, error: 'خطا در ثبت‌نام: ' + msg.substring(0, 150) },
      { status: 500 }
    )
  }
}
