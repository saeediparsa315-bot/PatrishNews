import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/stats/public - آمار عمومی سایت (بدون نیاز به auth)
export async function GET() {
  try {
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)

    const [totalArticles, totalUsers, totalViewsAgg, todayArticles] = await Promise.all([
      db.article.count({ where: { status: 'PUBLISHED' } }),
      db.user.count(),
      db.article.aggregate({ _sum: { viewCount: true } }),
      db.article.count({
        where: {
          status: 'PUBLISHED',
          publishedAt: { gte: today, lt: tomorrow },
        },
      }),
    ])

    return NextResponse.json({
      success: true,
      data: {
        totalArticles,
        totalUsers,
        totalViews: totalViewsAgg._sum.viewCount || 0,
        todayArticles,
      },
    })
  } catch (e) {
    console.error('GET /api/stats/public error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
