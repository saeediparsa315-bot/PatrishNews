import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'

// GET /api/stats - Dashboard statistics (admin only)
export async function GET(req: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user || (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 403 })
    }

    const { searchParams } = new URL(req.url)
    const range = searchParams.get('range') || '30' // days

    const days = parseInt(range)
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - days)

    const [
      totalUsers,
      totalArticles,
      publishedArticles,
      draftArticles,
      totalComments,
      pendingComments,
      totalCategories,
      totalTags,
      totalBookmarks,
      totalLikes,
      totalViewsAgg,
    ] = await Promise.all([
      db.user.count(),
      db.article.count(),
      db.article.count({ where: { status: 'PUBLISHED' } }),
      db.article.count({ where: { status: 'DRAFT' } }),
      db.comment.count(),
      db.comment.count({ where: { status: 'PENDING' } }),
      db.category.count(),
      db.tag.count(),
      db.bookmark.count(),
      db.like.count(),
      db.article.aggregate({ _sum: { viewCount: true } }),
    ])

    // Recent users (last 5)
    const recentUsers = await db.user.findMany({
      select: {
        id: true, username: true, name: true, email: true, role: true, createdAt: true,
      },
      orderBy: { createdAt: 'desc' },
      take: 5,
    })

    // Top viewed articles
    const topArticles = await db.article.findMany({
      where: { status: 'PUBLISHED' },
      select: {
        id: true, title: true, slug: true, viewCount: true, likeCount: true, commentCount: true,
        publishedAt: true,
        category: { select: { name: true, slug: true, color: true } },
      },
      orderBy: { viewCount: 'desc' },
      take: 5,
    })

    // Articles per day (last N days)
    const articlesPerDay: { date: string; count: number }[] = []
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date()
      d.setDate(d.getDate() - i)
      d.setHours(0, 0, 0, 0)
      const next = new Date(d)
      next.setDate(next.getDate() + 1)
      const count = await db.article.count({
        where: {
          publishedAt: { gte: d, lt: next },
          status: 'PUBLISHED',
        },
      })
      articlesPerDay.push({
        date: d.toISOString().split('T')[0],
        count,
      })
    }

    // Views per day (sum of views of articles published that day - approximate)
    const viewsPerDay: { date: string; count: number }[] = []
    for (let i = days - 1; i >= 0; i--) {
      const d = new Date()
      d.setDate(d.getDate() - i)
      d.setHours(0, 0, 0, 0)
      const next = new Date(d)
      next.setDate(next.getDate() + 1)
      const agg = await db.article.aggregate({
        where: { publishedAt: { gte: d, lt: next } },
        _sum: { viewCount: true },
      })
      viewsPerDay.push({
        date: d.toISOString().split('T')[0],
        count: agg._sum.viewCount || 0,
      })
    }

    // Articles per category
    const categories = await db.category.findMany({
      select: {
        id: true, name: true, color: true,
        _count: { select: { articles: { where: { status: 'PUBLISHED' } } } },
      },
      orderBy: { order: 'asc' },
    })

    return NextResponse.json({
      success: true,
      data: {
        counts: {
          users: totalUsers,
          articles: totalArticles,
          publishedArticles,
          draftArticles,
          comments: totalComments,
          pendingComments,
          categories: totalCategories,
          tags: totalTags,
          bookmarks: totalBookmarks,
          likes: totalLikes,
          totalViews: totalViewsAgg._sum.viewCount || 0,
        },
        recentUsers,
        topArticles,
        articlesPerDay,
        viewsPerDay,
        categories,
      },
    })
  } catch (e) {
    console.error('GET /api/stats error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
