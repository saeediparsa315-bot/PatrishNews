import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { logAction } from '@/lib/settings'

// PUT /api/articles/layout - ذخیره چیدمان دستی صفحه اصلی
export async function PUT(req: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json(
        { success: false, error: 'فقط سوپر ادمین' },
        { status: 403 }
      )
    }

    const body = await req.json()
    const { updates } = body as {
      updates: Array<{ id: string; slug: string; position: number; layoutMode: string }>
    }

    if (!Array.isArray(updates)) {
      return NextResponse.json(
        { success: false, error: 'پارامتر updates نامعتبر' },
        { status: 400 }
      )
    }

    // اعمال به‌روزرسانی‌ها
    for (const update of updates) {
      await db.article.update({
        where: { id: update.id },
        data: {
          position: Number(update.position),
          layoutMode: update.layoutMode,
        },
      })
    }

    await logAction(user.id, 'UPDATE', 'LAYOUT', null, `Updated ${updates.length} articles`)

    return NextResponse.json({ success: true })
  } catch (e) {
    console.error('PUT /api/articles/layout error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
