import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser, canPostNews } from '@/lib/auth'
import { slugify, calculateReadingTime, stripHtml } from '@/lib/persian'
import { logAction } from '@/lib/settings'

// GET /api/articles/[slug] - Get single article by slug
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params
    const user = await getCurrentUser()
    const isAdmin = user && (user.role === 'ADMIN' || user.role === 'SUPER_ADMIN')

    const article = await db.article.findUnique({
      where: { slug },
      include: {
        category: { select: { id: true, name: true, slug: true, color: true, icon: true } },
        author: { select: { id: true, username: true, name: true, avatar: true } },
        tags: { select: { id: true, name: true, slug: true, color: true } },
        comments: {
          where: { status: 'APPROVED', parentId: null },
          include: {
            user: { select: { id: true, username: true, name: true, avatar: true } },
            replies: {
              where: { status: 'APPROVED' },
              include: {
                user: { select: { id: true, username: true, name: true, avatar: true } },
              },
              orderBy: { createdAt: 'asc' },
            },
          },
          orderBy: { createdAt: 'desc' },
        },
      },
    })

    if (!article) {
      return NextResponse.json({ success: false, error: 'یافت نشد' }, { status: 404 })
    }

    // If article is not published and user is not admin
    if (article.status !== 'PUBLISHED' && !isAdmin) {
      return NextResponse.json({ success: false, error: 'یافت نشد' }, { status: 404 })
    }

    // Increment view count
    await db.article.update({
      where: { id: article.id },
      data: { viewCount: { increment: 1 } },
    })

    // Check if user liked/bookmarked
    let userInteractions: { liked: boolean; bookmarked: boolean } | null = null
    if (user) {
      const [liked, bookmarked] = await Promise.all([
        db.like.findUnique({
          where: { userId_articleId: { userId: user.id, articleId: article.id } },
        }),
        db.bookmark.findUnique({
          where: { userId_articleId: { userId: user.id, articleId: article.id } },
        }),
      ])
      userInteractions = { liked: !!liked, bookmarked: !!bookmarked }
    }

    return NextResponse.json({
      success: true,
      data: { ...article, userInteractions },
    })
  } catch (e) {
    console.error('GET /api/articles/[slug] error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

// PUT /api/articles/[slug] - Update article (SUPER_ADMIN only)
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params
    const user = await getCurrentUser()
    // درخواست ۱۱: فقط سوپر ادمین می‌تواند خبر را ویرایش کند
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json(
        { success: false, error: 'فقط سوپر ادمین می‌تواند خبر را ویرایش کند' },
        { status: 403 }
      )
    }

    const body = await req.json()
    const article = await db.article.findUnique({ where: { slug } })
    if (!article) {
      return NextResponse.json({ success: false, error: 'یافت نشد' }, { status: 404 })
    }

    const updateData: Record<string, unknown> = {}
    if (body.title !== undefined) {
      updateData.title = body.title
      updateData.slug = slugify(body.title)
    }
    if (body.excerpt !== undefined) updateData.excerpt = body.excerpt || null
    if (body.content !== undefined) {
      updateData.content = body.content || ''
      // اگر زمان مطالعه دستی تنظیم نشده بود، محاسبه خودکار
      if (body.readingTime === undefined) {
        updateData.readingTime = calculateReadingTime(stripHtml(body.content || ''))
      }
    }
    if (body.coverImage !== undefined) updateData.coverImage = body.coverImage || null
    if (body.categoryId !== undefined) updateData.categoryId = body.categoryId
    if (body.isFeatured !== undefined) updateData.isFeatured = Boolean(body.isFeatured)
    if (body.isBreaking !== undefined) updateData.isBreaking = Boolean(body.isBreaking)
    if (body.isHomepage !== undefined) updateData.isHomepage = Boolean(body.isHomepage)
    if (body.isMainHeadline !== undefined) {
      // درخواست ۱۲: فقط یک خبر می‌تواند mainHeadline باشد
      if (body.isMainHeadline) {
        await db.article.updateMany({
          where: { isMainHeadline: true, NOT: { id: article.id } },
          data: { isMainHeadline: false },
        })
      }
      updateData.isMainHeadline = Boolean(body.isMainHeadline)
    }
    // فیلدهای چیدمان
    if (body.layoutMode !== undefined) {
      updateData.layoutMode = body.layoutMode
      // اگر به MANUAL تغییر کرد و position ست نشده، position رو 0 کن
      if (body.layoutMode === 'MANUAL' && body.position === undefined) {
        updateData.position = 0
      }
    }
    if (body.displayOrder !== undefined) updateData.displayOrder = Number(body.displayOrder)
    if (body.position !== undefined) {
      const newPos = Number(body.position)
      // محدودیت ۵ خبر دستی
      if (newPos > 5) {
        return NextResponse.json(
          { success: false, error: 'موقعیت دستی باید بین ۱ تا ۵ باشد' },
          { status: 400 }
        )
      }
      // اگر موقعیت تکراری باشه، خبر دیگه‌ای که اون موقعیت رو داره به 0 تغییر بده
      if (newPos > 0) {
        // شمارش اخبار دستی فعلی (به‌جز این خبر)
        const manualCount = await db.article.count({
          where: {
            layoutMode: 'MANUAL',
            position: { gt: 0 },
            status: 'PUBLISHED',
            isHomepage: true,
            NOT: { id: article.id },
          },
        })
        // اگر این خبر قبلاً دستی نبوده و ۵ خبر دستی داریم
        if (article.layoutMode !== 'MANUAL' && manualCount >= 5) {
          return NextResponse.json(
            { success: false, error: 'حداکثر ۵ خبر دستی مجاز است. لطفاً یکی از اخبار دستی موجود را به حالت پیش‌فرض تغییر دهید.' },
            { status: 400 }
          )
        }
        await db.article.updateMany({
          where: { position: newPos, layoutMode: 'MANUAL', NOT: { id: article.id } },
          data: { position: 0 },
        })
      }
      updateData.position = newPos
    }
    if (body.readingTime !== undefined) updateData.readingTime = Number(body.readingTime)
    if (body.scheduledAt !== undefined) {
      updateData.scheduledAt = body.scheduledAt ? new Date(body.scheduledAt) : null
    }
    if (body.metaTitle !== undefined) updateData.metaTitle = body.metaTitle || null
    if (body.metaDescription !== undefined) updateData.metaDescription = body.metaDescription || null
    if (body.metaKeywords !== undefined) updateData.metaKeywords = body.metaKeywords || null
    if (body.status !== undefined) {
      updateData.status = body.status
      if (body.status === 'PUBLISHED' && !article.publishedAt) {
        updateData.publishedAt = new Date()
      }
    }
    if (body.tags !== undefined) {
      // Disconnect all existing tags then connect new ones
      await db.article.update({
        where: { id: article.id },
        data: { tags: { set: [] } },
      })
      if (body.tags.length > 0) {
        updateData.tags = { connect: body.tags.map((t: { id?: string }) => ({ id: t.id })) }
      }
    }

    const updated = await db.article.update({
      where: { id: article.id },
      data: updateData,
      include: {
        category: true,
        author: { select: { id: true, username: true, name: true } },
        tags: true,
      },
    })

    await logAction(user.id, 'UPDATE', 'ARTICLE', article.id, `Title: ${updated.title}`)

    return NextResponse.json({ success: true, data: updated })
  } catch (e) {
    console.error('PUT /api/articles/[slug] error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

// DELETE /api/articles/[slug] - SUPER_ADMIN only
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params
    const user = await getCurrentUser()
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json(
        { success: false, error: 'فقط سوپر ادمین می‌تواند خبر را حذف کند' },
        { status: 403 }
      )
    }

    const article = await db.article.findUnique({ where: { slug } })
    if (!article) {
      return NextResponse.json({ success: false, error: 'یافت نشد' }, { status: 404 })
    }

    await db.article.delete({ where: { id: article.id } })
    await logAction(user.id, 'DELETE', 'ARTICLE', article.id, `Title: ${article.title}`)

    return NextResponse.json({ success: true })
  } catch (e) {
    console.error('DELETE /api/articles/[slug] error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
