import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/articles/featured - Featured articles
export async function GET() {
  try {
    const articles = await db.article.findMany({
      where: { status: 'PUBLISHED', isFeatured: true },
      include: {
        category: { select: { id: true, name: true, slug: true, color: true, icon: true } },
        author: { select: { id: true, username: true, name: true } },
      },
      orderBy: { publishedAt: 'desc' },
      take: 6,
    })

    return NextResponse.json({ success: true, data: articles })
  } catch (e) {
    console.error('GET /api/articles/featured error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
