import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser, canPostNews } from '@/lib/auth'
import { slugify, calculateReadingTime, stripHtml } from '@/lib/persian'
import { logAction } from '@/lib/settings'

// GET /api/articles - List articles (public: published only; admin: all)
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = Math.min(parseInt(searchParams.get('limit') || '12'), 50)
    const categorySlug = searchParams.get('category')
    const tagSlug = searchParams.get('tag')
    const search = searchParams.get('search')
    const status = searchParams.get('status')
    const featured = searchParams.get('featured')
    const breaking = searchParams.get('breaking')
    const homepage = searchParams.get('homepage')
    const mainHeadline = searchParams.get('mainHeadline')
    const sortBy = searchParams.get('sortBy') || 'publishedAt'

    const user = await getCurrentUser()
    const isAdmin = user && (user.role === 'ADMIN' || user.role === 'SUPER_ADMIN')

    const where: Record<string, unknown> = {}

    // Filter by status
    if (status && isAdmin) {
      where.status = status
    } else {
      where.status = 'PUBLISHED'
    }

    if (categorySlug) {
      where.category = { slug: categorySlug }
    }

    if (tagSlug) {
      where.tags = { some: { slug: tagSlug } }
    }

    if (search) {
      where.OR = [
        { title: { contains: search } },
        { excerpt: { contains: search } },
        { content: { contains: search } },
      ]
    }

    if (featured === 'true') where.isFeatured = true
    if (breaking === 'true') where.isBreaking = true
    if (homepage === 'true') where.isHomepage = true
    if (mainHeadline === 'true') where.isMainHeadline = true

    const orderBy: Record<string, 'asc' | 'desc'> = {}
    if (sortBy === 'views') orderBy.viewCount = 'desc'
    else if (sortBy === 'likes') orderBy.likeCount = 'desc'
    else if (sortBy === 'title') orderBy.title = 'asc'
    else orderBy.publishedAt = 'desc'

    const [total, articles] = await Promise.all([
      db.article.count({ where }),
      db.article.findMany({
        where,
        include: {
          category: { select: { id: true, name: true, slug: true, color: true, icon: true } },
          author: { select: { id: true, username: true, name: true, avatar: true } },
          tags: { select: { id: true, name: true, slug: true, color: true } },
        },
        orderBy,
        skip: (page - 1) * limit,
        take: limit,
      }),
    ])

    return NextResponse.json({
      success: true,
      data: articles,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    })
  } catch (e) {
    console.error('GET /api/articles error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

// POST /api/articles - Create article (SUPER_ADMIN only)
export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser()
    // درخواست ۱۱: فقط سوپر ادمین می‌تواند خبر بسازد
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json(
        { success: false, error: 'فقط سوپر ادمین می‌تواند خبر ایجاد کند' },
        { status: 403 }
      )
    }

    const body = await req.json()
    const {
      title, excerpt, content, coverImage, categoryId, tags,
      status, isFeatured, isBreaking, isHomepage, isMainHeadline,
      layoutMode, displayOrder, position, readingTime,
      scheduledAt, metaTitle, metaDescription, metaKeywords,
    } = body

    if (!title || !categoryId) {
      return NextResponse.json(
        { success: false, error: 'عنوان و دسته‌بندی الزامی هستند' },
        { status: 400 }
      )
    }

    // Verify category exists
    const category = await db.category.findUnique({ where: { id: categoryId } })
    if (!category) {
      return NextResponse.json({ success: false, error: 'دسته‌بندی یافت نشد' }, { status: 400 })
    }

    const slug = slugify(title)
    const finalStatus = status || 'DRAFT'
    const publishedAt = finalStatus === 'PUBLISHED' ? new Date() : null

    // درخواست ۱۲: فقط یک خبر می‌تواند mainHeadline باشد
    if (isMainHeadline) {
      await db.article.updateMany({
        where: { isMainHeadline: true },
        data: { isMainHeadline: false },
      })
    }

    // اگر موقعیت دستی انتخاب شده، مطمئن شو موقعیت تکراری نیست
    if (layoutMode === 'MANUAL' && position && position > 0) {
      // محدودیت ۵ خبر دستی
      if (position > 5) {
        return NextResponse.json(
          { success: false, error: 'موقعیت دستی باید بین ۱ تا ۵ باشد' },
          { status: 400 }
        )
      }
      // شمارش اخبار دستی فعلی
      const manualCount = await db.article.count({
        where: {
          layoutMode: 'MANUAL',
          position: { gt: 0 },
          status: 'PUBLISHED',
          isHomepage: true,
        },
      })
      // چون این خبر جدید هست (POST)، اگر ۵ خبر دستی داریم، اجازه نده
      if (manualCount >= 5) {
        return NextResponse.json(
          { success: false, error: 'حداکثر ۵ خبر دستی مجاز است. لطفاً یکی از اخبار دستی موجود را به حالت پیش‌فرض تغییر دهید.' },
          { status: 400 }
        )
      }
      await db.article.updateMany({
        where: { position: position, layoutMode: 'MANUAL' },
        data: { position: 0 },
      })
    }

    const article = await db.article.create({
      data: {
        title,
        slug,
        excerpt: excerpt || null,
        content: content || '',
        coverImage: coverImage || null,
        categoryId,
        authorId: user.id,
        status: finalStatus,
        isFeatured: Boolean(isFeatured),
        isBreaking: Boolean(isBreaking),
        isHomepage: Boolean(isHomepage),
        isMainHeadline: Boolean(isMainHeadline),
        layoutMode: layoutMode || 'DEFAULT',
        displayOrder: Number(displayOrder) || 0,
        position: Number(position) || 0,
        readingTime: readingTime ? Number(readingTime) : calculateReadingTime(stripHtml(content || '')),
        scheduledAt: scheduledAt ? new Date(scheduledAt) : null,
        publishedAt,
        metaTitle: metaTitle || null,
        metaDescription: metaDescription || null,
        metaKeywords: metaKeywords || null,
        tags: tags && tags.length > 0
          ? { connect: tags.map((t: { id?: string; name: string }) => ({ id: t.id })) }
          : undefined,
      },
      include: {
        category: true,
        author: { select: { id: true, username: true, name: true } },
        tags: true,
      },
    })

    await logAction(user.id, 'CREATE', 'ARTICLE', article.id, `Title: ${title}`)

    return NextResponse.json({ success: true, data: article })
  } catch (e) {
    console.error('POST /api/articles error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
