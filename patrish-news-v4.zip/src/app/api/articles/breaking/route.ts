import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/articles/breaking - Breaking news
export async function GET() {
  try {
    const articles = await db.article.findMany({
      where: { status: 'PUBLISHED', isBreaking: true },
      select: {
        id: true,
        title: true,
        slug: true,
        publishedAt: true,
        category: { select: { name: true, slug: true, color: true } },
      },
      orderBy: { publishedAt: 'desc' },
      take: 10,
    })

    return NextResponse.json({ success: true, data: articles })
  } catch (e) {
    console.error('GET /api/articles/breaking error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
