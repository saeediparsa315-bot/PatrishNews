import { NextRequest, NextResponse } from 'next/server'
import { getCurrentUser } from '@/lib/auth'
import { writeFile, mkdir, stat, chmod } from 'fs/promises'
import { existsSync } from 'fs'
import { join, extname } from 'path'
import { randomBytes } from 'crypto'

/**
 * POST /api/upload - آپلود تصویر
 *
 * ذخیره در: process.cwd()/uploads/filename
 * URL برگشتی: /api/files/filename (همیشه)
 *
 * نکته: خودکار permission رو درست می‌کنه
 */

const ALLOWED_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.svg', '.bmp', '.ico']
const MAX_FILE_SIZE = 15 * 1024 * 1024 // ۱۵ مگابایت

const UPLOADS_DIR = join(process.cwd(), 'uploads')

/**
 * اطمینان از قابل نوشتن بودن پوشه uploads
 */
async function ensureUploadsWritable(): Promise<boolean> {
  try {
    if (!existsSync(UPLOADS_DIR)) {
      await mkdir(UPLOADS_DIR, { recursive: true })
    }

    // chmod 777
    try { await chmod(UPLOADS_DIR, 0o777) } catch {}

    // تست
    const testFile = join(UPLOADS_DIR, '.write_test_' + Date.now())
    await writeFile(testFile, 'test')
    const { unlink } = await import('fs/promises')
    await unlink(testFile)
    return true
  } catch (e) {
    console.error('[Upload] پوشه uploads قابل نوشتن نیست:', (e as Error).message)
    return false
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'برای آپلود تصویر وارد شوید' },
        { status: 401 }
      )
    }

    const formData = await req.formData()
    const file = formData.get('file') as File | null

    if (!file) {
      return NextResponse.json(
        { success: false, error: 'فایلی ارسال نشده' },
        { status: 400 }
      )
    }

    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json(
        { success: false, error: `حجم فایل نباید بیشتر از ${MAX_FILE_SIZE / 1024 / 1024} مگابایت باشد` },
        { status: 400 }
      )
    }

    const ext = extname(file.name).toLowerCase()
    if (!ALLOWED_EXTENSIONS.includes(ext)) {
      return NextResponse.json(
        { success: false, error: 'فرمت فایل مجاز نیست. فرمت‌های مجاز: ' + ALLOWED_EXTENSIONS.join(', ') },
        { status: 400 }
      )
    }

    // اطمینان از قابل نوشتن بودن
    const writable = await ensureUploadsWritable()
    if (!writable) {
      return NextResponse.json(
        {
          success: false,
          error: `پوشه uploads قابل نوشتن نیست: ${UPLOADS_DIR}. اجرا کنید: chmod -R 777 uploads`,
        },
        { status: 500 }
      )
    }

    // تولید نام یکتا
    const randomName = randomBytes(16).toString('hex')
    const timestamp = Date.now()
    const filename = `${timestamp}_${randomName}${ext}`

    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)

    // ذخیره فایل
    const filePath = join(UPLOADS_DIR, filename)
    await writeFile(filePath, buffer)

    // chmod فایل
    try { await chmod(filePath, 0o666) } catch {}

    // verify
    try {
      const stats = await stat(filePath)
      if (stats.size !== buffer.length) {
        throw new Error(`حجم فایل ذخیره شده (${stats.size}) با حجم اصلی (${buffer.length}) مطابقت ندارد`)
      }
    } catch (e) {
      return NextResponse.json(
        { success: false, error: 'فایل ذخیره شد ولی verify نشد: ' + (e as Error).message },
        { status: 500 }
      )
    }

    console.log(`[Upload] ${user.email} آپلود کرد: ${filename} (${file.size} bytes)`)

    return NextResponse.json({
      success: true,
      data: {
        url: `/api/files/${filename}`,
        filename,
        originalName: file.name,
        size: file.size,
      },
    })
  } catch (e) {
    console.error('[Upload] خطا:', e)
    return NextResponse.json(
      { success: false, error: 'خطا در آپلود: ' + (e instanceof Error ? e.message : '') },
      { status: 500 }
    )
  }
}

export async function GET() {
  let uploadsWritable = false
  let uploadsExists = false
  let uploadsMode = ''
  try {
    if (!existsSync(UPLOADS_DIR)) {
      await mkdir(UPLOADS_DIR, { recursive: true })
    }
    uploadsExists = true

    try { await chmod(UPLOADS_DIR, 0o777) } catch {}

    const stat = await import('fs/promises').then(m => m.stat(UPLOADS_DIR))
    uploadsMode = '0o' + (stat.mode & 0o777).toString(8)

    const testFile = join(UPLOADS_DIR, '.write_test_' + Date.now())
    await writeFile(testFile, 'test')
    const { unlink } = await import('fs/promises')
    await unlink(testFile)
    uploadsWritable = true
  } catch (e) {
    console.error('[Upload] diagnostic error:', (e as Error).message)
  }

  return NextResponse.json({
    success: true,
    message: 'Endpoint آپلود فعال است',
    maxFileSize: MAX_FILE_SIZE,
    allowedExtensions: ALLOWED_EXTENSIONS,
    uploadsDir: UPLOADS_DIR,
    uploadsExists,
    uploadsWritable,
    uploadsMode,
    cwd: process.cwd(),
    userInfo: {
      uid: process.getuid?.(),
      gid: process.getgid?.(),
    },
  })
}
