import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'

// GET /api/bookmarks - List user bookmarks
export async function GET() {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 })
    }

    const bookmarks = await db.bookmark.findMany({
      where: { userId: user.id },
      include: {
        article: {
          include: {
            category: { select: { id: true, name: true, slug: true, color: true } },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ success: true, data: bookmarks })
  } catch (e) {
    console.error('GET /api/bookmarks error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

// POST /api/bookmarks - Toggle bookmark
export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'برای ذخیره وارد شوید' }, { status: 401 })
    }

    const body = await req.json()
    const { articleId } = body

    if (!articleId) {
      return NextResponse.json({ success: false, error: 'articleId required' }, { status: 400 })
    }

    const existing = await db.bookmark.findUnique({
      where: { userId_articleId: { userId: user.id, articleId } },
    })

    if (existing) {
      await db.bookmark.delete({ where: { id: existing.id } })
      return NextResponse.json({ success: true, data: { bookmarked: false } })
    } else {
      await db.bookmark.create({
        data: { userId: user.id, articleId },
      })
      return NextResponse.json({ success: true, data: { bookmarked: true } })
    }
  } catch (e) {
    console.error('POST /api/bookmarks error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
