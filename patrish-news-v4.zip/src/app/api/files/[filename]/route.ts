import { NextRequest, NextResponse } from 'next/server'
import { readFile } from 'fs/promises'
import { existsSync } from 'fs'
import { join, extname } from 'path'

/**
 * GET /api/files/[filename] - سرو کردن فایل‌های آپلود شده
 *
 * فقط از process.cwd()/uploads/ فایل می‌خونه.
 */

const MIME_TYPES: Record<string, string> = {
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.svg': 'image/svg+xml',
  '.bmp': 'image/bmp',
  '.ico': 'image/x-icon',
}

const UPLOADS_DIR = join(process.cwd(), 'uploads')

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ filename: string }> }
) {
  try {
    const { filename } = await params

    // جلوگیری از path traversal
    if (!filename || filename.includes('..') || filename.includes('/') || filename.includes('\\')) {
      return NextResponse.json(
        { success: false, error: 'نام فایل نامعتبر' },
        { status: 400 }
      )
    }

    // فقط پسوندهای مجاز
    const ext = extname(filename).toLowerCase()
    if (!MIME_TYPES[ext]) {
      return NextResponse.json(
        { success: false, error: 'نوع فایل مجاز نیست' },
        { status: 400 }
      )
    }

    const filePath = join(UPLOADS_DIR, filename)

    if (!existsSync(filePath)) {
      return NextResponse.json(
        { success: false, error: 'فایل یافت نشد' },
        { status: 404 }
      )
    }

    const fileBuffer = await readFile(filePath)
    const mime = MIME_TYPES[ext]

    const headers = new Headers()
    headers.set('Content-Type', mime)
    headers.set('Cache-Control', 'public, max-age=31536000, immutable')
    headers.set('Content-Length', fileBuffer.length.toString())

    return new NextResponse(fileBuffer, { headers })
  } catch (e) {
    console.error('[Files] خطا:', (e as Error).message?.substring(0, 200))
    return NextResponse.json(
      { success: false, error: 'خطا در خواندن فایل' },
      { status: 500 }
    )
  }
}
