import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { slugify } from '@/lib/persian'
import { logAction } from '@/lib/settings'

// GET /api/categories
export async function GET() {
  try {
    const categories = await db.category.findMany({
      where: { isActive: true },
      include: {
        parent: { select: { id: true, name: true, slug: true } },
        children: {
          where: { isActive: true },
          select: { id: true, name: true, slug: true, color: true, icon: true },
        },
        _count: { select: { articles: { where: { status: 'PUBLISHED' } } } },
      },
      orderBy: { order: 'asc' },
    })

    return NextResponse.json({ success: true, data: categories })
  } catch (e) {
    console.error('GET /api/categories error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

// POST /api/categories
export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ success: false, error: 'فقط سوپر ادمین' }, { status: 403 })
    }

    const body = await req.json()
    const { name, description, color, icon, parentId, order } = body

    if (!name) {
      return NextResponse.json({ success: false, error: 'نام الزامی است' }, { status: 400 })
    }

    const category = await db.category.create({
      data: {
        name,
        slug: slugify(name),
        description: description || null,
        color: color || '#7C3AED',
        icon: icon || null,
        parentId: parentId || null,
        order: order || 0,
      },
    })

    await logAction(user.id, 'CREATE', 'CATEGORY', category.id, `Name: ${name}`)
    return NextResponse.json({ success: true, data: category })
  } catch (e) {
    console.error('POST /api/categories error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
