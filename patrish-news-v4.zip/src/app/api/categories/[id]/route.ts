import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { slugify } from '@/lib/persian'
import { logAction } from '@/lib/settings'

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const user = await getCurrentUser()
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ success: false, error: 'فقط سوپر ادمین' }, { status: 403 })
    }

    const body = await req.json()
    const updateData: Record<string, unknown> = {}
    if (body.name !== undefined) {
      updateData.name = body.name
      updateData.slug = slugify(body.name)
    }
    if (body.description !== undefined) updateData.description = body.description
    if (body.color !== undefined) updateData.color = body.color
    if (body.icon !== undefined) updateData.icon = body.icon
    if (body.order !== undefined) updateData.order = body.order
    if (body.isActive !== undefined) updateData.isActive = Boolean(body.isActive)
    if (body.parentId !== undefined) updateData.parentId = body.parentId || null

    const updated = await db.category.update({ where: { id }, data: updateData })
    await logAction(user.id, 'UPDATE', 'CATEGORY', id)

    return NextResponse.json({ success: true, data: updated })
  } catch (e) {
    console.error('PUT /api/categories/[id] error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const user = await getCurrentUser()
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ success: false, error: 'فقط سوپر ادمین' }, { status: 403 })
    }

    // Check if has articles
    const articleCount = await db.article.count({ where: { categoryId: id } })
    if (articleCount > 0) {
      return NextResponse.json(
        { success: false, error: `این دسته ${articleCount} خبر دارد و قابل حذف نیست` },
        { status: 400 }
      )
    }

    await db.category.delete({ where: { id } })
    await logAction(user.id, 'DELETE', 'CATEGORY', id)

    return NextResponse.json({ success: true })
  } catch (e) {
    console.error('DELETE /api/categories/[id] error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
