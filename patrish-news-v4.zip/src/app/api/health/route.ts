import { NextResponse } from 'next/server'
import { db, ensureSchema, dbInfo } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { existsSync, statSync } from 'fs'

/**
 * GET /api/health - بررسی سلامت سیستم
 * این endpoint برای دیباگ سریع مشکلات هاست استفاده می‌شه
 */
export async function GET() {
  const result: Record<string, unknown> = {
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV,
    cwd: process.cwd(),
  }

  // ۱. اطلاعات دیتابیس
  result.databaseUrl = dbInfo.url
  result.isFallbackPath = dbInfo.isFallback

  // اطلاعات permission پوشه
  if (dbInfo.dir && existsSync(dbInfo.dir)) {
    try {
      const stat = statSync(dbInfo.dir)
      result.dbDirMode = '0o' + (stat.mode & 0o777).toString(8)
      result.dbDirUid = stat.uid
      result.dbDirGid = stat.gid
    } catch {}
  }

  // ۲. بررسی schema
  try {
    await ensureSchema()
    result.schema = '✅ اعمال شد'
  } catch (e) {
    result.schema = '❌ ' + (e as Error).message.substring(0, 200)
  }

  // ۳. تست query و write
  try {
    const userCount = await db.user.count()
    result.userCount = userCount

    const categoryCount = await db.category.count()
    result.categoryCount = categoryCount

    const sessionCount = await db.session.count()
    result.sessionCount = sessionCount

    // تست write
    const admin = await db.user.findFirst({ where: { role: 'SUPER_ADMIN' } })
    if (admin) {
      try {
        await db.auditLog.create({
          data: {
            userId: admin.id,
            action: 'HEALTH_CHECK',
            entity: 'SYSTEM',
          },
        })
        await db.auditLog.deleteMany({ where: { action: 'HEALTH_CHECK' } })
        result.writeTest = '✅ write کار می‌کنه'
      } catch (writeErr) {
        const wmsg = (writeErr as Error).message
        result.writeTest = '❌ ' + wmsg.substring(0, 200)
        if (wmsg.includes('readonly') || wmsg.includes('read-only')) {
          result.criticalError = '🔴 دیتابیس readonly است! این عامل مشکل login/register است'
          result.solution = `اجرا کنید: chmod -R 777 ${dbInfo.dir} && chown -R $(whoami) ${dbInfo.dir}`
        }
      }
    }

    // admin
    const adminUser = await db.user.findFirst({
      where: { role: 'SUPER_ADMIN' },
      select: { email: true, username: true, createdAt: true, isBlocked: true },
    })
    result.superAdmin = adminUser || '❌ وجود ندارد'

    // کاربر فعلی
    const currentUser = await getCurrentUser()
    result.currentUser = currentUser || '❌ لاگین نشده'
  } catch (e) {
    result.error = (e as Error).message
    result.stack = (e as Error).stack?.substring(0, 500)
  }

  return NextResponse.json(result, {
    headers: { 'Content-Type': 'application/json; charset=utf-8' }
  })
}
