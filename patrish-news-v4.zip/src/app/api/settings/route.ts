import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { getSetting, setSetting, DEFAULT_SETTINGS, ensureDefaultSettings } from '@/lib/settings'
import { logAction } from '@/lib/settings'

// GET /api/settings
export async function GET() {
  try {
    await ensureDefaultSettings()
    const settings = await db.siteSetting.findMany()
    const result = Object.fromEntries(settings.map(s => [s.key, s.value]))

    // Merge with defaults
    const merged = { ...DEFAULT_SETTINGS, ...result }

    return NextResponse.json({ success: true, data: merged })
  } catch (e) {
    console.error('GET /api/settings error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}

// PUT /api/settings - Update settings (super admin only)
export async function PUT(req: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user || user.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ success: false, error: 'فقط سوپر ادمین' }, { status: 403 })
    }

    const body = await req.json()
    const allowedKeys = Object.keys(DEFAULT_SETTINGS)

    for (const [key, value] of Object.entries(body)) {
      if (allowedKeys.includes(key)) {
        await setSetting(key, String(value))
      }
    }

    await logAction(user.id, 'UPDATE', 'SETTINGS', null, `Keys: ${Object.keys(body).join(', ')}`)

    // Return updated settings
    const settings = await db.siteSetting.findMany()
    const result = { ...DEFAULT_SETTINGS, ...Object.fromEntries(settings.map(s => [s.key, s.value])) }

    return NextResponse.json({ success: true, data: result })
  } catch (e) {
    console.error('PUT /api/settings error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
