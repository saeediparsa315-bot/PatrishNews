import { NextRequest, NextResponse } from 'next/server'
import { db, ensureSchema } from '@/lib/db'
import { hashPassword } from '@/lib/auth'
import { cookies } from 'next/headers'
import * as crypto from 'crypto'

/**
 * /api/setup - راه‌اندازی اولیه دیتابیس
 *
 * امنیت:
 * - فقط وقتی دیتابیس خالیه کار می‌کنه (admin نمی‌سازه اگه وجود داشته باشه)
 * - reset و resetPassword فقط با توکن ادمین یا SETUP_TOKEN از env
 *
 * استفاده:
 * - GET /api/setup - ساخت اولیه (اگه خالی باشه)
 * - GET /api/setup?resetPassword=1 - ریست رمز ادمین (نیاز به توکن)
 * - GET /api/setup?reset=1 - ریست کامل (نیاز به توکن)
 */

// ادمین پیش‌فرض
const ADMIN_EMAIL = 'admin@news24.ir'
const ADMIN_PASSWORD = 'admin123'
const ADMIN_USERNAME = 'superadmin'
const ADMIN_NAME = 'مدیر کل'

const DEFAULT_CATEGORIES = [
  { name: 'اخبار جهان', slug: 'world', description: 'آخرین اخبار و تحولات جهان', color: '#06B6D4', icon: 'Globe', order: 1 },
  { name: 'تکنولوژی', slug: 'technology', description: 'اخبار دنیای فناوری و هوش مصنوعی', color: '#7C3AED', icon: 'Cpu', order: 2 },
  { name: 'گیم', slug: 'gaming', description: 'جدیدترین اخبار بازی‌ها و کنسول‌ها', color: '#F43F5E', icon: 'Gamepad2', order: 3 },
  { name: 'سرگرمی', slug: 'entertainment', description: 'اخبار سینما، موسیقی و هنر', color: '#F59E0B', icon: 'Clapperboard', order: 4 },
  { name: 'علمی', slug: 'science', description: 'کشفیات و اخبار علمی', color: '#10B981', icon: 'FlaskConical', order: 5 },
  { name: 'ورزشی', slug: 'sports', description: 'اخبار ورزشی داخلی و خارجی', color: '#3B82F6', icon: 'Trophy', order: 6 },
  { name: 'سیاسی', slug: 'politics', description: 'اخبار سیاسی داخلی و خارجی', color: '#DC2626', icon: 'Landmark', order: 7 },
]

const DEFAULT_TAGS = [
  { name: 'هوش مصنوعی', slug: 'ai', color: '#7C3AED' },
  { name: 'آیفون', slug: 'iphone', color: '#06B6D4' },
  { name: 'پلی‌استیشن', slug: 'playstation', color: '#3B82F6' },
  { name: 'اکس‌باکس', slug: 'xbox', color: '#10B981' },
  { name: 'گیمینگ', slug: 'gaming-tag', color: '#F43F5E' },
  { name: 'سینما', slug: 'cinema', color: '#F59E0B' },
  { name: 'علم', slug: 'sci', color: '#14B8A6' },
  { name: 'فضا', slug: 'space', color: '#8B5CF6' },
  { name: 'اقتصاد', slug: 'economy', color: '#F97316' },
  { name: 'سلامت', slug: 'health', color: '#EC4899' },
]

const DEFAULT_SETTINGS: Record<string, string> = {
  site_name: 'پاتریش نیوز',
  site_description: 'دنیای تکنولوژی، ساده و به‌روز',
  site_logo_text: 'پاتریش',
  primary_color: '#7C3AED',
  accent_color: '#06B6D4',
  footer_text: '© ۱۴۰۵ پاتریش نیوز - تمامی حقوق محفوظ است',
  social_twitter: '',
  social_telegram: 'https://t.me/PCnewsF',
  social_instagram: '',
  social_youtube: '',
  contact_email: 'info@patrishnews.ir',
  comments_enabled: 'true',
  comments_require_approval: 'true',
  default_seo_title: 'پاتریش نیوز | اخبار روز دنیا، تکنولوژی و گیم',
  default_seo_description: 'جدیدترین اخبار جهان، تکنولوژی، گیم، علم، ورزش و سرگرمی',
  default_seo_keywords: 'اخبار,تکنولوژی,گیم,علم,ورزش,سرگرمی,پاتریش نیوز',
}

/**
 * بررسی دسترسی برای عملیات خطرناک
 */
async function canPerformDangerousOps(req: NextRequest): Promise<boolean> {
  // اگه SETUP_TOKEN در env تنظیم شده، با query token چک کن
  const setupToken = process.env.SETUP_TOKEN
  if (setupToken) {
    const queryToken = new URL(req.url).searchParams.get('token')
    if (queryToken === setupToken) return true
  }

  // اگه کاربر ادمین لاگین شده
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get('news_session')?.value
    if (token) {
      const session = await db.session.findUnique({
        where: { token },
        include: { user: { select: { role: true } } },
      })
      if (session && session.user.role === 'SUPER_ADMIN') {
        return true
      }
    }
  } catch {}

  return false
}

export async function GET(req: NextRequest) {
  try {
    await ensureSchema()

    const results: string[] = []
    const { searchParams } = new URL(req.url)
    const reset = searchParams.get('reset') === '1'
    const resetPassword = searchParams.get('resetPassword') === '1'

    // عملیات خطرناک نیاز به احراز هویت دارن
    if (reset || resetPassword) {
      const allowed = await canPerformDangerousOps(req)
      if (!allowed) {
        return NextResponse.json({
          success: false,
          error: 'دسترسی غیرمجاز. برای reset، یا به عنوان سوپر ادمین لاگین کنید یا SETUP_TOKEN را در env تنظیم کنید و ?token=XXX را اضافه کنید.',
          hint: 'برای تنظیم SETUP_TOKEN، متغیر محیطی SETUP_TOKEN را در .env قرار دهید و سپس /api/setup?resetPassword=1&token=YOUR_TOKEN را صدا بزنید.',
        }, { status: 403, headers: { 'Content-Type': 'application/json; charset=utf-8' } })
      }

      if (resetPassword) {
        // ریست رمز ادمین
        const admin = await db.user.findFirst({
          where: { role: 'SUPER_ADMIN' },
        })

        if (admin) {
          await db.user.update({
            where: { id: admin.id },
            data: { passwordHash: hashPassword(ADMIN_PASSWORD), isBlocked: false },
          })
          results.push(`✅ رمز سوپر ادمین ریست شد: ${admin.email} / ${ADMIN_PASSWORD}`)
        } else {
          // اگه admin نبود، بساز
          await db.user.create({
            data: {
              email: ADMIN_EMAIL,
              username: ADMIN_USERNAME,
              passwordHash: hashPassword(ADMIN_PASSWORD),
              name: ADMIN_NAME,
              role: 'SUPER_ADMIN',
            },
          })
          results.push(`✅ سوپر ادمین ساخته شد: ${ADMIN_EMAIL} / ${ADMIN_PASSWORD}`)
        }

        // پاک کردن سشن‌های قدیمی
        await db.session.deleteMany({}).catch(() => {})
        results.push('✅ تمام سشن‌های قدیمی پاک شدند')
      }

      if (reset) {
        // ریست کامل - فقط تنظیمات و دسته‌ها رو دوباره می‌سازه
        // (کاربران پاک نمی‌شن)
        const catCount = await db.category.count()
        if (catCount === 0) {
          for (const cat of DEFAULT_CATEGORIES) {
            try {
              await db.category.create({ data: cat })
            } catch {}
          }
          results.push(`✅ ${DEFAULT_CATEGORIES.length} دسته‌بندی ساخته شد`)
        }

        const tagCount = await db.tag.count()
        if (tagCount === 0) {
          for (const tag of DEFAULT_TAGS) {
            try {
              await db.tag.create({ data: tag })
            } catch {}
          }
          results.push(`✅ ${DEFAULT_TAGS.length} برچسب ساخته شد`)
        }

        const settingCount = await db.siteSetting.count()
        if (settingCount === 0) {
          for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
            try {
              await db.siteSetting.create({ data: { key, value } })
            } catch {}
          }
          results.push('✅ تنظیمات سایت ساخته شد')
        }
      }

      return NextResponse.json({
        success: true,
        results,
        login: { email: ADMIN_EMAIL, password: ADMIN_PASSWORD },
      }, { headers: { 'Content-Type': 'application/json; charset=utf-8' } })
    }

    // عملیات عادی setup (ایمن - فقط اگه خالی باشه)
    const userCount = await db.user.count().catch(() => -1)

    if (userCount === -1) {
      return NextResponse.json({
        success: false,
        error: 'دیتابیس قابل دسترسی نیست.',
        dbUrl: process.env.DATABASE_URL,
      }, { status: 500, headers: { 'Content-Type': 'application/json; charset=utf-8' } })
    }

    results.push(`کاربران فعلی: ${userCount}`)

    // ساخت ادمین اولیه فقط اگه هیچ کاربری وجود نداره
    if (userCount === 0) {
      await db.user.create({
        data: {
          email: ADMIN_EMAIL,
          username: ADMIN_USERNAME,
          passwordHash: hashPassword(ADMIN_PASSWORD),
          name: ADMIN_NAME,
          role: 'SUPER_ADMIN',
        },
      })
      results.push(`✅ سوپر ادمین ساخته شد: ${ADMIN_EMAIL} / ${ADMIN_PASSWORD}`)
    } else {
      results.push(`ℹ️ ادمین از قبل وجود دارد - برای ریست رمز: /api/setup?resetPassword=1`)
    }

    // دسته‌ها
    const catCount = await db.category.count()
    if (catCount === 0) {
      for (const cat of DEFAULT_CATEGORIES) {
        try {
          await db.category.create({ data: cat })
        } catch {}
      }
      results.push(`✅ ${DEFAULT_CATEGORIES.length} دسته‌بندی ساخته شد`)
    } else {
      results.push(`ℹ️ ${catCount} دسته‌بندی موجود است`)
    }

    // برچسب‌ها
    const tagCount = await db.tag.count()
    if (tagCount === 0) {
      for (const tag of DEFAULT_TAGS) {
        try {
          await db.tag.create({ data: tag })
        } catch {}
      }
      results.push(`✅ ${DEFAULT_TAGS.length} برچسب ساخته شد`)
    }

    // تنظیمات
    const settingCount = await db.siteSetting.count()
    if (settingCount === 0) {
      for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
        try {
          await db.siteSetting.create({ data: { key, value } })
        } catch {}
      }
      results.push('✅ تنظیمات سایت ساخته شد')
    }

    return NextResponse.json({
      success: true,
      message: 'راه‌اندازی دیتابیس کامل شد!',
      results,
      login: { email: ADMIN_EMAIL, password: ADMIN_PASSWORD },
      dbUrl: process.env.DATABASE_URL,
      note: 'برای ریست رمز ادمین (نیاز به دسترسی): /api/setup?resetPassword=1&token=SETUP_TOKEN',
      hasSetupToken: !!process.env.SETUP_TOKEN,
    }, { headers: { 'Content-Type': 'application/json; charset=utf-8' } })
  } catch (e) {
    return NextResponse.json({
      success: false,
      error: e instanceof Error ? e.message : 'خطا',
      stack: e instanceof Error ? e.stack?.substring(0, 500) : '',
      dbUrl: process.env.DATABASE_URL,
    }, { status: 500, headers: { 'Content-Type': 'application/json; charset=utf-8' } })
  }
}
