import { NextResponse } from 'next/server'
import { db, ensureSchema, dbInfo } from '@/lib/db'
import { existsSync, statSync, writeFileSync, unlinkSync, mkdirSync, chmodSync } from 'fs'
import { join } from 'path'

/**
 * GET /api/diagnose - دیاگنوستیک کامل سیستم
 *
 * این endpoint دقیقاً می‌گه مشکل کجاست:
 * - مسیر دیتابیس
 * - قابل نوشتن بودن
 * - permission‌ها
 * - schema status
 * - sample query
 */
export async function GET() {
  const result: Record<string, unknown> = {
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV,
    cwd: process.cwd(),
    userInfo: {
      uid: process.getuid?.(),
      gid: process.getgid?.(),
      username: process.env.USER || process.env.LOGNAME,
    },
  }

  // ۱. اطلاعات مسیر دیتابیس
  result.database = {
    url: dbInfo.url,
    dir: dbInfo.dir,
    file: dbInfo.file,
    isFallback: dbInfo.isFallback,
    envVar: process.env.DATABASE_URL,
  }

  // ۲. بررسی پوشه دیتابیس
  if (dbInfo.dir) {
    const dirInfo: Record<string, unknown> = { path: dbInfo.dir }
    try {
      dirInfo.exists = existsSync(dbInfo.dir)
      if (dirInfo.exists) {
        const stat = statSync(dbInfo.dir)
        dirInfo.isDirectory = stat.isDirectory()
        dirInfo.mode = '0o' + (stat.mode & 0o777).toString(8)
        dirInfo.uid = stat.uid
        dirInfo.gid = stat.gid
        dirInfo.writable = tryWriteTest(dbInfo.dir)
      }
    } catch (e) {
      dirInfo.error = (e as Error).message
    }
    result.databaseDir = dirInfo
  }

  // ۳. بررسی فایل دیتابیس
  if (dbInfo.file && existsSync(dbInfo.file)) {
    const fileInfo: Record<string, unknown> = { path: dbInfo.file }
    try {
      const stat = statSync(dbInfo.file)
      fileInfo.size = stat.size
      fileInfo.mode = '0o' + (stat.mode & 0o777).toString(8)
      fileInfo.uid = stat.uid
      fileInfo.gid = stat.gid
      fileInfo.writable = tryWriteTest(dbInfo.file, true)
    } catch (e) {
      fileInfo.error = (e as Error).message
    }
    result.databaseFile = fileInfo
  }

  // ۴. بررسی پوشه uploads
  const uploadsDir = join(process.cwd(), 'uploads')
  const uploadsInfo: Record<string, unknown> = { path: uploadsDir }
  try {
    uploadsInfo.exists = existsSync(uploadsDir)
    if (!uploadsInfo.exists) {
      mkdirSync(uploadsDir, { recursive: true })
      uploadsInfo.createdNow = true
    }
    const stat = statSync(uploadsDir)
    uploadsInfo.mode = '0o' + (stat.mode & 0o777).toString(8)
    uploadsInfo.uid = stat.uid
    uploadsInfo.gid = stat.gid
    uploadsInfo.writable = tryWriteTest(uploadsDir)
  } catch (e) {
    uploadsInfo.error = (e as Error).message
  }
  result.uploads = uploadsInfo

  // ۵. بررسی schema
  try {
    await ensureSchema()
    result.schema = '✅ اعمال شد'
  } catch (e) {
    result.schema = '❌ خطا: ' + (e as Error).message
  }

  // ۶. تست query واقعی
  try {
    const userCount = await db.user.count()
    result.queryTest = {
      status: '✅ query کار می‌کنه',
      userCount,
    }
  } catch (e) {
    const msg = (e as Error).message
    result.queryTest = {
      status: '❌ query خطا داد',
      error: msg.substring(0, 300),
      isReadonlyError: msg.includes('readonly') || msg.includes('read-only'),
    }
  }

  // ۷. تست write واقعی
  try {
    // سعی کن یک session موقت بسازی و پاک کنی
    const testUser = await db.user.findFirst()
    if (testUser) {
      try {
        // سعی کن یک audit log بسازی (این write هست)
        await db.auditLog.create({
          data: {
            userId: testUser.id,
            action: 'DIAGNOSE_TEST',
            entity: 'SYSTEM',
          },
        })
        // پاک کن
        await db.auditLog.deleteMany({
          where: { action: 'DIAGNOSE_TEST' },
        })
        result.writeTest = '✅ write کار می‌کنه'
      } catch (e) {
        const msg = (e as Error).message
        result.writeTest = {
          status: '❌ write خطا داد',
          error: msg.substring(0, 300),
          isReadonlyError: msg.includes('readonly') || msg.includes('read-only'),
          solution: 'پوشه دیتابیس قابل نوشتن نیست. اجرا کنید: chmod -R 777 ' + dbInfo.dir,
        }
      }
    } else {
      result.writeTest = '⏸ skip - کاربری برای تست وجود ندارد'
    }
  } catch (e) {
    result.writeTest = '❌ ' + (e as Error).message
  }

  // ۸. تشخیص خودکار مشکل
  const problems: string[] = []
  const dbDir = result.databaseDir as Record<string, unknown>
  if (dbDir && dbDir.writable === false) {
    problems.push('🔴 پوشه دیتابیس قابل نوشتن نیست')
  }
  if (dbInfo.isFallback) {
    problems.push('🟡 در حال استفاده از مسیر fallback (/tmp) - در restart گم می‌شه')
  }
  const writeTest = result.writeTest
  if (typeof writeTest === 'object' && writeTest !== null && (writeTest as Record<string, unknown>).isReadonlyError) {
    problems.push('🔴 دیتابیس readonly است - نمی‌تونه Session ذخیره کنه')
  }

  result.problems = problems
  result.recommendations = generateRecommendations(result)

  return NextResponse.json(result, {
    headers: { 'Content-Type': 'application/json; charset=utf-8' }
  })
}

function tryWriteTest(path: string, isFile = false): boolean {
  try {
    const testPath = isFile ? path + '.writetest' : join(path, '.write_test_' + Date.now())
    writeFileSync(testPath, 'test')
    unlinkSync(testPath)
    return true
  } catch {
    return false
  }
}

function generateRecommendations(result: Record<string, unknown>): string[] {
  const recs: string[] = []
  const dbDir = result.databaseDir as Record<string, unknown> | undefined
  const dbInfo = result.database as Record<string, unknown> | undefined

  if (dbDir && dbDir.writable === false) {
    recs.push(`اجرای دستور: chmod -R 777 ${dbDir.path}`)
    recs.push(`یا: chown -R $(whoami) ${dbDir.path}`)
  }

  if (dbInfo && dbInfo.isFallback === true) {
    recs.push('مسیر اصلی قابل نوشتن نیست. پوشه db رو قابل نوشتن کنید.')
  }

  if (recs.length === 0) {
    recs.push('✅ همه چیز خوبه - مشکلی پیدا نشد')
  }

  return recs
}
