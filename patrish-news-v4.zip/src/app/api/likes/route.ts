import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'

// POST /api/likes - Toggle like
export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ success: false, error: 'برای لایک وارد شوید' }, { status: 401 })
    }

    const body = await req.json()
    const { articleId } = body

    if (!articleId) {
      return NextResponse.json({ success: false, error: 'articleId required' }, { status: 400 })
    }

    const existing = await db.like.findUnique({
      where: { userId_articleId: { userId: user.id, articleId } },
    })

    if (existing) {
      // Unlike
      await db.like.delete({ where: { id: existing.id } })
      await db.article.update({
        where: { id: articleId },
        data: { likeCount: { decrement: 1 } },
      })
      return NextResponse.json({ success: true, data: { liked: false } })
    } else {
      // Like
      await db.like.create({
        data: { userId: user.id, articleId },
      })
      await db.article.update({
        where: { id: articleId },
        data: { likeCount: { increment: 1 } },
      })
      return NextResponse.json({ success: true, data: { liked: true } })
    }
  } catch (e) {
    console.error('POST /api/likes error:', e)
    return NextResponse.json({ success: false, error: 'Server error' }, { status: 500 })
  }
}
