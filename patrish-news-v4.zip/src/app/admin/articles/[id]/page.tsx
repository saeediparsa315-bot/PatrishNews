import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect, notFound } from 'next/navigation'
import { ArticleForm } from '@/components/admin/article-form'

export const dynamic = 'force-dynamic'

export default async function EditArticlePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params
  const user = await getCurrentUser()
  // درخواست ۱۱: فقط سوپر ادمین می‌تواند خبر را ویرایش کند
  if (!user || user.role !== 'SUPER_ADMIN') {
    redirect('/admin/articles')
  }

  const [article, categories, tags] = await Promise.all([
    db.article.findUnique({
      where: { id },
      include: { tags: true },
    }),
    db.category.findMany({
      where: { isActive: true, parentId: null },
      include: { children: { where: { isActive: true } } },
      orderBy: { order: 'asc' },
    }),
    db.tag.findMany({ orderBy: { name: 'asc' } }),
  ])

  if (!article) notFound()

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold">ویرایش خبر</h1>
        <p className="text-muted-foreground mt-1 line-clamp-1">{article.title}</p>
      </div>
      <ArticleForm
        article={article}
        categories={categories}
        tags={tags}
        selectedTags={article.tags}
      />
    </div>
  )
}
