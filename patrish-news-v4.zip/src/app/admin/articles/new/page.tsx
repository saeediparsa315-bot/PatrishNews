import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { ArticleForm } from '@/components/admin/article-form'

export const dynamic = 'force-dynamic'

export default async function NewArticlePage() {
  const user = await getCurrentUser()
  // درخواست ۱۱: فقط سوپر ادمین می‌تواند خبر بسازد
  if (!user || user.role !== 'SUPER_ADMIN') {
    redirect('/admin/articles')
  }

  const categories = await db.category.findMany({
    where: { isActive: true, parentId: null },
    include: {
      children: { where: { isActive: true } },
    },
    orderBy: { order: 'asc' },
  })

  const tags = await db.tag.findMany({ orderBy: { name: 'asc' } })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold">افزودن خبر جدید</h1>
        <p className="text-muted-foreground mt-1">یک خبر جدید ایجاد کنید (فقط سوپر ادمین)</p>
      </div>
      <ArticleForm categories={categories} tags={tags} />
    </div>
  )
}
