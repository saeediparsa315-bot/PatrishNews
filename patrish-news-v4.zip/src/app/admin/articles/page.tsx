import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import Link from 'next/link'
import { ArticleTable } from '@/components/admin/article-table'
import { Button } from '@/components/ui/button'
import { Plus } from 'lucide-react'
import { formatPersianDate, formatNumber } from '@/lib/persian'

export const dynamic = 'force-dynamic'

export default async function AdminArticlesPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}) {
  const user = await getCurrentUser()
  if (!user || (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) return null

  const sp = await searchParams
  const status = typeof sp.status === 'string' ? sp.status : undefined
  const categoryId = typeof sp.category === 'string' ? sp.category : undefined

  const where: Record<string, unknown> = {}
  if (status) where.status = status
  if (categoryId) where.categoryId = categoryId

  const [articles, categories] = await Promise.all([
    db.article.findMany({
      where,
      include: {
        category: { select: { id: true, name: true, slug: true, color: true, icon: true } },
        author: { select: { id: true, username: true, name: true, avatar: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 100,
    }),
    db.category.findMany({
      where: { isActive: true },
      select: { id: true, name: true, slug: true, color: true },
      orderBy: { order: 'asc' },
    }),
  ])

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold">مدیریت اخبار</h1>
          <p className="text-muted-foreground mt-1">
            مجموع: {formatNumber(articles.length)} خبر
          </p>
        </div>
        <Link href="/admin/articles/new">
          <Button>
            <Plus className="size-4 ml-2" />
            افزودن خبر جدید
          </Button>
        </Link>
      </div>

      <ArticleTable articles={articles} categories={categories} />
    </div>
  )
}
