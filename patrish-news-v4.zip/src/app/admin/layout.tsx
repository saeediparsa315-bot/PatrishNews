import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { AdminSidebar } from '@/components/admin/sidebar'
import { AdminTopbar } from '@/components/admin/topbar'
import { ensureDefaultSettings } from '@/lib/settings'

export const metadata = { title: 'پنل مدیریت | پاتریش نیوز' }

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  await ensureDefaultSettings()
  const user = await getCurrentUser()

  if (!user) redirect('/login')
  if (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN') redirect('/')

  const [categories, settings] = await Promise.all([
    db.category.findMany({
      where: { isActive: true, parentId: null },
      orderBy: { order: 'asc' },
      select: { id: true, name: true, slug: true, color: true, icon: true, _count: { select: { articles: true } } },
    }),
    db.siteSetting.findMany(),
  ])

  const settingsObj = Object.fromEntries(settings.map(s => [s.key, s.value]))

  return (
    <div className="min-h-screen bg-muted/20" dir="rtl">
      <div className="flex">
        <AdminSidebar user={user} categories={categories} />
        <div className="flex-1 min-w-0 lg:pr-72">
          <AdminTopbar user={user} siteName={settingsObj.site_name || 'پاتریش نیوز'} />
          <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
            {children}
          </main>
        </div>
      </div>
    </div>
  )
}
