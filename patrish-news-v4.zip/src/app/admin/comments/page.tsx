import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { CommentsManager } from '@/components/admin/comments-manager'

export const dynamic = 'force-dynamic'

export default async function AdminCommentsPage({
  searchParams,
}: {
  searchParams: Promise<{ [key: string]: string | string[] | undefined }>
}) {
  const user = await getCurrentUser()
  if (!user || (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) redirect('/login')

  const sp = await searchParams
  const status = typeof sp.status === 'string' ? sp.status : undefined

  const where: Record<string, unknown> = {}
  if (status) where.status = status

  const comments = await db.comment.findMany({
    where,
    include: {
      user: { select: { id: true, username: true, name: true, avatar: true } },
      article: { select: { id: true, title: true, slug: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 100,
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold">مدیریت نظرات</h1>
        <p className="text-muted-foreground mt-1">بررسی و تأیید نظرات کاربران</p>
      </div>
      <CommentsManager comments={comments} />
    </div>
  )
}
