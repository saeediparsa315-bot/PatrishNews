import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { BackupManager } from '@/components/admin/backup-manager'

export const dynamic = 'force-dynamic'

export default async function AdminBackupPage() {
  const user = await getCurrentUser()
  if (!user || user.role !== 'SUPER_ADMIN') {
    redirect('/admin')
  }

  const counts = {
    users: await db.user.count(),
    articles: await db.article.count({ where: { status: 'PUBLISHED' } }),
    categories: await db.category.count(),
    tags: await db.tag.count(),
    comments: await db.comment.count(),
    likes: await db.like.count(),
    bookmarks: await db.bookmark.count(),
    auditLogs: await db.auditLog.count(),
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold">بک‌آپ‌گیری و بازیابی</h1>
        <p className="text-muted-foreground mt-1">
          از کل پایگاه داده بک‌آپ بگیرید یا از فایل بک‌آپ بازیابی کنید
        </p>
      </div>
      <BackupManager counts={counts} />
    </div>
  )
}
