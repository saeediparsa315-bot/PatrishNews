import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { LayoutEditor } from '@/components/admin/layout-editor'

export const dynamic = 'force-dynamic'

export default async function AdminLayoutPage() {
  const user = await getCurrentUser()
  // ادمین‌ها هم می‌توانند چیدمان را ببینند ولی فقط سوپر ادمین می‌تواند ذخیره کند
  if (!user || (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) {
    redirect('/admin')
  }

  const articles = await db.article.findMany({
    where: {
      status: 'PUBLISHED',
      publishedAt: { gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
    },
    include: {
      category: { select: { id: true, name: true, slug: true, color: true, icon: true } },
      author: { select: { id: true, username: true, name: true, avatar: true } },
    },
    orderBy: { publishedAt: 'desc' },
    take: 50,
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold">چیدمان دستی صفحه اصلی</h1>
        <p className="text-muted-foreground mt-1">
          با drag &amp; drop کارت‌ها را در موقعیت‌های ۱ تا ۷ قرار دهید
        </p>
      </div>
      <LayoutEditor articles={articles} canEdit={user.role === 'SUPER_ADMIN'} />
    </div>
  )
}
