import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { UsersManager } from '@/components/admin/users-manager'

export const dynamic = 'force-dynamic'

export default async function AdminUsersPage() {
  const user = await getCurrentUser()
  if (!user || user.role !== 'SUPER_ADMIN') redirect('/admin')

  const users = await db.user.findMany({
    select: {
      id: true, email: true, username: true, name: true, avatar: true,
      role: true, isBlocked: true, createdAt: true,
      _count: {
        select: {
          articles: true,
          comments: true,
          bookmarks: true,
        },
      },
    },
    orderBy: { createdAt: 'desc' },
    take: 200,
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold">مدیریت کاربران</h1>
        <p className="text-muted-foreground mt-1">
          مجموع: {users.length} کاربر
        </p>
      </div>
      <UsersManager users={users} currentUser={user} />
    </div>
  )
}
