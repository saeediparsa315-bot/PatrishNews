import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { CategoriesManager } from '@/components/admin/categories-manager'

export const dynamic = 'force-dynamic'

export default async function AdminCategoriesPage() {
  const user = await getCurrentUser()
  if (!user || (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) redirect('/login')

  const categories = await db.category.findMany({
    include: {
      parent: { select: { id: true, name: true, slug: true } },
      children: {
        select: { id: true, name: true, slug: true, color: true, icon: true, isActive: true },
      },
      _count: { select: { articles: true } },
    },
    orderBy: { order: 'asc' },
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold">دسته‌بندی‌ها</h1>
        <p className="text-muted-foreground mt-1">مدیریت دسته‌بندی‌های اخبار سایت</p>
      </div>
      <CategoriesManager categories={categories} canEdit={user.role === 'SUPER_ADMIN'} />
    </div>
  )
}
