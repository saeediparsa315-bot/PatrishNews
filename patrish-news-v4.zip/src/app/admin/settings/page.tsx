import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { SettingsManager } from '@/components/admin/settings-manager'
import { ensureDefaultSettings } from '@/lib/settings'

export const dynamic = 'force-dynamic'

export default async function AdminSettingsPage() {
  const user = await getCurrentUser()
  if (!user || user.role !== 'SUPER_ADMIN') redirect('/admin')

  await ensureDefaultSettings()

  const settings = await db.siteSetting.findMany()
  const settingsObj = Object.fromEntries(settings.map(s => [s.key, s.value]))

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold">تنظیمات سایت</h1>
        <p className="text-muted-foreground mt-1">تنظیمات کلی سایت را مدیریت کنید</p>
      </div>
      <SettingsManager initialSettings={settingsObj} />
    </div>
  )
}
