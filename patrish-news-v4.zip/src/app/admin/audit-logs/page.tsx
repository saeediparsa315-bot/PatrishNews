import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import { formatPersianDate, formatTime, toPersianDigits } from '@/lib/persian'

export const dynamic = 'force-dynamic'

const actionLabels: Record<string, { label: string; color: string }> = {
  CREATE: { label: 'ایجاد', color: 'bg-emerald-500/15 text-emerald-600' },
  UPDATE: { label: 'ویرایش', color: 'bg-blue-500/15 text-blue-600' },
  DELETE: { label: 'حذف', color: 'bg-red-500/15 text-red-600' },
  LOGIN: { label: 'ورود', color: 'bg-cyan-500/15 text-cyan-600' },
  LOGOUT: { label: 'خروج', color: 'bg-gray-500/15 text-gray-600' },
  REGISTER: { label: 'ثبت‌نام', color: 'bg-violet-500/15 text-violet-600' },
  CHANGE_ROLE: { label: 'تغییر نقش', color: 'bg-amber-500/15 text-amber-600' },
  BLOCK: { label: 'مسدود', color: 'bg-red-500/15 text-red-600' },
  UNBLOCK: { label: 'رفع مسدودی', color: 'bg-emerald-500/15 text-emerald-600' },
}

export default async function AdminAuditLogsPage() {
  const user = await getCurrentUser()
  if (!user || user.role !== 'SUPER_ADMIN') redirect('/admin')

  const logs = await db.auditLog.findMany({
    include: {
      user: { select: { id: true, username: true, name: true, role: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 200,
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold">لاگ فعالیت‌ها</h1>
        <p className="text-muted-foreground mt-1">تاریخچه آخرین فعالیت‌های سیستم</p>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>کاربر</TableHead>
                  <TableHead>عملیات</TableHead>
                  <TableHead>موجودیت</TableHead>
                  <TableHead>جزئیات</TableHead>
                  <TableHead>زمان</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-12 text-muted-foreground">
                      فعالیتی ثبت نشده است
                    </TableCell>
                  </TableRow>
                ) : logs.map(log => {
                  const action = actionLabels[log.action] || { label: log.action, color: 'bg-muted text-muted-foreground' }
                  return (
                    <TableRow key={log.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="size-8 rounded-full bg-primary/15 flex items-center justify-center text-xs font-bold text-primary">
                            {(log.user?.name || log.user?.username || '?').charAt(0)}
                          </div>
                          <div className="min-w-0">
                            <div className="font-medium text-sm">{log.user?.name || log.user?.username || 'سیستم'}</div>
                            {log.user?.role && (
                              <div className="text-xs text-muted-foreground">
                                {log.user.role === 'SUPER_ADMIN' ? 'سوپر ادمین' : log.user.role === 'ADMIN' ? 'ادمین' : 'کاربر'}
                              </div>
                            )}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className={`px-2 py-1 rounded-md text-xs font-medium ${action.color}`}>
                          {action.label}
                        </span>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{log.entity}</Badge>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground max-w-xs truncate">
                        {log.details || '—'}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                        <div>{formatPersianDate(log.createdAt)}</div>
                        <div className="text-muted-foreground">{formatTime(log.createdAt)}</div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
