import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Users, FileText, MessageSquare, Eye, Heart, Bookmark,
  TrendingUp, FolderTree, Activity, Flame, Clock, Star, Zap, Home,
} from 'lucide-react'
import { AdminStatsChart } from '@/components/admin/stats-chart'
import { formatRelativeTime, formatNumber, toPersianDigits, formatPersianDate } from '@/lib/persian'

export const dynamic = 'force-dynamic'

export default async function AdminAnalyticsPage() {
  const user = await getCurrentUser()
  // درخواست ۱۰: صفحه اختصاصی برای سوپر ادمین
  if (!user || user.role !== 'SUPER_ADMIN') {
    redirect('/admin')
  }

  const days = 30
  const startDate = new Date()
  startDate.setDate(startDate.getDate() - days)

  const [
    totalUsers, totalArticles, publishedArticles, draftArticles,
    totalComments, pendingComments, totalCategories, totalTags,
    totalBookmarks, totalLikes, totalViewsAgg,
    homepageArticlesCount, breakingArticlesCount, mainHeadlineCount,
    recentUsers, topArticles, topCategories, allUsers, allArticles,
  ] = await Promise.all([
    db.user.count(),
    db.article.count(),
    db.article.count({ where: { status: 'PUBLISHED' } }),
    db.article.count({ where: { status: 'DRAFT' } }),
    db.comment.count(),
    db.comment.count({ where: { status: 'PENDING' } }),
    db.category.count(),
    db.tag.count(),
    db.bookmark.count(),
    db.like.count(),
    db.article.aggregate({ _sum: { viewCount: true } }),
    db.article.count({ where: { status: 'PUBLISHED', isHomepage: true } }),
    db.article.count({ where: { status: 'PUBLISHED', isBreaking: true } }),
    db.article.count({ where: { status: 'PUBLISHED', isMainHeadline: true } }),
    db.user.findMany({
      select: {
        id: true, username: true, name: true, email: true, role: true, createdAt: true,
        isBlocked: true,
        _count: { select: { articles: true, comments: true, bookmarks: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 20,
    }),
    db.article.findMany({
      where: { status: 'PUBLISHED' },
      select: {
        id: true, title: true, slug: true, viewCount: true, likeCount: true,
        commentCount: true, publishedAt: true, readingTime: true,
        isMainHeadline: true, isBreaking: true, isHomepage: true, isFeatured: true,
        category: { select: { name: true, slug: true, color: true } },
        author: { select: { name: true, username: true } },
      },
      orderBy: { viewCount: 'desc' },
      take: 20,
    }),
    db.category.findMany({
      select: {
        id: true, name: true, color: true,
        _count: { select: { articles: { where: { status: 'PUBLISHED' } } } },
      },
      orderBy: { order: 'asc' },
    }),
    db.user.findMany({
      select: {
        id: true, username: true, name: true, email: true, role: true,
        isBlocked: true, createdAt: true,
        _count: { select: { articles: true, comments: true, bookmarks: true, likes: true } },
      },
      orderBy: { createdAt: 'desc' },
    }),
    db.article.findMany({
      where: { status: 'PUBLISHED' },
      select: {
        id: true, title: true, slug: true, viewCount: true, likeCount: true,
        commentCount: true, readingTime: true, publishedAt: true,
        isMainHeadline: true, isBreaking: true, isHomepage: true, isFeatured: true,
        category: { select: { name: true, color: true } },
        author: { select: { name: true, username: true } },
      },
      orderBy: { publishedAt: 'desc' },
    }),
  ])

  // Articles per day (last 30 days)
  const articlesPerDay: { date: string; count: number }[] = []
  const viewsPerDay: { date: string; count: number }[] = []
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date()
    d.setDate(d.getDate() - i)
    d.setHours(0, 0, 0, 0)
    const next = new Date(d)
    next.setDate(next.getDate() + 1)
    const [artCount, viewAgg] = await Promise.all([
      db.article.count({
        where: { publishedAt: { gte: d, lt: next }, status: 'PUBLISHED' },
      }),
      db.article.aggregate({
        where: { publishedAt: { gte: d, lt: next } },
        _sum: { viewCount: true },
      }),
    ])
    articlesPerDay.push({ date: d.toISOString().split('T')[0], count: artCount })
    viewsPerDay.push({ date: d.toISOString().split('T')[0], count: viewAgg._sum.viewCount || 0 })
  }

  const stats = [
    { label: 'کل کاربران', value: totalUsers, icon: Users, color: '#7C3AED' },
    { label: 'کل اخبار', value: totalArticles, icon: FileText, color: '#06B6D4' },
    { label: 'منتشر شده', value: publishedArticles, icon: FileText, color: '#10B981' },
    { label: 'پیش‌نویس', value: draftArticles, icon: FileText, color: '#F59E0B' },
    { label: 'کل نظرات', value: totalComments, icon: MessageSquare, color: '#F43F5E' },
    { label: 'نظرات در انتظار', value: pendingComments, icon: Clock, color: '#EF4444' },
    { label: 'دسته‌ها', value: totalCategories, icon: FolderTree, color: '#8B5CF6' },
    { label: 'برچسب‌ها', value: totalTags, icon: TrendingUp, color: '#EC4899' },
    { label: 'تیتر اصلی', value: mainHeadlineCount, icon: Star, color: '#F59E0B' },
    { label: 'خبر فوری', value: breakingArticlesCount, icon: Zap, color: '#EF4444' },
    { label: 'صفحه اصلی', value: homepageArticlesCount, icon: Home, color: '#3B82F6' },
    { label: 'کل بازدیدها', value: totalViewsAgg._sum.viewCount || 0, icon: Eye, color: '#06B6D4' },
    { label: 'کل لایک‌ها', value: totalLikes, icon: Heart, color: '#F97316' },
    { label: 'کل ذخیره‌ها', value: totalBookmarks, icon: Bookmark, color: '#14B8A6' },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold">آمار و اطلاعات سایت</h1>
        <p className="text-muted-foreground mt-1">
          مشاهده کامل آمار و اطلاعات سایت (اختصاصی سوپر ادمین)
        </p>
      </div>

      {/* Stats grid */}
      <div>
        <h2 className="text-lg font-bold mb-3">آمار کلی</h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
          {stats.map(stat => (
            <Card key={stat.label} className="hover:shadow-md transition-all">
              <CardContent className="pt-4 pb-4">
                <div
                  className="size-9 rounded-lg flex items-center justify-center mb-2"
                  style={{ backgroundColor: `${stat.color}20` }}
                >
                  <stat.icon className="size-4" style={{ color: stat.color }} />
                </div>
                <div className="text-2xl font-bold">{toPersianDigits(stat.value)}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Charts */}
      <div>
        <h2 className="text-lg font-bold mb-3">نمودارهای فعالیت</h2>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Activity className="size-5 text-primary" />
                اخبار منتشر شده روزانه
              </CardTitle>
              <CardDescription>تعداد اخبار در ۳۰ روز اخیر</CardDescription>
            </CardHeader>
            <CardContent>
              <AdminStatsChart data={articlesPerDay} color="#7C3AED" label="اخبار" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-base">
                <Eye className="size-5 text-cyan-500" />
                بازدیدهای روزانه
              </CardTitle>
              <CardDescription>مجموع بازدیدها در ۳۰ روز اخیر</CardDescription>
            </CardHeader>
            <CardContent>
              <AdminStatsChart data={viewsPerDay} color="#06B6D4" label="بازدید" />
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Top Articles Table */}
      <div>
        <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
          <Flame className="size-5 text-destructive" />
          پربازدیدترین اخبار
        </h2>
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">#</TableHead>
                    <TableHead className="text-right">عنوان خبر</TableHead>
                    <TableHead className="text-right">دسته</TableHead>
                    <TableHead className="text-right">نویسنده</TableHead>
                    <TableHead className="text-right">بازدید</TableHead>
                    <TableHead className="text-right">لایک</TableHead>
                    <TableHead className="text-right">نظر</TableHead>
                    <TableHead className="text-right">زمان مطالعه</TableHead>
                    <TableHead className="text-right">پرچم‌ها</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {topArticles.map((article, idx) => (
                    <TableRow key={article.id}>
                      <TableCell className="font-bold text-muted-foreground/30">
                        {toPersianDigits(idx + 1)}
                      </TableCell>
                      <TableCell className="max-w-xs">
                        <div className="font-medium line-clamp-2">{article.title}</div>
                      </TableCell>
                      <TableCell>
                        {article.category && (
                          <Badge
                            variant="outline"
                            style={{ color: article.category.color, borderColor: `${article.category.color}40` }}
                          >
                            {article.category.name}
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-sm">{article.author?.name || article.author?.username}</TableCell>
                      <TableCell className="font-mono">{formatNumber(article.viewCount)}</TableCell>
                      <TableCell className="font-mono">{toPersianDigits(article.likeCount)}</TableCell>
                      <TableCell className="font-mono">{toPersianDigits(article.commentCount)}</TableCell>
                      <TableCell className="font-mono">{toPersianDigits(article.readingTime)} دقیقه</TableCell>
                      <TableCell>
                        <div className="flex gap-1 flex-wrap">
                          {article.isMainHeadline && <Star className="size-3 text-amber-500" />}
                          {article.isBreaking && <Zap className="size-3 text-destructive" />}
                          {article.isHomepage && <Home className="size-3 text-blue-500" />}
                          {article.isFeatured && <Flame className="size-3 text-primary" />}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Categories Distribution */}
      <div>
        <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
          <FolderTree className="size-5 text-primary" />
          توزیع اخبار در دسته‌ها
        </h2>
        <Card>
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="text-right">نام دسته</TableHead>
                  <TableHead className="text-right">تعداد اخبار</TableHead>
                  <TableHead className="text-right">درصد</TableHead>
                  <TableHead className="text-right">نمودار</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topCategories.map(cat => {
                  const percent = publishedArticles > 0 ? (cat._count.articles / publishedArticles) * 100 : 0
                  return (
                    <TableRow key={cat.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="size-3 rounded-full" style={{ backgroundColor: cat.color }} />
                          <span className="font-medium">{cat.name}</span>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono">{toPersianDigits(cat._count.articles)}</TableCell>
                      <TableCell className="font-mono">{toPersianDigits(percent.toFixed(1))}٪</TableCell>
                      <TableCell className="w-48">
                        <div className="h-2 rounded-full bg-muted overflow-hidden">
                          <div
                            className="h-full rounded-full"
                            style={{ width: `${percent}%`, backgroundColor: cat.color }}
                          />
                        </div>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* All Users Table */}
      <div>
        <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
          <Users className="size-5 text-primary" />
          لیست کاربران
        </h2>
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">نام</TableHead>
                    <TableHead className="text-right">ایمیل</TableHead>
                    <TableHead className="text-right">نقش</TableHead>
                    <TableHead className="text-right">مقالات</TableHead>
                    <TableHead className="text-right">نظرات</TableHead>
                    <TableHead className="text-right">لایک‌ها</TableHead>
                    <TableHead className="text-right">ذخیره‌ها</TableHead>
                    <TableHead className="text-right">عضویت</TableHead>
                    <TableHead className="text-right">وضعیت</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {allUsers.map(u => (
                    <TableRow key={u.id}>
                      <TableCell>
                        <div className="font-medium">{u.name || u.username}</div>
                        <div className="text-xs text-muted-foreground">@{u.username}</div>
                      </TableCell>
                      <TableCell className="text-sm" dir="ltr">{u.email}</TableCell>
                      <TableCell>
                        <Badge variant={u.role === 'SUPER_ADMIN' ? 'default' : u.role === 'ADMIN' ? 'secondary' : 'outline'}>
                          {u.role === 'SUPER_ADMIN' ? 'سوپر ادمین' : u.role === 'ADMIN' ? 'ادمین' : 'کاربر'}
                        </Badge>
                      </TableCell>
                      <TableCell className="font-mono">{toPersianDigits(u._count.articles)}</TableCell>
                      <TableCell className="font-mono">{toPersianDigits(u._count.comments)}</TableCell>
                      <TableCell className="font-mono">{toPersianDigits(u._count.likes)}</TableCell>
                      <TableCell className="font-mono">{toPersianDigits(u._count.bookmarks)}</TableCell>
                      <TableCell className="text-xs whitespace-nowrap">{formatRelativeTime(u.createdAt)}</TableCell>
                      <TableCell>
                        {u.isBlocked ? (
                          <Badge variant="destructive">مسدود</Badge>
                        ) : (
                          <Badge variant="outline" className="text-emerald-600">فعال</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* All Articles Table */}
      <div>
        <h2 className="text-lg font-bold mb-3 flex items-center gap-2">
          <FileText className="size-5 text-primary" />
          لیست تمام اخبار
        </h2>
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="text-right">عنوان</TableHead>
                    <TableHead className="text-right">دسته</TableHead>
                    <TableHead className="text-right">نویسنده</TableHead>
                    <TableHead className="text-right">بازدید</TableHead>
                    <TableHead className="text-right">لایک</TableHead>
                    <TableHead className="text-right">نظر</TableHead>
                    <TableHead className="text-right">زمان مطالعه</TableHead>
                    <TableHead className="text-right">تاریخ انتشار</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {allArticles.map(article => (
                    <TableRow key={article.id}>
                      <TableCell className="max-w-xs">
                        <div className="font-medium line-clamp-1">{article.title}</div>
                      </TableCell>
                      <TableCell>
                        {article.category && (
                          <Badge
                            variant="outline"
                            style={{ color: article.category.color, borderColor: `${article.category.color}40` }}
                          >
                            {article.category.name}
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-sm">{article.author?.name || article.author?.username}</TableCell>
                      <TableCell className="font-mono">{formatNumber(article.viewCount)}</TableCell>
                      <TableCell className="font-mono">{toPersianDigits(article.likeCount)}</TableCell>
                      <TableCell className="font-mono">{toPersianDigits(article.commentCount)}</TableCell>
                      <TableCell className="font-mono">{toPersianDigits(article.readingTime)} دقیقه</TableCell>
                      <TableCell className="text-xs whitespace-nowrap">
                        {article.publishedAt ? formatPersianDate(article.publishedAt) : '—'}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
