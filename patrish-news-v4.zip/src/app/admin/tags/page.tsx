import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { TagsManager } from '@/components/admin/tags-manager'

export const dynamic = 'force-dynamic'

export default async function AdminTagsPage() {
  const user = await getCurrentUser()
  if (!user || (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) redirect('/login')

  const tags = await db.tag.findMany({
    include: { _count: { select: { articles: true } } },
    orderBy: { name: 'asc' },
  })

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold">برچسب‌ها</h1>
        <p className="text-muted-foreground mt-1">مدیریت برچسب‌های اخبار</p>
      </div>
      <TagsManager tags={tags} canEdit={user.role === 'SUPER_ADMIN'} />
    </div>
  )
}
