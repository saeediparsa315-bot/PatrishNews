import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import Link from 'next/link'
import {
  Users, FileText, MessageSquare, Eye, Heart, Bookmark,
  TrendingUp, FolderTree, Plus, ArrowLeft, Activity,
  Flame, Clock, AlertCircle,
} from 'lucide-react'
import { AdminStatsChart } from '@/components/admin/stats-chart'
import { formatRelativeTime, formatNumber, toPersianDigits, formatPersianDate } from '@/lib/persian'

export const dynamic = 'force-dynamic'

export default async function AdminDashboard() {
  const user = await getCurrentUser()
  if (!user || (user.role !== 'ADMIN' && user.role !== 'SUPER_ADMIN')) {
    return null
  }

  const days = 30
  const startDate = new Date()
  startDate.setDate(startDate.getDate() - days)

  const [
    totalUsers, totalArticles, publishedArticles, draftArticles,
    totalComments, pendingComments, totalCategories, totalTags,
    totalBookmarks, totalLikes, totalViewsAgg,
    recentUsers, topArticles, categories,
  ] = await Promise.all([
    db.user.count(),
    db.article.count(),
    db.article.count({ where: { status: 'PUBLISHED' } }),
    db.article.count({ where: { status: 'DRAFT' } }),
    db.comment.count(),
    db.comment.count({ where: { status: 'PENDING' } }),
    db.category.count(),
    db.tag.count(),
    db.bookmark.count(),
    db.like.count(),
    db.article.aggregate({ _sum: { viewCount: true } }),
    db.user.findMany({
      select: { id: true, username: true, name: true, email: true, role: true, createdAt: true, isBlocked: true },
      orderBy: { createdAt: 'desc' },
      take: 5,
    }),
    db.article.findMany({
      where: { status: 'PUBLISHED' },
      select: {
        id: true, title: true, slug: true, viewCount: true, likeCount: true, commentCount: true, publishedAt: true,
        category: { select: { name: true, slug: true, color: true } },
      },
      orderBy: { viewCount: 'desc' },
      take: 5,
    }),
    db.category.findMany({
      select: {
        id: true, name: true, color: true,
        _count: { select: { articles: { where: { status: 'PUBLISHED' } } } },
      },
      orderBy: { order: 'asc' },
    }),
  ])

  // Articles per day (last 30 days)
  const articlesPerDay: { date: string; count: number }[] = []
  const viewsPerDay: { date: string; count: number }[] = []
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date()
    d.setDate(d.getDate() - i)
    d.setHours(0, 0, 0, 0)
    const next = new Date(d)
    next.setDate(next.getDate() + 1)
    const [artCount, viewAgg] = await Promise.all([
      db.article.count({
        where: { publishedAt: { gte: d, lt: next }, status: 'PUBLISHED' },
      }),
      db.article.aggregate({
        where: { publishedAt: { gte: d, lt: next } },
        _sum: { viewCount: true },
      }),
    ])
    articlesPerDay.push({ date: d.toISOString().split('T')[0], count: artCount })
    viewsPerDay.push({ date: d.toISOString().split('T')[0], count: viewAgg._sum.viewCount || 0 })
  }

  const stats = [
    { label: 'کل کاربران', value: totalUsers, icon: Users, color: '#7C3AED', href: '/admin/users' },
    { label: 'کل اخبار', value: totalArticles, icon: FileText, color: '#06B6D4', href: '/admin/articles' },
    { label: 'منتشر شده', value: publishedArticles, icon: FileText, color: '#10B981', href: '/admin/articles?status=PUBLISHED' },
    { label: 'پیش‌نویس', value: draftArticles, icon: FileText, color: '#F59E0B', href: '/admin/articles?status=DRAFT' },
    { label: 'کل نظرات', value: totalComments, icon: MessageSquare, color: '#F43F5E', href: '/admin/comments' },
    { label: 'نظرات در انتظار', value: pendingComments, icon: AlertCircle, color: '#EF4444', href: '/admin/comments?status=PENDING' },
    { label: 'دسته‌ها', value: totalCategories, icon: FolderTree, color: '#8B5CF6', href: '/admin/categories' },
    { label: 'برچسب‌ها', value: totalTags, icon: TrendingUp, color: '#EC4899', href: '/admin/tags' },
    { label: 'کل ذخیره‌ها', value: totalBookmarks, icon: Bookmark, color: '#14B8A6' },
    { label: 'کل لایک‌ها', value: totalLikes, icon: Heart, color: '#F97316' },
    { label: 'کل بازدیدها', value: totalViewsAgg._sum.viewCount || 0, icon: Eye, color: '#3B82F6' },
  ]

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold">داشبورد مدیریت</h1>
          <p className="text-muted-foreground mt-1">
            خلاصه فعالیت‌های سایت در ۳۰ روز گذشته
          </p>
        </div>
        <div className="flex gap-2">
          <Link href="/admin/articles/new">
            <Button>
              <Plus className="size-4 ml-2" />
              افزودن خبر
            </Button>
          </Link>
          <Link href="/" target="_blank">
            <Button variant="outline">
              مشاهده سایت
              <ArrowLeft className="size-4 mr-2" />
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
        {stats.map(stat => (
          <Link key={stat.label} href={stat.href || '#'}>
            <Card className="hover:shadow-md hover:border-primary/40 transition-all h-full">
              <CardContent className="pt-4 pb-4">
                <div
                  className="size-9 rounded-lg flex items-center justify-center mb-2"
                  style={{ backgroundColor: `${stat.color}20` }}
                >
                  <stat.icon className="size-4" style={{ color: stat.color }} />
                </div>
                <div className="text-2xl font-bold">{toPersianDigits(stat.value)}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="size-5 text-primary" />
              اخبار منتشر شده روزانه
            </CardTitle>
            <CardDescription>تعداد اخبار در ۳۰ روز اخیر</CardDescription>
          </CardHeader>
          <CardContent>
            <AdminStatsChart data={articlesPerDay} color="#7C3AED" label="اخبار" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="size-5 text-cyan-500" />
              بازدیدهای روزانه
            </CardTitle>
            <CardDescription>مجموع بازدیدها در ۳۰ روز اخیر</CardDescription>
          </CardHeader>
          <CardContent>
            <AdminStatsChart data={viewsPerDay} color="#06B6D4" label="بازدید" />
          </CardContent>
        </Card>
      </div>

      {/* Top articles & recent users */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Flame className="size-5 text-destructive" />
              پربازدیدترین اخبار
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topArticles.map((article, idx) => (
                <Link
                  key={article.id}
                  href={`/admin/articles/${article.id}`}
                  className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/40 transition-colors"
                >
                  <div className="text-xl font-bold text-muted-foreground/30 w-8 text-center">
                    {toPersianDigits(idx + 1)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium line-clamp-1">{article.title}</div>
                    <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                      {article.category && (
                        <span style={{ color: article.category.color }}>{article.category.name}</span>
                      )}
                      <span className="flex items-center gap-1">
                        <Eye className="size-3" />
                        {formatNumber(article.viewCount)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Heart className="size-3" />
                        {toPersianDigits(article.likeCount)}
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageSquare className="size-3" />
                        {toPersianDigits(article.commentCount)}
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="size-5 text-primary" />
              جدیدترین کاربران
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentUsers.map(u => (
                <div key={u.id} className="flex items-center gap-3 p-2">
                  <div className="size-9 rounded-full bg-primary/15 flex items-center justify-center text-sm font-bold text-primary">
                    {(u.name || u.username).charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium line-clamp-1">{u.name || u.username}</div>
                    <div className="text-xs text-muted-foreground" dir="ltr">{u.email}</div>
                  </div>
                  <Badge variant={u.role === 'SUPER_ADMIN' ? 'default' : u.role === 'ADMIN' ? 'secondary' : 'outline'} className="text-xs">
                    {u.role === 'SUPER_ADMIN' ? 'سوپر' : u.role === 'ADMIN' ? 'ادمین' : 'کاربر'}
                  </Badge>
                  <span className="text-xs text-muted-foreground whitespace-nowrap">
                    {formatRelativeTime(u.createdAt)}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Category breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FolderTree className="size-5 text-primary" />
            توزیع اخبار در دسته‌ها
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {categories.map(cat => (
              <Link
                key={cat.id}
                href={`/admin/articles?category=${cat.id}`}
                className="text-center p-4 rounded-xl border hover:shadow-md transition-all"
                style={{ borderColor: `${cat.color}40` }}
              >
                <div
                  className="size-12 rounded-xl mx-auto mb-2 flex items-center justify-center"
                  style={{ backgroundColor: `${cat.color}20` }}
                >
                  <FolderTree className="size-5" style={{ color: cat.color }} />
                </div>
                <div className="font-bold text-lg">{toPersianDigits(cat._count.articles)}</div>
                <div className="text-xs text-muted-foreground truncate">{cat.name}</div>
              </Link>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
