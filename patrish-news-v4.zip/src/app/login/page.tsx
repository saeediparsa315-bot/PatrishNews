import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { LoginForm } from '@/components/auth-forms'

export const metadata = { title: 'ورود | پاتریش نیوز' }
export const dynamic = "force-dynamic"

export default async function LoginPage() {
  const user = await getCurrentUser()
  if (user) redirect('/')

  const categories = await db.category.findMany({
    where: { isActive: true, parentId: null },
    orderBy: { order: 'asc' },
  })

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader user={null} categories={categories} />
      <main className="flex-1 flex items-center justify-center px-4 py-12">
        <LoginForm />
      </main>
      <SiteFooter />
    </div>
  )
}
