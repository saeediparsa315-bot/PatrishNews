import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { ProfileForm } from '@/components/profile-form'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ArticleCard } from '@/components/article-card'
import { formatPersianDate, formatNumber, toPersianDigits } from '@/lib/persian'
import { Bookmark, Heart, MessageCircle, FileText, User as UserIcon } from 'lucide-react'

export const metadata = { title: 'پروفایل | پاتریش نیوز' }
export const dynamic = "force-dynamic"

export default async function ProfilePage() {
  const user = await getCurrentUser()
  if (!user) redirect('/login')

  const [categories, stats, bookmarks] = await Promise.all([
    db.category.findMany({
      where: { isActive: true, parentId: null },
      orderBy: { order: 'asc' },
    }),
    Promise.all([
      db.article.count({ where: { authorId: user.id } }),
      db.comment.count({ where: { userId: user.id } }),
      db.bookmark.count({ where: { userId: user.id } }),
      db.like.count({ where: { userId: user.id } }),
    ]),
    db.bookmark.findMany({
      where: { userId: user.id },
      include: {
        article: {
          include: {
            category: { select: { id: true, name: true, slug: true, color: true, icon: true } },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
      take: 6,
    }),
  ])

  const [articleCount, commentCount, bookmarkCount, likeCount] = stats
  const userWithDates = await db.user.findUnique({
    where: { id: user.id },
    select: { createdAt: true },
  })

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader user={user} categories={categories} />

      <main className="flex-1">
        <div className="border-b border-border/40 bg-gradient-to-l from-primary/10 to-transparent">
          <div className="container mx-auto px-4 py-8">
            <div className="flex items-center gap-4">
              <div className="size-20 rounded-full bg-primary/15 flex items-center justify-center text-2xl font-bold text-primary">
                {(user.name || user.username).charAt(0)}
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold">{user.name || user.username}</h1>
                <p className="text-muted-foreground">{user.email}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-xs px-2 py-0.5 rounded-md bg-primary/15 text-primary font-medium">
                    {user.role === 'SUPER_ADMIN' ? 'سوپر ادمین' : user.role === 'ADMIN' ? 'ادمین' : 'کاربر'}
                  </span>
                  {userWithDates && (
                    <span className="text-xs text-muted-foreground">
                      عضو از {formatPersianDate(userWithDates.createdAt)}
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
            {[
              { label: 'مقالات نوشته شده', value: articleCount, icon: FileText, color: '#7C3AED' },
              { label: 'نظرات', value: commentCount, icon: MessageCircle, color: '#06B6D4' },
              { label: 'ذخیره‌ها', value: bookmarkCount, icon: Bookmark, color: '#10B981' },
              { label: 'لایک‌ها', value: likeCount, icon: Heart, color: '#F43F5E' },
            ].map(stat => (
              <Card key={stat.label}>
                <CardContent className="pt-6">
                  <div className="flex items-center gap-3">
                    <div
                      className="size-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: `${stat.color}20` }}
                    >
                      <stat.icon className="size-5" style={{ color: stat.color }} />
                    </div>
                    <div>
                      <div className="text-2xl font-bold">{toPersianDigits(stat.value)}</div>
                      <div className="text-xs text-muted-foreground">{stat.label}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Tabs defaultValue="profile">
            <TabsList className="mb-6">
              <TabsTrigger value="profile" className="gap-2">
                <UserIcon className="size-4" />
                ویرایش پروفایل
              </TabsTrigger>
              <TabsTrigger value="bookmarks" className="gap-2">
                <Bookmark className="size-4" />
                ذخیره‌ها
              </TabsTrigger>
            </TabsList>

            <TabsContent value="profile">
              <ProfileForm user={user} />
            </TabsContent>

            <TabsContent value="bookmarks">
              {bookmarks.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Bookmark className="size-12 mx-auto mb-3 opacity-20" />
                  <p>هنوز خبری ذخیره نکرده‌اید</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {bookmarks.map(b => (
                    <ArticleCard key={b.id} article={b.article} variant="compact" />
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
