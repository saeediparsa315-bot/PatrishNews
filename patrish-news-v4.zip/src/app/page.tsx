import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { ensureDefaultSettings } from '@/lib/settings'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { ArticleCard } from '@/components/article-card'
import { BreakingTicker } from '@/components/breaking-ticker'
import { LiveStatsWidget } from '@/components/live-stats-widget'
import { ScrollReveal } from '@/components/scroll-reveal'
import Link from 'next/link'
import { ChevronLeft, Flame } from 'lucide-react'
import { Button } from '@/components/ui/button'

export const revalidate = 60

const MAX_HOMEPAGE_ARTICLES = 15
const MAX_MANUAL_ARTICLES = 5  // حداکثر ۵ خبر دستی
const AUTO_ARTICLES_COUNT = 10 // ۱۰ خبر خودکار بر اساس بازدید

export default async function HomePage() {
  await ensureDefaultSettings()

  const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000)

  const [user, categories, breakingNews, manualArticles, autoArticles] = await Promise.all([
    getCurrentUser(),
    db.category.findMany({
      where: { isActive: true, parentId: null },
      include: {
        children: {
          where: { isActive: true },
          select: { id: true, name: true, slug: true, color: true, icon: true },
          orderBy: { order: 'asc' },
        },
      },
      orderBy: { order: 'asc' },
    }),
    // اخبار فوری: فقط ۲۴ ساعت اخیر
    db.article.findMany({
      where: {
        status: 'PUBLISHED',
        isBreaking: true,
        publishedAt: { gte: oneDayAgo },
      },
      select: {
        id: true, title: true, slug: true, publishedAt: true,
        category: { select: { name: true, slug: true, color: true } },
      },
      orderBy: { publishedAt: 'desc' },
      take: 8,
    }),
    // اخبار دستی (MANUAL): حداکثر ۵ خبر، بر اساس position
    // نکته: نیازی به isHomepage نیست - هر خبری می‌تونه موقعیت دستی بگیره
    db.article.findMany({
      where: {
        status: 'PUBLISHED',
        layoutMode: 'MANUAL',
        position: { gt: 0 },
        publishedAt: { gte: oneDayAgo },
      },
      include: {
        category: { select: { id: true, name: true, slug: true, color: true, icon: true } },
        author: { select: { id: true, username: true, name: true, avatar: true } },
      },
      orderBy: { position: 'asc' },
      take: MAX_MANUAL_ARTICLES,
    }),
    // اخبار خودکار: بر اساس بازدید (۲۴ ساعت اخیر، ۱۰ خبر)
    // بعد از ۲۴ ساعت اگر خبری نباشد، خودکار با خبر جدید جایگزین می‌شود
    // نکته: isHomepage برای اخبار دستی هست، اخبار خودکار از همه اخبار منتشر شده انتخاب می‌شوند
    // take: 20 تا اگه بعضی از اخبار دستی بودن، همچنان ۱۰ خبر خودکار داشته باشیم
    db.article.findMany({
      where: {
        status: 'PUBLISHED',
        publishedAt: { gte: oneDayAgo },
      },
      include: {
        category: { select: { id: true, name: true, slug: true, color: true, icon: true } },
        author: { select: { id: true, username: true, name: true, avatar: true } },
      },
      orderBy: [
        { viewCount: 'desc' },  // بر اساس بازدید
        { publishedAt: 'desc' }, // بعد بر اساس تاریخ
      ],
      take: 20,
    }),
  ])

  // ترکیب اخبار دستی و خودکار
  // اول اخبار دستی (با position مرتب)، بعد خودکار تا ۱۵ خبر بشه
  const manualIds = new Set(manualArticles.map(a => a.id))
  const homepageArticles: typeof manualArticles = [...manualArticles]
  for (const article of autoArticles) {
    if (homepageArticles.length >= MAX_HOMEPAGE_ARTICLES) break
    // اخبار دستی تکراری نشن
    if (!manualIds.has(article.id)) {
      homepageArticles.push(article)
    }
  }

  // اولین خبر = Hero (تیتر اصلی)
  const heroArticle = homepageArticles[0] || null
  const sideArticles = homepageArticles.slice(1, 5) // ۴ خبر کناری
  const gridArticles = homepageArticles.slice(5, 15) // ۱۰ خبر گرید

  // نمایش تعداد بازدید فقط برای ادمین و سوپر ادمین
  const showViews = !!(user && (user.role === 'ADMIN' || user.role === 'SUPER_ADMIN'))

  return (
    <div className="min-h-screen flex flex-col bg-background page-transition">
      <SiteHeader user={user} categories={categories} />

      <main className="flex-1">
        {/* Breaking news ticker */}
        {breakingNews.length > 0 && <BreakingTicker articles={breakingNews} />}

        <div className="container mx-auto px-4 py-6 sm:py-8">
          {/* آمار زنده - فقط برای ادمین و سوپر ادمین */}
          {user && (user.role === 'ADMIN' || user.role === 'SUPER_ADMIN') && (
            <ScrollReveal className="mb-8">
              <LiveStatsWidget />
            </ScrollReveal>
          )}

          {/* Hero Section - چیدمان مدرن CNN/Reuters style */}
          {heroArticle && (
            <ScrollReveal className="mb-8">
              <section className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {/* تیتر اصلی بزرگ - سمت راست */}
                <div className="lg:col-span-2 lg:order-2">
                  <ArticleCard article={heroArticle} variant="hero" showViews={showViews} />
                </div>
                {/* ۴ خبر کناری - سمت چپ */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-4 lg:order-1">
                  {sideArticles.map(article => (
                    <ArticleCard
                      key={article.id}
                      article={article}
                      variant="horizontal"
                      showExcerpt={false}
                      showViews={showViews}
                    />
                  ))}
                </div>
              </section>
            </ScrollReveal>
          )}

          {/* اخبار گرید (۱۰ خبر باقی‌مونده) */}
          {gridArticles.length > 0 && (
            <ScrollReveal className="mb-12" delay={100}>
              <section>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl sm:text-2xl font-bold flex items-center gap-2">
                    <Flame className="h-5 w-5 text-primary" />
                    اخبار داغ
                  </h2>
                  <Link href="/trending" className="text-sm text-primary hover:underline flex items-center gap-1">
                    مشاهده همه
                    <ChevronLeft className="h-4 w-4" />
                  </Link>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 sm:gap-6">
                  {gridArticles.map((article, idx) => (
                    <ScrollReveal key={article.id} delay={idx * 50}>
                      <ArticleCard article={article} showViews={showViews} />
                    </ScrollReveal>
                  ))}
                </div>
              </section>
            </ScrollReveal>
          )}

          {/* empty state */}
          {homepageArticles.length === 0 && (
            <section className="text-center py-20">
              <Flame className="size-16 mx-auto mb-4 text-muted-foreground/30" />
              <h2 className="text-xl font-bold mb-2">در حال حاضر خبر داغی در صفحه اصلی نیست</h2>
              <p className="text-muted-foreground mb-4">
                اخبار داغ پس از ۲۴ ساعت از صفحه اصلی خارج می‌شوند.<br/>
                برای مشاهده همه اخبار به دسته‌بندی‌ها مراجعه کنید.
              </p>
              <div className="flex gap-2 justify-center flex-wrap">
                {categories.slice(0, 3).map(cat => (
                  <Link key={cat.id} href={`/category/${cat.slug}`}>
                    <Button variant="outline" size="sm">
                      {cat.name}
                    </Button>
                  </Link>
                ))}
              </div>
            </section>
          )}
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
