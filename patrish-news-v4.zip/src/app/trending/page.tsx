import { redirect } from 'next/navigation'

export default function TrendingPage() {
  redirect('/search?type=trending')
}
