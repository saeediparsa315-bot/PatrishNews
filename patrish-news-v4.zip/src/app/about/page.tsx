import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { Card, CardContent } from '@/components/ui/card'
import { Newspaper, Eye, Heart, Users, Target, Award } from 'lucide-react'
import { LiveStatsWidget } from '@/components/live-stats-widget'

export const metadata = { title: 'درباره ما | پاتریش نیوز' }
export const dynamic = "force-dynamic"

export default async function AboutPage() {
  const user = await getCurrentUser()
  const categories = await db.category.findMany({
    where: { isActive: true, parentId: null },
    orderBy: { order: 'asc' },
  })

  const values = [
    { icon: Newspaper, title: 'اخبار واقعی', desc: 'تمام اخبار ما واقعی و معتبر هستند', color: '#7C3AED' },
    { icon: Eye, title: 'شفافیت', desc: 'تمام اطلاعات و آمار سایت واقعی و شفاف است', color: '#06B6D4' },
    { icon: Heart, title: 'احترام به کاربر', desc: 'تجربه کاربری عالی در اولویت ماست', color: '#F43F5E' },
    { icon: Target, title: 'دقت', desc: 'اطلاعات دقیق و به‌روز', color: '#10B981' },
    { icon: Award, title: 'کیفیت', desc: 'محتوای باکیفیت و حرفه‌ای', color: '#F59E0B' },
    { icon: Users, title: 'جامعه', desc: 'پاسخگویی به نیازهای جامعه کاربری', color: '#8B5CF6' },
  ]

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader user={user} categories={categories} />

      <main className="flex-1">
        <section className="relative overflow-hidden border-b border-border/40 bg-gradient-to-l from-primary/10 to-transparent">
          <div className="container mx-auto px-4 py-16">
            <div className="max-w-3xl">
              <h1 className="text-4xl sm:text-5xl font-bold mb-4">درباره پاتریش نیوز</h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                پاتریش نیوز، مرجع تخصصی اخبار جهان، تکنولوژی و گیم. ما با هدف ارائه اخبار دقیق،
                به‌روز و معتبر در حوزه‌های مختلف، خدمت‌رسانی به کاربران فارسی‌زبان را آغاز کرده‌ایم.
              </p>
            </div>
          </div>
        </section>

        <div className="container mx-auto px-4 py-12">
          <section className="mb-16">
            <h2 className="text-2xl font-bold mb-6 text-center">آمار سایت به‌صورت زنده</h2>
            <LiveStatsWidget />
          </section>

          <section className="mb-16">
            <h2 className="text-2xl font-bold mb-6 text-center">ارزش‌های ما</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {values.map((value) => (
                <Card key={value.title} className="hover:shadow-md transition-all hover-scale">
                  <CardContent className="pt-6">
                    <div
                      className="size-12 rounded-xl flex items-center justify-center mb-4"
                      style={{ backgroundColor: `${value.color}20` }}
                    >
                      <value.icon className="size-6" style={{ color: value.color }} />
                    </div>
                    <h3 className="font-bold text-lg mb-2">{value.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{value.desc}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

          <section className="mb-16">
            <Card className="overflow-hidden">
              <CardContent className="pt-8 pb-8">
                <h2 className="text-2xl font-bold mb-4">ماموریت ما</h2>
                <div className="prose prose-sm max-w-none text-muted-foreground leading-relaxed space-y-4">
                  <p>
                    پاتریش نیوز با هدف ارائه اخبار دقیق، به‌روز و معتبر در حوزه‌های تکنولوژی، گیم،
                    علم، ورزش، سرگرمی و اخبار جهان فعالیت می‌کند. ما متعهد هستیم که تمام اخبار
                    منتشر شده در سایت واقعی و معتبر باشند و آمار سایت به‌صورت شفاف و واقعی نمایش داده شود.
                  </p>
                  <p>
                    تیم ما متشکل از نویسندگان متخصص در حوزه‌های مختلف است که با دقت اخبار را
                    بررسی و منتشر می‌کنند. ما به تجربه کاربری عالی اهمیت می‌دهیم و همواره در حال
                    بهبود سایت هستیم تا بهترین تجربه را برای کاربران فراهم کنیم.
                  </p>
                  <p>
                    پاتریش نیوز از کاربران خود حمایت می‌کند و تلاش می‌کند تا پلتفرمی امن و قابل
                    اعتماد برای دریافت اخبار روز دنیا باشد. ما به نظرات و پیشنهادات شما اهمیت
                    می‌دهیم و همواره در حال توسعه و بهبود هستیم.
                  </p>
                </div>
              </CardContent>
            </Card>
          </section>
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
