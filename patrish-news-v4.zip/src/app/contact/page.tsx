import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Mail, Send, MapPin, Phone, MessageCircle } from 'lucide-react'
import { ContactForm } from '@/components/contact-form'

export const metadata = { title: 'تماس با ما | پاتریش نیوز' }
export const dynamic = "force-dynamic"

export default async function ContactPage() {
  const user = await getCurrentUser()
  const categories = await db.category.findMany({
    where: { isActive: true, parentId: null },
    orderBy: { order: 'asc' },
  })

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader user={user} categories={categories} />

      <main className="flex-1">
        <section className="relative overflow-hidden border-b border-border/40 bg-gradient-to-l from-primary/10 to-transparent">
          <div className="container mx-auto px-4 py-16">
            <div className="max-w-3xl">
              <h1 className="text-4xl sm:text-5xl font-bold mb-4">تماس با ما</h1>
              <p className="text-lg text-muted-foreground leading-relaxed">
                برای هرگونه سوال، پیشنهاد یا انتقاد، از راه‌های زیر با ما در ارتباط باشید.
              </p>
            </div>
          </div>
        </section>

        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* فرم تماس */}
            <Card>
              <CardHeader>
                <CardTitle>پیام بفرستید</CardTitle>
              </CardHeader>
              <CardContent>
                <ContactForm />
              </CardContent>
            </Card>

            {/* اطلاعات تماس */}
            <div className="space-y-4">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-bold text-lg mb-4">اطلاعات تماس</h3>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="size-10 rounded-lg bg-primary/15 flex items-center justify-center shrink-0">
                        <Mail className="size-5 text-primary" />
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">ایمیل</div>
                        <a href="mailto:info@patrishnews.ir" className="font-medium hover:text-primary" dir="ltr">
                          info@patrishnews.ir
                        </a>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="size-10 rounded-lg bg-cyan-500/15 flex items-center justify-center shrink-0">
                        <Send className="size-5 text-cyan-500" />
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">تلگرام</div>
                        <a href="https://t.me/PCnewsF" target="_blank" rel="noreferrer" className="font-medium hover:text-primary" dir="ltr">
                          @PCnewsF
                        </a>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="size-10 rounded-lg bg-emerald-500/15 flex items-center justify-center shrink-0">
                        <MessageCircle className="size-5 text-emerald-500" />
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">پشتیبانی</div>
                        <span className="font-medium">۲۴ ساعته در خدمت شما</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="pt-6">
                  <h3 className="font-bold text-lg mb-4">ساعات پاسخگویی</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">شنبه تا چهارشنبه</span>
                      <span className="font-medium">۹ تا ۱۸</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">پنجشنبه</span>
                      <span className="font-medium">۹ تا ۱۳</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">جمعه</span>
                      <span className="font-medium">تعطیل</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
