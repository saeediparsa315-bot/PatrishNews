import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { ArticleCard } from '@/components/article-card'
import { ArticleListClient } from '@/components/article-list-client'
import { Clock, Flame, Radio, Search as SearchIcon, ChevronLeft } from 'lucide-react'
import Link from 'next/link'

export const revalidate = 60

async function getListData(sortBy: 'publishedAt' | 'views' | 'likes', filter: { isBreaking?: boolean } = {}) {
  return db.article.findMany({
    where: { status: 'PUBLISHED', ...filter },
    include: {
      category: { select: { id: true, name: true, slug: true, color: true, icon: true } },
      author: { select: { id: true, username: true, name: true, avatar: true } },
    },
    orderBy: sortBy === 'views' ? { viewCount: 'desc' } : sortBy === 'likes' ? { likeCount: 'desc' } : { publishedAt: 'desc' },
    take: 24,
  })
}

export default async function ListPage({ searchParams }: { searchParams: Promise<{ [key: string]: string | string[] | undefined }> }) {
  const sp = await searchParams
  const type = typeof sp.type === 'string' ? sp.type : 'latest'
  const q = typeof sp.q === 'string' ? sp.q : ''

  const user = await getCurrentUser()
  const categories = await db.category.findMany({
    where: { isActive: true, parentId: null },
    orderBy: { order: 'asc' },
  })

  let title = 'آخرین اخبار'
  let icon = <Clock className="size-7" />
  let articles: Awaited<ReturnType<typeof getListData>> = []
  let sortBy: 'publishedAt' | 'views' | 'likes' = 'publishedAt'
  let isSearch = false

  if (q) {
    isSearch = true
    title = `نتایج جستجو: ${q}`
    icon = <SearchIcon className="size-7" />
    articles = await db.article.findMany({
      where: {
        status: 'PUBLISHED',
        OR: [
          { title: { contains: q } },
          { excerpt: { contains: q } },
          { content: { contains: q } },
        ],
      },
      include: {
        category: { select: { id: true, name: true, slug: true, color: true, icon: true } },
        author: { select: { id: true, username: true, name: true, avatar: true } },
      },
      orderBy: { publishedAt: 'desc' },
      take: 24,
    })
  } else if (type === 'trending') {
    title = 'داغ‌ترین اخبار'
    icon = <Flame className="size-7 text-destructive" />
    articles = await getListData('views')
    sortBy = 'views'
  } else if (type === 'breaking') {
    title = 'اخبار فوری'
    icon = <Radio className="size-7 text-destructive" />
    articles = await getListData('publishedAt', { isBreaking: true })
  } else {
    articles = await getListData('publishedAt')
  }

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader user={user} categories={categories} />

      <main className="flex-1">
        <div className="border-b border-border/40 bg-muted/20">
          <div className="container mx-auto px-4 py-8">
            <nav className="flex items-center gap-1 text-sm text-muted-foreground mb-4">
              <Link href="/" className="hover:text-foreground">خانه</Link>
              <ChevronLeft className="size-3" />
              <span className="text-foreground">{title}</span>
            </nav>
            <div className="flex items-center gap-3">
              <div className="size-12 rounded-xl bg-primary/15 flex items-center justify-center text-primary">
                {icon}
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold">{title}</h1>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          {articles.length === 0 ? (
            <div className="text-center py-20 text-muted-foreground">
              {isSearch ? (
                <>
                  <SearchIcon className="size-16 mx-auto mb-4 opacity-20" />
                  <p className="text-lg">نتیجه‌ای یافت نشد</p>
                  <p className="text-sm mt-2">عبارت دیگری را امتحان کنید</p>
                </>
              ) : (
                <p className="text-lg">خبری یافت نشد</p>
              )}
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-8">
                {articles.map(article => (
                  <ArticleCard key={article.id} article={article} />
                ))}
              </div>
              {!isSearch && (
                <ArticleListClient initialCount={articles.length} sortBy={sortBy} />
              )}
            </>
          )}
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
