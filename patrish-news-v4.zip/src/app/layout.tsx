import type { Metadata, Viewport } from "next";
import { Vazirmatn } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { ThemeProvider } from "@/components/theme-provider";
import { SettingsProvider } from "@/components/settings-provider";
import { ServiceWorkerRegister } from "@/components/sw-register";
import { ImageFixer } from "@/components/image-fixer";

const vazirmatn = Vazirmatn({
  variable: "--font-vazirmatn",
  subsets: ["arabic", "latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "پاتریش نیوز | اخبار روز دنیا، تکنولوژی و گیم",
  description: "دنیای تکنولوژی، ساده و به‌روز - جدیدترین اخبار جهان، تکنولوژی، گیم، علم، ورزش و سرگرمی",
  keywords: ["اخبار", "تکنولوژی", "گیم", "علم", "ورزش", "سرگرمی", "پاتریش نیوز"],
  manifest: "/manifest.json",
  icons: {
    icon: "/logo.svg",
    apple: "/logo.svg",
  },
  openGraph: {
    title: "پاتریش نیوز",
    description: "دنیای تکنولوژی، ساده و به‌روز",
    type: "website",
    locale: "fa_IR",
  },
}

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#0A0E1A" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fa" dir="rtl" suppressHydrationWarning>
      <head>
        {/* PWA: manifest + theme color */}
        <link rel="manifest" href="/manifest.json" />
        <meta name="theme-color" content="#7C3AED" />
        {/* structured data برای SEO (درخواست ۲۴) */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "NewsMediaOrganization",
              "name": "پاتریش نیوز",
              "description": "دنیای تکنولوژی، ساده و به‌روز",
              "url": "/",
              "logo": "/logo.svg",
              "inLanguage": "fa-IR",
            }),
          }}
        />
      </head>
      <body
        className={`${vazirmatn.variable} font-sans antialiased bg-background text-foreground`}
      >
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem={true}
          disableTransitionOnChange={false}
        >
          <SettingsProvider>
            {/* Skip link برای accessibility (درخواست ۲۳) */}
            <a href="#main-content" className="skip-link">پرش به محتوای اصلی</a>
            <div id="main-content">
              {children}
            </div>
            <ServiceWorkerRegister />
            <ImageFixer />
            <Toaster />
            <SonnerToaster position="top-center" richColors closeButton />
          </SettingsProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
