import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { redirect } from 'next/navigation'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { ArticleCard } from '@/components/article-card'
import { Bookmark } from 'lucide-react'

export const metadata = { title: 'ذخیره‌شده‌ها | پاتریش نیوز' }
export const dynamic = "force-dynamic"

export default async function BookmarksPage() {
  const user = await getCurrentUser()
  if (!user) redirect('/login')

  const [categories, bookmarks] = await Promise.all([
    db.category.findMany({
      where: { isActive: true, parentId: null },
      orderBy: { order: 'asc' },
    }),
    db.bookmark.findMany({
      where: { userId: user.id },
      include: {
        article: {
          include: {
            category: { select: { id: true, name: true, slug: true, color: true, icon: true } },
            author: { select: { id: true, username: true, name: true, avatar: true } },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    }),
  ])

  const articles = bookmarks.map(b => b.article).filter(a => a.status === 'PUBLISHED')

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader user={user} categories={categories} />

      <main className="flex-1">
        <div className="border-b border-border/40 bg-muted/20">
          <div className="container mx-auto px-4 py-8">
            <div className="flex items-center gap-3">
              <div className="size-12 rounded-xl bg-primary/15 flex items-center justify-center text-primary">
                <Bookmark className="size-6" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold">اخبار ذخیره‌شده</h1>
                <p className="text-muted-foreground text-sm">اخباری که برای بعد ذخیره کرده‌اید</p>
              </div>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          {articles.length === 0 ? (
            <div className="text-center py-20 text-muted-foreground">
              <Bookmark className="size-16 mx-auto mb-4 opacity-20" />
              <p className="text-lg">هنوز خبری ذخیره نکرده‌اید</p>
              <p className="text-sm mt-2">با کلیک روی آیکن ذخیره در هر خبر، آن را اینجا پیدا کنید</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
              {articles.map(article => (
                <ArticleCard key={article.id} article={article} />
              ))}
            </div>
          )}
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
