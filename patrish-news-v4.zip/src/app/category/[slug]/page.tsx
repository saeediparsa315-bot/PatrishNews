import { db } from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { SiteHeader } from '@/components/site-header'
import { SiteFooter } from '@/components/site-footer'
import { ArticleCard } from '@/components/article-card'
import { ArticleListClient } from '@/components/article-list-client'
import { Globe, Cpu, Gamepad2, Clapperboard, FlaskConical, Trophy, Bitcoin, HeartPulse, Rocket, Newspaper, Landmark, ChevronLeft } from 'lucide-react'

const iconMap: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  Globe, Cpu, Gamepad2, Clapperboard, FlaskConical, Trophy, Bitcoin, HeartPulse, Rocket, Newspaper, Landmark,
}

export const revalidate = 60

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const category = await db.category.findUnique({ where: { slug }, select: { name: true, description: true } })
  if (!category) return { title: 'دسته یافت نشد' }
  return {
    title: `${category.name} | پاتریش نیوز`,
    description: category.description || `آخرین اخبار ${category.name}`,
  }
}

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params
  const user = await getCurrentUser()

  const [categories, category] = await Promise.all([
    db.category.findMany({
      where: { isActive: true, parentId: null },
      orderBy: { order: 'asc' },
    }),
    db.category.findUnique({
      where: { slug },
      include: {
        children: {
          where: { isActive: true },
          select: { id: true, name: true, slug: true, color: true, icon: true },
          orderBy: { order: 'asc' },
        },
      },
    }),
  ])

  if (!category || !category.isActive) {
    notFound()
  }

  const articles = await db.article.findMany({
    where: {
      status: 'PUBLISHED',
      category: { slug },
    },
    include: {
      category: { select: { id: true, name: true, slug: true, color: true, icon: true } },
      author: { select: { id: true, username: true, name: true, avatar: true } },
    },
    orderBy: { publishedAt: 'desc' },
    take: 24,
  })

  const Icon = category.icon ? iconMap[category.icon] : Newspaper

  return (
    <div className="min-h-screen flex flex-col">
      <SiteHeader user={user} categories={categories} />

      <main className="flex-1">
        <div className="relative overflow-hidden border-b border-border/40">
          <div
            className="absolute inset-0 opacity-10"
            style={{ background: `linear-gradient(135deg, ${category.color}, transparent)` }}
          />
          <div className="container mx-auto px-4 py-10 relative">
            <nav className="flex items-center gap-1 text-sm text-muted-foreground mb-4">
              <Link href="/" className="hover:text-foreground">خانه</Link>
              <ChevronLeft className="size-3" />
              <span className="text-foreground">{category.name}</span>
            </nav>
            <div className="flex items-center gap-4">
              <div
                className="size-16 rounded-2xl flex items-center justify-center"
                style={{ backgroundColor: `${category.color}25` }}
              >
                <Icon className="size-8" style={{ color: category.color }} />
              </div>
              <div>
                <h1 className="text-3xl sm:text-4xl font-bold mb-1">{category.name}</h1>
                {category.description && (
                  <p className="text-muted-foreground">{category.description}</p>
                )}
              </div>
            </div>

            {category.children && category.children.length > 0 && (
              <div className="mt-6 flex flex-wrap gap-2">
                {category.children.map(child => {
                  const ChildIcon = child.icon ? iconMap[child.icon] : null
                  return (
                    <Link
                      key={child.id}
                      href={`/category/${child.slug}`}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border hover:bg-muted/40 transition-colors"
                      style={{ borderColor: `${child.color}40` }}
                    >
                      {ChildIcon && <ChildIcon className="size-4" style={{ color: child.color }} />}
                      <span className="text-sm font-medium">{child.name}</span>
                    </Link>
                  )
                })}
              </div>
            )}
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          {articles.length === 0 ? (
            <div className="text-center py-20 text-muted-foreground">
              <Newspaper className="size-16 mx-auto mb-4 opacity-20" />
              <p className="text-lg">خبری در این دسته یافت نشد</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mb-8">
                {articles.map(article => (
                  <ArticleCard
                    key={article.id}
                    article={article}
                    showCategory={false}
                    showViews={!!(user && (user.role === 'ADMIN' || user.role === 'SUPER_ADMIN'))}
                  />
                ))}
              </div>
              <ArticleListClient categorySlug={slug} initialCount={articles.length} />
            </>
          )}
        </div>
      </main>

      <SiteFooter />
    </div>
  )
}
