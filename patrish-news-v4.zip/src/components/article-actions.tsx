'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Heart, Bookmark, Share2, Check } from 'lucide-react'
import { toast } from 'sonner'
import { toPersianDigits } from '@/lib/persian'

interface ArticleActionsProps {
  articleId: string
  initialLikes: number
  initialLiked: boolean
  initialBookmarked: boolean
  isLoggedIn: boolean
}

export function ArticleActions({
  articleId,
  initialLikes,
  initialLiked,
  initialBookmarked,
  isLoggedIn,
}: ArticleActionsProps) {
  const router = useRouter()
  const [likes, setLikes] = useState(initialLikes)
  const [liked, setLiked] = useState(initialLiked)
  const [bookmarked, setBookmarked] = useState(initialBookmarked)
  const [loading, setLoading] = useState<'like' | 'bookmark' | null>(null)
  const [shared, setShared] = useState(false)

  const handleLike = async () => {
    if (!isLoggedIn) {
      toast.info('برای لایک وارد شوید')
      router.push('/login')
      return
    }
    setLoading('like')
    try {
      const res = await fetch('/api/likes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ articleId }),
        credentials: 'include',
      })
      const data = await res.json()
      if (data.success) {
        setLiked(data.data.liked)
        setLikes(prev => data.data.liked ? prev + 1 : prev - 1)
      } else {
        toast.error(data.error || 'خطا')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setLoading(null)
    }
  }

  const handleBookmark = async () => {
    if (!isLoggedIn) {
      toast.info('برای ذخیره وارد شوید')
      router.push('/login')
      return
    }
    setLoading('bookmark')
    try {
      const res = await fetch('/api/bookmarks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ articleId }),
        credentials: 'include',
      })
      const data = await res.json()
      if (data.success) {
        setBookmarked(data.data.bookmarked)
        toast.success(data.data.bookmarked ? 'ذخیره شد' : 'از ذخیره‌ها حذف شد')
      } else {
        toast.error(data.error || 'خطا')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setLoading(null)
    }
  }

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: document.title,
          url: window.location.href,
        })
      } catch {
        // user cancelled
      }
    } else {
      await navigator.clipboard.writeText(window.location.href)
      setShared(true)
      toast.success('لینک کپی شد')
      setTimeout(() => setShared(false), 2000)
    }
  }

  return (
    <div className="flex items-center gap-3 py-4 border-y border-border/40">
      <Button
        variant={liked ? 'default' : 'outline'}
        size="lg"
        onClick={handleLike}
        disabled={loading === 'like'}
        className="gap-2"
      >
        <Heart className={`size-5 ${liked ? 'fill-current' : ''}`} />
        {toPersianDigits(likes)}
      </Button>

      <Button
        variant={bookmarked ? 'default' : 'outline'}
        size="lg"
        onClick={handleBookmark}
        disabled={loading === 'bookmark'}
        className="gap-2"
      >
        <Bookmark className={`size-5 ${bookmarked ? 'fill-current' : ''}`} />
        {bookmarked ? 'ذخیره شده' : 'ذخیره'}
      </Button>

      <Button
        variant="outline"
        size="lg"
        onClick={handleShare}
        className="gap-2"
      >
        {shared ? <Check className="size-5" /> : <Share2 className="size-5" />}
        اشتراک‌گذاری
      </Button>
    </div>
  )
}
