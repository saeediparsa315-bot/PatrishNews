'use client'

import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'

interface SiteSettings {
  site_name: string
  site_description: string
  site_logo_text: string
  primary_color: string
  accent_color: string
  footer_text: string
  social_twitter: string
  social_telegram: string
  social_instagram: string
  social_youtube: string
  contact_email: string
  comments_enabled: string
  comments_require_approval: string
  default_seo_title: string
  default_seo_description: string
  default_seo_keywords: string
}

const DEFAULT_SETTINGS: SiteSettings = {
  site_name: 'پاتریش نیوز',
  site_description: 'دنیای تکنولوژی، ساده و به‌روز',
  site_logo_text: 'پاتریش',
  primary_color: '#7C3AED',
  accent_color: '#06B6D4',
  footer_text: '© ۱۴۰۵ پاتریش نیوز - تمامی حقوق محفوظ است',
  social_twitter: '',
  social_telegram: 'https://t.me/PCnewsF',
  social_instagram: '',
  social_youtube: '',
  contact_email: 'info@patrishnews.ir',
  comments_enabled: 'true',
  comments_require_approval: 'true',
  default_seo_title: 'پاتریش نیوز | اخبار روز دنیا، تکنولوژی و گیم',
  default_seo_description: 'جدیدترین اخبار جهان، تکنولوژی، گیم، علم، ورزش و سرگرمی را در پاتریش نیوز دنبال کنید',
  default_seo_keywords: 'اخبار,تکنولوژی,گیم,علم,ورزش,سرگرمی,پاتریش نیوز',
}

const SettingsContext = createContext<{
  settings: SiteSettings
  refresh: () => void
}>({
  settings: DEFAULT_SETTINGS,
  refresh: () => {},
})

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SETTINGS)

  const refresh = () => {
    fetch('/api/settings')
      .then(r => r.json())
      .then(data => {
        if (data.success && data.data) {
          // Filter to only known keys to avoid extra keys like newsletter_enabled
          const filtered: Partial<SiteSettings> = {}
          for (const key of Object.keys(DEFAULT_SETTINGS) as (keyof SiteSettings)[]) {
            if (data.data[key] !== undefined) {
              filtered[key] = data.data[key]
            }
          }
          setSettings({ ...DEFAULT_SETTINGS, ...filtered })
        }
      })
      .catch(() => {})
  }

  useEffect(() => {
    refresh()
  }, [])

  return (
    <SettingsContext.Provider value={{ settings, refresh }}>
      {children}
    </SettingsContext.Provider>
  )
}

export function useSettings() {
  return useContext(SettingsContext)
}
