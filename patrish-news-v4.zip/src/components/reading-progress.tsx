'use client'

import { useState, useEffect } from 'react'

export function ReadingProgress() {
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const article = document.querySelector('article') || document.querySelector('#main-content')
      if (!article) return

      const articleTop = article.offsetTop
      const articleHeight = article.offsetHeight
      const windowHeight = window.innerHeight
      const scrollY = window.scrollY

      // محاسبه درصد پیشرفت
      const totalScrollable = articleHeight - windowHeight
      const currentScroll = scrollY - articleTop

      if (currentScroll <= 0) {
        setProgress(0)
      } else if (currentScroll >= totalScrollable) {
        setProgress(100)
      } else {
        setProgress((currentScroll / totalScrollable) * 100)
      }
    }

    window.addEventListener('scroll', handleScroll, { passive: true })
    window.addEventListener('resize', handleScroll)
    handleScroll()

    return () => {
      window.removeEventListener('scroll', handleScroll)
      window.removeEventListener('resize', handleScroll)
    }
  }, [])

  return (
    <div
      className="reading-progress"
      style={{ width: `${progress}%` }}
      role="progressbar"
      aria-valuenow={Math.round(progress)}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label="پیشرفت مطالعه"
    />
  )
}
