'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { MessageCircle, Send, Trash2, AlertCircle, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { formatRelativeTime, toPersianDigits } from '@/lib/persian'
import Link from 'next/link'

interface Comment {
  id: string
  content: string
  createdAt: string | Date
  user: {
    id: string
    username: string
    name: string | null
    avatar: string | null
  }
  replies?: Comment[]
}

interface CommentsSectionProps {
  articleId: string
  comments: Comment[]
  isLoggedIn: boolean
}

export function CommentsSection({ articleId, comments: initialComments, isLoggedIn }: CommentsSectionProps) {
  const router = useRouter()
  const [comments, setComments] = useState(initialComments)
  const [content, setContent] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [replyTo, setReplyTo] = useState<string | null>(null)
  const [replyContent, setReplyContent] = useState('')

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!content.trim()) return
    setSubmitting(true)
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, articleId }),
        credentials: 'include',
      })
      const data = await res.json()
      if (data.success) {
        toast.success(data.data.status === 'APPROVED'
          ? 'نظر شما ثبت شد'
          : 'نظر شما ثبت شد و پس از تأیید نمایش داده می‌شود')
        setContent('')
        // Add to local state if approved
        if (data.data.status === 'APPROVED') {
          setComments(prev => [data.data, ...prev])
        }
      } else {
        toast.error(data.error || 'خطا در ثبت نظر')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setSubmitting(false)
    }
  }

  const handleReply = async (parentId: string) => {
    if (!replyContent.trim()) return
    setSubmitting(true)
    try {
      const res = await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: replyContent, articleId, parentId }),
        credentials: 'include',
      })
      const data = await res.json()
      if (data.success) {
        toast.success(data.data.status === 'APPROVED'
          ? 'پاسخ شما ثبت شد'
          : 'پاسخ شما ثبت شد و پس از تأیید نمایش داده می‌شود')
        setReplyContent('')
        setReplyTo(null)
        if (data.data.status === 'APPROVED') {
          setComments(prev => prev.map(c => {
            if (c.id === parentId) {
              return { ...c, replies: [...(c.replies || []), data.data] }
            }
            return c
          }))
        }
      } else {
        toast.error(data.error || 'خطا')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setSubmitting(false)
    }
  }

  const handleDelete = async (commentId: string) => {
    if (!confirm('آیا از حذف این نظر مطمئن هستید؟')) return
    try {
      const res = await fetch(`/api/comments/${commentId}`, { method: 'DELETE', credentials: 'include' })
      const data = await res.json()
      if (data.success) {
        setComments(prev => prev.filter(c => c.id !== commentId))
        toast.success('نظر حذف شد')
      } else {
        toast.error(data.error || 'خطا')
      }
    } catch {
      toast.error('خطا در ارتباط')
    }
  }

  return (
    <section className="mt-12 pt-8 border-t">
      <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
        <MessageCircle className="size-5" />
        نظرات ({toPersianDigits(comments.length)})
      </h2>

      {/* Comment form */}
      {isLoggedIn ? (
        <form onSubmit={handleSubmit} className="mb-8">
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="نظر خود را بنویسید..."
            rows={4}
            maxLength={1000}
            className="mb-2"
          />
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">
              {toPersianDigits(content.length)}/۱۰۰۰
            </span>
            <Button type="submit" disabled={submitting || !content.trim()} size="sm">
              {submitting ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
              ارسال نظر
            </Button>
          </div>
        </form>
      ) : (
        <div className="mb-8 p-4 rounded-lg border border-dashed text-center text-sm text-muted-foreground">
          برای نظر دادن{' '}
          <Link href="/login" className="text-primary hover:underline font-medium">وارد شوید</Link>
        </div>
      )}

      {/* Comments list */}
      {comments.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">
          <MessageCircle className="size-12 mx-auto mb-3 opacity-30" />
          <p>هنوز نظری ثبت نشده است. اولین نفر باشید!</p>
        </div>
      ) : (
        <div className="space-y-6">
          {comments.map(comment => (
            <div key={comment.id} className="space-y-3">
              <CommentItem
                comment={comment}
                isLoggedIn={isLoggedIn}
                onReply={() => setReplyTo(replyTo === comment.id ? null : comment.id)}
                onDelete={() => handleDelete(comment.id)}
              />

              {/* Reply form */}
              {replyTo === comment.id && isLoggedIn && (
                <div className="pr-12">
                  <Textarea
                    value={replyContent}
                    onChange={(e) => setReplyContent(e.target.value)}
                    placeholder={`پاسخ به ${comment.user.name || comment.user.username}...`}
                    rows={3}
                    maxLength={1000}
                    className="mb-2"
                  />
                  <div className="flex gap-2 justify-end">
                    <Button variant="ghost" size="sm" onClick={() => { setReplyTo(null); setReplyContent('') }}>
                      انصراف
                    </Button>
                    <Button size="sm" onClick={() => handleReply(comment.id)} disabled={submitting || !replyContent.trim()}>
                      {submitting ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
                      ارسال پاسخ
                    </Button>
                  </div>
                </div>
              )}

              {/* Replies */}
              {comment.replies && comment.replies.length > 0 && (
                <div className="pr-12 space-y-3">
                  {comment.replies.map(reply => (
                    <CommentItem
                      key={reply.id}
                      comment={reply}
                      isLoggedIn={isLoggedIn}
                      isReply
                      onDelete={() => handleDelete(reply.id)}
                    />
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </section>
  )
}

function CommentItem({
  comment,
  isLoggedIn,
  isReply,
  onReply,
  onDelete,
}: {
  comment: Comment
  isLoggedIn: boolean
  isReply?: boolean
  onReply?: () => void
  onDelete: () => void
}) {
  return (
    <div className={`flex gap-3 ${isReply ? '' : ''}`}>
      <Avatar className="size-10 shrink-0">
        <AvatarFallback className="bg-primary/15 text-primary text-xs">
          {(comment.user.name || comment.user.username).charAt(0)}
        </AvatarFallback>
      </Avatar>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1 flex-wrap">
          <span className="font-semibold text-sm">{comment.user.name || comment.user.username}</span>
          <span className="text-xs text-muted-foreground">{formatRelativeTime(comment.createdAt)}</span>
        </div>
        <div className="text-sm leading-relaxed whitespace-pre-wrap break-words">{comment.content}</div>
        {isLoggedIn && onReply && !isReply && (
          <button
            onClick={onReply}
            className="text-xs text-muted-foreground hover:text-primary mt-2"
          >
            پاسخ دادن
          </button>
        )}
      </div>
      <Button
        variant="ghost"
        size="icon"
        className="size-8 shrink-0 text-muted-foreground hover:text-destructive"
        onClick={onDelete}
      >
        <Trash2 className="size-4" />
      </Button>
    </div>
  )
}
