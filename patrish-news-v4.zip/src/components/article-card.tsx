'use client'

import Link from 'next/link'
import { Clock, Eye, Heart, MessageCircle } from 'lucide-react'
import { formatRelativeTime, formatNumber, toPersianDigits } from '@/lib/persian'
import type { ArticleWithRelations } from '@/lib/types'

interface ArticleCardProps {
  article: ArticleWithRelations
  variant?: 'default' | 'compact' | 'hero' | 'minimal' | 'horizontal'
  showCategory?: boolean
  showExcerpt?: boolean
  showViews?: boolean  // تعداد بازدید فقط برای ادمین
}

// کامپوننت تصویر با fallback
function ArticleImage({
  src,
  alt,
  className,
  priority,
  sizes,
}: {
  src: string
  alt: string
  className?: string
  priority?: boolean
  sizes?: string
}) {
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={src}
      alt={alt}
      className={className}
      loading="eager"
      decoding="async"
      onError={(e) => {
        // fallback: نمایش یک تصویر placeholder زیبا
        const target = e.target as HTMLImageElement
        target.onerror = null // جلوگیری از loop
        target.src = 'data:image/svg+xml;utf8,' + encodeURIComponent(`
          <svg xmlns="http://www.w3.org/2000/svg" width="400" height="225" viewBox="0 0 400 225">
            <defs>
              <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style="stop-color:#7C3AED;stop-opacity:0.6"/>
                <stop offset="100%" style="stop-color:#06B6D4;stop-opacity:0.6"/>
              </linearGradient>
            </defs>
            <rect width="400" height="225" fill="url(#g)"/>
            <text x="50%" y="48%" fill="#fff" font-family="Arial" font-size="22" text-anchor="middle" dy=".3em" font-weight="bold" opacity="0.95">پاتریش نیوز</text>
            <text x="50%" y="60%" fill="#fff" font-family="Arial" font-size="11" text-anchor="middle" dy=".3em" opacity="0.7">دنیای تکنولوژی، ساده و به‌روز</text>
          </svg>
        `)
      }}
    />
  )
}

export function ArticleCard({
  article,
  variant = 'default',
  showCategory = true,
  showExcerpt = true,
  showViews = false,
}: ArticleCardProps) {
  const href = `/article/${article.slug}`

  if (variant === 'hero') {
    return (
      <Link href={href} className="group relative block overflow-hidden rounded-2xl h-[400px] sm:h-[500px] hover-scale">
        <div className="absolute inset-0">
          {article.coverImage ? (
            <ArticleImage
              src={article.coverImage}
              alt={article.title}
              className="size-full object-cover transition-transform duration-700 group-hover:scale-105"
              priority
            />
          ) : (
            <div className="size-full gradient-bg" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent" />
        </div>

        <div className="relative h-full flex flex-col justify-end p-6 sm:p-8">
          <div className="flex items-center gap-2 mb-3">
            {article.isBreaking && (
              <span className="px-2.5 py-1 rounded-md bg-destructive text-destructive-foreground text-xs font-bold animate-pulse">
                فوری
              </span>
            )}
            {showCategory && article.category && (
              <span
                className="px-2.5 py-1 rounded-md text-xs font-semibold backdrop-blur-md"
                style={{
                  backgroundColor: `${article.category.color}40`,
                  color: '#fff',
                  border: `1px solid ${article.category.color}`,
                }}
              >
                {article.category.name}
              </span>
            )}
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white mb-3 leading-tight line-clamp-3">
            {article.title}
          </h2>
          {showExcerpt && article.excerpt && (
            <p className="text-sm sm:text-base text-white/80 line-clamp-2 mb-4 max-w-3xl">
              {article.excerpt}
            </p>
          )}
          <div className="flex items-center gap-4 text-xs text-white/70">
            {article.author && (
              <span>{article.author.name || article.author.username}</span>
            )}
            <span className="flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              {formatRelativeTime(article.publishedAt || article.createdAt)}
            </span>
            {showViews && (
              <span className="flex items-center gap-1">
                <Eye className="h-3.5 w-3.5" />
                {formatNumber(article.viewCount)}
              </span>
            )}
            <span className="hidden sm:flex items-center gap-1">
              <MessageCircle className="h-3.5 w-3.5" />
              {toPersianDigits(article.commentCount)}
            </span>
          </div>
        </div>
      </Link>
    )
  }

  if (variant === 'horizontal') {
    return (
      <Link href={href} className="group flex gap-4 items-start hover-scale">
        <div className="relative size-24 sm:size-28 shrink-0 overflow-hidden rounded-lg bg-muted">
          {article.coverImage ? (
            <ArticleImage
              src={article.coverImage}
              alt={article.title}
              className="size-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
          ) : (
            <div className="size-full gradient-bg opacity-30 flex items-center justify-center">
              <span className="text-xs text-white/50">پاتریش</span>
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          {showCategory && article.category && (
            <span
              className="inline-block text-xs font-semibold mb-1"
              style={{ color: article.category.color }}
            >
              {article.category.name}
            </span>
          )}
          <h3 className="font-semibold leading-snug line-clamp-2 group-hover:text-primary transition-colors">
            {article.title}
          </h3>
          <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {formatRelativeTime(article.publishedAt || article.createdAt)}
            </span>
            {showViews && (
              <span className="flex items-center gap-1">
                <Eye className="h-3 w-3" />
                {formatNumber(article.viewCount)}
              </span>
            )}
          </div>
        </div>
      </Link>
    )
  }

  if (variant === 'compact') {
    return (
      <Link href={href} className="group block hover-scale">
        <div className="relative aspect-[16/10] mb-3 overflow-hidden rounded-lg bg-muted">
          {article.coverImage ? (
            <ArticleImage
              src={article.coverImage}
              alt={article.title}
              className="size-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
          ) : (
            <div className="size-full gradient-bg opacity-30 flex items-center justify-center">
              <span className="text-sm text-white/50">پاتریش نیوز</span>
            </div>
          )}
          {article.isBreaking && (
            <span className="absolute top-2 right-2 px-2 py-0.5 rounded bg-destructive text-destructive-foreground text-xs font-bold animate-pulse">
              فوری
            </span>
          )}
        </div>
        {showCategory && article.category && (
          <span
            className="text-xs font-semibold mb-1 block"
            style={{ color: article.category.color }}
          >
            {article.category.name}
          </span>
        )}
        <h3 className="font-semibold leading-snug line-clamp-2 group-hover:text-primary transition-colors">
          {article.title}
        </h3>
        <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {formatRelativeTime(article.publishedAt || article.createdAt)}
          </span>
          {showViews && (
            <span className="flex items-center gap-1">
              <Eye className="h-3 w-3" />
              {formatNumber(article.viewCount)}
            </span>
          )}
        </div>
      </Link>
    )
  }

  if (variant === 'minimal') {
    return (
      <Link href={href} className="group block py-3 border-b border-border/40 last:border-0">
        <h3 className="font-medium leading-snug line-clamp-2 group-hover:text-primary transition-colors">
          {article.title}
        </h3>
        <div className="mt-1.5 text-xs text-muted-foreground flex items-center gap-2">
          {showCategory && article.category && (
            <span style={{ color: article.category.color }}>{article.category.name}</span>
          )}
          <span>•</span>
          <span>{formatRelativeTime(article.publishedAt || article.createdAt)}</span>
        </div>
      </Link>
    )
  }

  // Default
  return (
    <Link href={href} className="group block overflow-hidden rounded-xl border border-border/40 bg-card hover:border-primary/40 hover:shadow-lg transition-all duration-300 hover-scale">
      <div className="relative aspect-[16/10] overflow-hidden bg-muted">
        {article.coverImage ? (
          <ArticleImage
            src={article.coverImage}
            alt={article.title}
            className="size-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
        ) : (
          <div className="size-full gradient-bg opacity-30 flex items-center justify-center">
            <span className="text-sm text-white/50">پاتریش نیوز</span>
          </div>
        )}
        <div className="absolute top-3 right-3 flex gap-2">
          {article.isBreaking && (
            <span className="px-2 py-1 rounded bg-destructive text-destructive-foreground text-xs font-bold animate-pulse">
              فوری
            </span>
          )}
          {article.isFeatured && !article.isBreaking && (
            <span className="px-2 py-1 rounded bg-accent text-accent-foreground text-xs font-bold">
              ویژه
            </span>
          )}
        </div>
        {showCategory && article.category && (
          <span
            className="absolute bottom-3 right-3 px-2.5 py-1 rounded-md text-xs font-semibold backdrop-blur-md"
            style={{
              backgroundColor: `${article.category.color}40`,
              color: '#fff',
              border: `1px solid ${article.category.color}`,
            }}
          >
            {article.category.name}
          </span>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-bold leading-snug line-clamp-2 group-hover:text-primary transition-colors mb-2">
          {article.title}
        </h3>
        {showExcerpt && article.excerpt && (
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
            {article.excerpt}
          </p>
        )}
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          {article.author && (
            <span className="font-medium">{article.author.name || article.author.username}</span>
          )}
          <span className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {formatRelativeTime(article.publishedAt || article.createdAt)}
          </span>
          {showViews && (
            <span className="flex items-center gap-1">
              <Eye className="h-3 w-3" />
              {formatNumber(article.viewCount)}
            </span>
          )}
          <span className="flex items-center gap-1">
            <Heart className="h-3 w-3" />
            {toPersianDigits(article.likeCount)}
          </span>
        </div>
      </div>
    </Link>
  )
}
