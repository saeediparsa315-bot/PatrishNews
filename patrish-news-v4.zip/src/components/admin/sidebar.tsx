'use client'

import { useState } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  LayoutDashboard, FileText, FolderTree, Tags, Users, MessageSquare,
  Settings, ScrollText, Menu, X, Home, Eye, Plus, LogOut, ShieldCheck, Activity, LayoutGrid, DatabaseBackup,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet'
import type { SessionUser } from '@/lib/types'

interface AdminCategory {
  id: string
  name: string
  slug: string
  color: string
  icon: string | null
  _count: { articles: number }
}

interface NavItem {
  href: string
  label: string
  icon: React.ComponentType<{ className?: string }>
  superAdminOnly?: boolean
}

const navItems: NavItem[] = [
  { href: '/admin', label: 'داشبورد', icon: LayoutDashboard },
  { href: '/admin/analytics', label: 'آمار و اطلاعات سایت', icon: Activity, superAdminOnly: true },
  { href: '/admin/articles', label: 'مدیریت اخبار', icon: FileText },
  { href: '/admin/articles/new', label: 'افزودن خبر', icon: Plus },
  { href: '/admin/layout', label: 'چیدمان دستی صفحه اصلی', icon: LayoutGrid },
  { href: '/admin/categories', label: 'دسته‌بندی‌ها', icon: FolderTree },
  { href: '/admin/tags', label: 'برچسب‌ها', icon: Tags },
  { href: '/admin/comments', label: 'نظرات', icon: MessageSquare },
  { href: '/admin/users', label: 'کاربران', icon: Users, superAdminOnly: true },
  { href: '/admin/backup', label: 'بک‌آپ‌گیری و بازیابی', icon: DatabaseBackup, superAdminOnly: true },
  { href: '/admin/settings', label: 'تنظیمات سایت', icon: Settings, superAdminOnly: true },
  { href: '/admin/audit-logs', label: 'لاگ فعالیت‌ها', icon: ScrollText, superAdminOnly: true },
]

export function AdminSidebar({
  user,
  categories,
}: {
  user: SessionUser
  categories: AdminCategory[]
}) {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  const filteredNav = navItems.filter(item => !item.superAdminOnly || user.role === 'SUPER_ADMIN')

  const content = (
    <div className="flex h-full flex-col bg-card border-l">
      {/* Logo */}
      <div className="p-5 border-b">
        <Link href="/" className="flex items-center gap-2">
          <div className="size-10 rounded-xl gradient-bg flex items-center justify-center text-white font-bold glow">
            پ
          </div>
          <div>
            <div className="font-bold text-lg">پنل مدیریت</div>
            <div className="text-xs text-muted-foreground">پاتریش نیوز</div>
          </div>
        </Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto p-3 no-scrollbar">
        <div className="space-y-1">
          {filteredNav.map(item => {
            const active = pathname === item.href ||
              (item.href !== '/admin' && pathname.startsWith(item.href))
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  active
                    ? 'bg-primary text-primary-foreground shadow-sm'
                    : 'hover:bg-muted text-foreground'
                }`}
              >
                <item.icon className="size-4" />
                {item.label}
              </Link>
            )
          })}
        </div>

        {/* Categories overview */}
        <div className="mt-6 pt-6 border-t">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2 px-3">
            دسته‌ها
          </div>
          <div className="space-y-0.5">
            {categories.map(cat => (
              <Link
                key={cat.id}
                href={`/admin/articles?category=${cat.slug}`}
                onClick={() => setOpen(false)}
                className="flex items-center gap-2 px-3 py-2 rounded-md text-sm hover:bg-muted transition-colors"
              >
                <div
                  className="size-2 rounded-full"
                  style={{ backgroundColor: cat.color }}
                />
                <span className="flex-1 truncate">{cat.name}</span>
                <span className="text-xs text-muted-foreground">
                  {cat._count.articles}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </nav>

      {/* Footer */}
      <div className="p-3 border-t space-y-1">
        <Link href="/" className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm hover:bg-muted">
          <Home className="size-4" />
          مشاهده سایت
        </Link>
        <Link href="/profile" className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm hover:bg-muted">
          <Eye className="size-4" />
          پروفایل
        </Link>
      </div>
    </div>
  )

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden lg:block fixed inset-y-0 right-0 w-72 z-30">
        {content}
      </aside>

      {/* Mobile sidebar (Sheet) */}
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button
            variant="outline"
            size="icon"
            className="lg:hidden fixed top-4 right-4 z-40"
            aria-label="منو"
          >
            <Menu className="size-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="right" className="w-[280px] p-0">
          <SheetTitle className="sr-only">منوی پنل مدیریت</SheetTitle>
          {content}
        </SheetContent>
      </Sheet>
    </>
  )
}
