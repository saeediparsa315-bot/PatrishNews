'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Save, Loader2, Palette, Settings as SettingsIcon, Share2, MessageSquare, Mail } from 'lucide-react'
import { toast } from 'sonner'

interface Settings {
  [key: string]: string
}

export function SettingsManager({ initialSettings }: { initialSettings: Settings }) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [settings, setSettings] = useState<Settings>(initialSettings)

  const update = (key: string, value: string) => {
    setSettings(prev => ({ ...prev, [key]: value }))
  }

  const handleSave = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
        credentials: 'include',
      })
      const data = await res.json()
      if (data.success) {
        toast.success('تنظیمات ذخیره شد')
        router.refresh()
      } else {
        toast.error(data.error || 'خطا')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="general">
        <TabsList>
          <TabsTrigger value="general" className="gap-2">
            <SettingsIcon className="size-4" />
            عمومی
          </TabsTrigger>
          <TabsTrigger value="appearance" className="gap-2">
            <Palette className="size-4" />
            ظاهر
          </TabsTrigger>
          <TabsTrigger value="comments" className="gap-2">
            <MessageSquare className="size-4" />
            نظرات
          </TabsTrigger>
          <TabsTrigger value="social" className="gap-2">
            <Share2 className="size-4" />
            شبکه‌های اجتماعی
          </TabsTrigger>
          <TabsTrigger value="seo" className="gap-2">
            <Mail className="size-4" />
            سئو
          </TabsTrigger>
        </TabsList>

        {/* General */}
        <TabsContent value="general">
          <Card>
            <CardHeader>
              <CardTitle>تنظیمات عمومی</CardTitle>
              <CardDescription>اطلاعات اصلی سایت</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 max-w-2xl">
              <div className="space-y-2">
                <Label htmlFor="site_name">نام سایت</Label>
                <Input id="site_name" value={settings.site_name || ''} onChange={(e) => update('site_name', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="site_logo_text">متن لوگو</Label>
                <Input id="site_logo_text" value={settings.site_logo_text || ''} onChange={(e) => update('site_logo_text', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="site_description">توضیحات سایت</Label>
                <Textarea id="site_description" value={settings.site_description || ''} onChange={(e) => update('site_description', e.target.value)} rows={2} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="footer_text">متن فوتر</Label>
                <Input id="footer_text" value={settings.footer_text || ''} onChange={(e) => update('footer_text', e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="contact_email">ایمیل تماس</Label>
                <Input id="contact_email" type="email" value={settings.contact_email || ''} onChange={(e) => update('contact_email', e.target.value)} dir="ltr" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Appearance */}
        <TabsContent value="appearance">
          <Card>
            <CardHeader>
              <CardTitle>رنگ‌ها و ظاهر</CardTitle>
              <CardDescription>تنظیمات رنگ سایت</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 max-w-2xl">
              <div className="space-y-2">
                <Label htmlFor="primary_color">رنگ اصلی</Label>
                <div className="flex items-center gap-3">
                  <Input id="primary_color" type="color" value={settings.primary_color || '#7C3AED'} onChange={(e) => update('primary_color', e.target.value)} className="w-20 h-10 p-1" />
                  <Input value={settings.primary_color || ''} onChange={(e) => update('primary_color', e.target.value)} dir="ltr" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="accent_color">رنگ اکسنت</Label>
                <div className="flex items-center gap-3">
                  <Input id="accent_color" type="color" value={settings.accent_color || '#06B6D4'} onChange={(e) => update('accent_color', e.target.value)} className="w-20 h-10 p-1" />
                  <Input value={settings.accent_color || ''} onChange={(e) => update('accent_color', e.target.value)} dir="ltr" />
                </div>
              </div>
              <div className="p-4 rounded-lg border bg-muted/30">
                <div className="text-sm font-medium mb-2">پیش‌نمایش</div>
                <div className="flex items-center gap-3">
                  <div className="size-10 rounded-lg flex items-center justify-center text-white" style={{ backgroundColor: settings.primary_color }}>
                    ا
                  </div>
                  <Button style={{ backgroundColor: settings.primary_color }}>دکمه اصلی</Button>
                  <Button style={{ backgroundColor: settings.accent_color }}>دکمه اکسنت</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Comments */}
        <TabsContent value="comments">
          <Card>
            <CardHeader>
              <CardTitle>تنظیمات نظرات</CardTitle>
              <CardDescription>مدیریت سیستم نظرات</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 max-w-2xl">
              <div className="flex items-center justify-between p-3 rounded-lg border">
                <div>
                  <Label htmlFor="comments_enabled">فعال بودن نظرات</Label>
                  <p className="text-sm text-muted-foreground">کاربران بتوانند نظر ثبت کنند</p>
                </div>
                <Switch
                  id="comments_enabled"
                  checked={settings.comments_enabled === 'true'}
                  onCheckedChange={(v) => update('comments_enabled', v ? 'true' : 'false')}
                />
              </div>
              <div className="flex items-center justify-between p-3 rounded-lg border">
                <div>
                  <Label htmlFor="comments_require_approval">تأیید قبل از نمایش</Label>
                  <p className="text-sm text-muted-foreground">نظرات قبل از نمایش باید توسط ادمین تأیید شوند</p>
                </div>
                <Switch
                  id="comments_require_approval"
                  checked={settings.comments_require_approval === 'true'}
                  onCheckedChange={(v) => update('comments_require_approval', v ? 'true' : 'false')}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Social */}
        <TabsContent value="social">
          <Card>
            <CardHeader>
              <CardTitle>شبکه‌های اجتماعی</CardTitle>
              <CardDescription>لینک‌های شبکه‌های اجتماعی در فوتر نمایش داده می‌شوند</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 max-w-2xl">
              <div className="space-y-2">
                <Label htmlFor="social_telegram">تلگرام</Label>
                <Input id="social_telegram" value={settings.social_telegram || ''} onChange={(e) => update('social_telegram', e.target.value)} placeholder="https://t.me/..." dir="ltr" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="social_instagram">اینستاگرام</Label>
                <Input id="social_instagram" value={settings.social_instagram || ''} onChange={(e) => update('social_instagram', e.target.value)} placeholder="https://instagram.com/..." dir="ltr" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="social_twitter">توییتر / X</Label>
                <Input id="social_twitter" value={settings.social_twitter || ''} onChange={(e) => update('social_twitter', e.target.value)} placeholder="https://twitter.com/..." dir="ltr" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="social_youtube">یوتیوب</Label>
                <Input id="social_youtube" value={settings.social_youtube || ''} onChange={(e) => update('social_youtube', e.target.value)} placeholder="https://youtube.com/..." dir="ltr" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* SEO */}
        <TabsContent value="seo">
          <Card>
            <CardHeader>
              <CardTitle>تنظیمات سئو</CardTitle>
              <CardDescription>تنظیمات پیش‌فرض برای موتورهای جستجو</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 max-w-2xl">
              <div className="space-y-2">
                <Label htmlFor="default_seo_title">عنوان پیش‌فرض سئو</Label>
                <Input id="default_seo_title" value={settings.default_seo_title || ''} onChange={(e) => update('default_seo_title', e.target.value)} maxLength={60} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="default_seo_description">توضیحات پیش‌فرض سئو</Label>
                <Textarea id="default_seo_description" value={settings.default_seo_description || ''} onChange={(e) => update('default_seo_description', e.target.value)} rows={3} maxLength={160} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="default_seo_keywords">کلمات کلیدی پیش‌فرض</Label>
                <Input id="default_seo_keywords" value={settings.default_seo_keywords || ''} onChange={(e) => update('default_seo_keywords', e.target.value)} placeholder="کلمات با کاما جدا شوند" />
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Save button - sticky */}
      <div className="sticky bottom-4 flex justify-end">
        <Button onClick={handleSave} disabled={loading} size="lg" className="shadow-lg">
          {loading ? <Loader2 className="size-4 ml-2 animate-spin" /> : <Save className="size-4 ml-2" />}
          ذخیره تنظیمات
        </Button>
      </div>
    </div>
  )
}
