'use client'

import { useState, useMemo } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Search, Shield, ShieldCheck, Ban, Trash2, ShieldAlert, UserCheck, Filter } from 'lucide-react'
import { toast } from 'sonner'
import { formatPersianDate, formatRelativeTime, toPersianDigits } from '@/lib/persian'
import type { SessionUser } from '@/lib/types'

interface User {
  id: string
  email: string
  username: string
  name: string | null
  avatar: string | null
  role: string
  isBlocked: boolean
  createdAt: Date | string
  _count: { articles: number; comments: number; bookmarks: number }
}

interface Props {
  users: User[]
  currentUser: SessionUser
}

export function UsersManager({ users, currentUser }: Props) {
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState('all')
  const [target, setTarget] = useState<User | null>(null)
  const [action, setAction] = useState<'SET_ROLE' | 'BLOCK' | 'UNBLOCK' | 'DELETE' | null>(null)
  const [newRole, setNewRole] = useState('USER')
  const [loading, setLoading] = useState(false)

  const filtered = useMemo(() => {
    return users.filter(u => {
      if (search) {
        const q = search.toLowerCase()
        if (!u.email.toLowerCase().includes(q) &&
            !u.username.toLowerCase().includes(q) &&
            !(u.name || '').toLowerCase().includes(q)) return false
      }
      if (roleFilter !== 'all' && u.role !== roleFilter) return false
      return true
    })
  }, [users, search, roleFilter])

  const openAction = (user: User, act: 'SET_ROLE' | 'BLOCK' | 'UNBLOCK' | 'DELETE') => {
    setTarget(user)
    setAction(act)
    setNewRole(user.role)
  }

  const handleConfirm = async () => {
    if (!target || !action) return
    setLoading(true)
    try {
      const body: Record<string, unknown> = { userId: target.id, action }
      if (action === 'SET_ROLE') body.value = newRole

      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        credentials: 'include',
      })
      const data = await res.json()
      if (data.success) {
        toast.success('عملیات با موفقیت انجام شد')
        setTarget(null)
        setAction(null)
        window.location.reload()
      } else {
        toast.error(data.error || 'خطا')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setLoading(false)
    }
  }

  const roleLabels: Record<string, { label: string; color: string; icon: React.ComponentType<{ className?: string }> }> = {
    SUPER_ADMIN: { label: 'سوپر ادمین', color: 'bg-primary/15 text-primary', icon: ShieldCheck },
    ADMIN: { label: 'ادمین', color: 'bg-cyan-500/15 text-cyan-600', icon: Shield },
    USER: { label: 'کاربر', color: 'bg-muted text-muted-foreground', icon: UserCheck },
  }

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <Input
            placeholder="جستجو بر اساس نام، ایمیل یا نام کاربری..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10"
          />
        </div>
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-full sm:w-44">
            <Filter className="size-4 ml-2" />
            <SelectValue placeholder="نقش" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه نقش‌ها</SelectItem>
            <SelectItem value="SUPER_ADMIN">سوپر ادمین</SelectItem>
            <SelectItem value="ADMIN">ادمین</SelectItem>
            <SelectItem value="USER">کاربر</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Desktop table */}
      <div className="hidden md:block rounded-xl border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-right">کاربر</TableHead>
              <TableHead className="text-right">نام کاربری</TableHead>
              <TableHead className="text-right">نقش</TableHead>
              <TableHead className="text-right">آمار</TableHead>
              <TableHead className="text-right">عضویت</TableHead>
              <TableHead className="text-right">عملیات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                  کاربری یافت نشد
                </TableCell>
              </TableRow>
            ) : filtered.map(u => {
              const role = roleLabels[u.role] || roleLabels.USER
              const isSelf = u.id === currentUser.id
              return (
                <TableRow key={u.id} className={u.isBlocked ? 'opacity-60' : ''}>
                  <TableCell>
                    <div className="flex items-center gap-3">
                      <div className="size-10 rounded-full bg-primary/15 flex items-center justify-center text-sm font-bold text-primary shrink-0">
                        {(u.name || u.username).charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <div className="font-medium line-clamp-1">
                          {u.name || u.username}
                          {u.isBlocked && <span className="text-destructive text-xs mr-2">(مسدود)</span>}
                        </div>
                        <div className="text-xs text-muted-foreground" dir="ltr">{u.email}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="font-mono text-sm" dir="ltr">@{u.username}</span>
                  </TableCell>
                  <TableCell>
                    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium ${role.color}`}>
                      <role.icon className="size-3" />
                      {role.label}
                    </span>
                  </TableCell>
                  <TableCell>
                    <div className="text-xs space-y-0.5">
                      <div>{toPersianDigits(u._count.articles)} مقاله</div>
                      <div className="text-muted-foreground">{toPersianDigits(u._count.comments)} نظر • {toPersianDigits(u._count.bookmarks)} ذخیره</div>
                    </div>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                    {formatRelativeTime(u.createdAt)}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1 justify-end">
                      {!isSelf && (
                        <>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="size-8"
                            onClick={() => openAction(u, 'SET_ROLE')}
                            title="تغییر نقش"
                          >
                            <Shield className="size-4" />
                          </Button>
                          {u.isBlocked ? (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-8 text-emerald-600"
                              onClick={() => openAction(u, 'UNBLOCK')}
                              title="رفع مسدودی"
                            >
                              <UserCheck className="size-4" />
                            </Button>
                          ) : (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-8 text-amber-600"
                              onClick={() => openAction(u, 'BLOCK')}
                              title="مسدود کردن"
                            >
                              <Ban className="size-4" />
                            </Button>
                          )}
                          {u.role !== 'SUPER_ADMIN' && (
                            <Button
                              variant="ghost"
                              size="icon"
                              className="size-8 text-destructive"
                              onClick={() => openAction(u, 'DELETE')}
                              title="حذف کاربر"
                            >
                              <Trash2 className="size-4" />
                            </Button>
                          )}
                        </>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </div>

      {/* Mobile cards */}
      <div className="md:hidden space-y-3">
        {filtered.map(u => {
          const role = roleLabels[u.role] || roleLabels.USER
          const isSelf = u.id === currentUser.id
          return (
            <Card key={u.id} className={u.isBlocked ? 'opacity-60' : ''}>
              <CardContent className="pt-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="size-10 rounded-full bg-primary/15 flex items-center justify-center text-sm font-bold text-primary">
                      {(u.name || u.username).charAt(0)}
                    </div>
                    <div>
                      <div className="font-medium">{u.name || u.username}</div>
                      <div className="text-xs text-muted-foreground" dir="ltr">{u.email}</div>
                    </div>
                  </div>
                  <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium ${role.color}`}>
                    {role.label}
                  </span>
                </div>
                <div className="text-xs text-muted-foreground mb-3">
                  {toPersianDigits(u._count.articles)} مقاله • {toPersianDigits(u._count.comments)} نظر • {formatRelativeTime(u.createdAt)}
                </div>
                {!isSelf && (
                  <div className="flex gap-1">
                    <Button variant="outline" size="sm" className="flex-1" onClick={() => openAction(u, 'SET_ROLE')}>
                      <Shield className="size-3 ml-1" />
                      نقش
                    </Button>
                    {u.isBlocked ? (
                      <Button variant="outline" size="sm" onClick={() => openAction(u, 'UNBLOCK')}>
                        رفع مسدودی
                      </Button>
                    ) : (
                      <Button variant="outline" size="sm" onClick={() => openAction(u, 'BLOCK')}>
                        <Ban className="size-3 ml-1" />
                        مسدود
                      </Button>
                    )}
                    {u.role !== 'SUPER_ADMIN' && (
                      <Button variant="outline" size="sm" className="text-destructive" onClick={() => openAction(u, 'DELETE')}>
                        <Trash2 className="size-3" />
                      </Button>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Action dialog */}
      <Dialog open={!!target} onOpenChange={(open) => { if (!open) { setTarget(null); setAction(null) } }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {action === 'SET_ROLE' && 'تغییر نقش کاربر'}
              {action === 'BLOCK' && 'مسدود کردن کاربر'}
              {action === 'UNBLOCK' && 'رفع مسدودی کاربر'}
              {action === 'DELETE' && 'حذف کاربر'}
            </DialogTitle>
            <DialogDescription>
              {action === 'SET_ROLE' && `نقش کاربر «${target?.name || target?.username}» را انتخاب کنید`}
              {action === 'BLOCK' && `آیا از مسدود کردن «${target?.name || target?.username}» مطمئن هستید؟ این کاربر نمی‌تواند وارد شود.`}
              {action === 'UNBLOCK' && `آیا از رفع مسدودی «${target?.name || target?.username}» مطمئن هستید؟`}
              {action === 'DELETE' && `آیا از حذف «${target?.name || target?.username}» مطمئن هستید؟ تمام فعالیت‌های این کاربر حذف خواهد شد.`}
            </DialogDescription>
          </DialogHeader>

          {action === 'SET_ROLE' && (
            <div className="py-2">
              <Select value={newRole} onValueChange={setNewRole}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="USER">کاربر عادی</SelectItem>
                  <SelectItem value="ADMIN">ادمین (می‌تواند خبر منتشر کند)</SelectItem>
                  {currentUser.role === 'SUPER_ADMIN' && (
                    <SelectItem value="SUPER_ADMIN">سوپر ادمین (دسترسی کامل)</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>
          )}

          {action === 'DELETE' && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
              <ShieldAlert className="size-5 shrink-0" />
              این عملیات قابل بازگشت نیست
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => { setTarget(null); setAction(null) }}>انصراف</Button>
            <Button
              variant={action === 'DELETE' || action === 'BLOCK' ? 'destructive' : 'default'}
              onClick={handleConfirm}
              disabled={loading}
            >
              {loading ? 'در حال انجام...' : 'تأیید'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
