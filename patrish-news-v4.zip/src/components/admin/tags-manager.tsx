'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import { Badge } from '@/components/ui/badge'
import { Plus, Edit, Trash2, Tag, Loader2, X } from 'lucide-react'
import { toast } from 'sonner'
import { toPersianDigits } from '@/lib/persian'

const colorOptions = ['#7C3AED', '#06B6D4', '#F43F5E', '#F59E0B', '#10B981', '#3B82F6', '#EC4899', '#8B5CF6', '#14B8A6', '#F97316']

interface Tag {
  id: string
  name: string
  slug: string
  color: string
  _count: { articles: number }
}

export function TagsManager({ tags, canEdit }: { tags: Tag[]; canEdit: boolean }) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Tag | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<Tag | null>(null)
  const [loading, setLoading] = useState(false)
  const [name, setName] = useState('')
  const [color, setColor] = useState('#7C3AED')

  const openNew = () => {
    setEditing(null)
    setName('')
    setColor('#7C3AED')
    setOpen(true)
  }

  const openEdit = (tag: Tag) => {
    setEditing(tag)
    setName(tag.name)
    setColor(tag.color)
    setOpen(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const url = editing ? `/api/tags/${editing.id}` : '/api/tags'
      const method = editing ? 'PUT' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, color }),
        credentials: 'include',
      })
      const data = await res.json()
      if (data.success) {
        toast.success(editing ? 'برچسب به‌روزرسانی شد' : 'برچسب ایجاد شد')
        setOpen(false)
        router.refresh()
      } else {
        toast.error(data.error || 'خطا')
      }
    } catch {
      toast.error('خطا')
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    setLoading(true)
    try {
      const res = await fetch(`/api/tags/${deleteTarget.id}`, { method: 'DELETE', credentials: 'include' })
      const data = await res.json()
      if (data.success) {
        toast.success('برچسب حذف شد')
        setDeleteTarget(null)
        router.refresh()
      } else {
        toast.error(data.error || 'خطا')
      }
    } catch {
      toast.error('خطا')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {canEdit && (
        <div className="flex justify-end">
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={openNew}>
                <Plus className="size-4 ml-2" />
                افزودن برچسب
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>{editing ? 'ویرایش برچسب' : 'افزودن برچسب'}</DialogTitle>
                <DialogDescription>
                  {editing ? 'اطلاعات برچسب را ویرایش کنید' : 'یک برچسب جدید ایجاد کنید'}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">نام برچسب *</Label>
                  <Input
                    id="name"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="مثال: هوش مصنوعی"
                  />
                </div>
                <div className="space-y-2">
                  <Label>رنگ</Label>
                  <div className="flex flex-wrap gap-2">
                    {colorOptions.map(c => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => setColor(c)}
                        className={`size-8 rounded-lg transition-all ${color === c ? 'ring-2 ring-offset-2 ring-offset-background' : ''}`}
                        style={{ backgroundColor: c }}
                      />
                    ))}
                  </div>
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setOpen(false)}>انصراف</Button>
                  <Button type="submit" disabled={loading}>
                    {loading && <Loader2 className="size-4 ml-2 animate-spin" />}
                    {editing ? 'به‌روزرسانی' : 'ایجاد'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      )}

      {tags.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Tag className="size-12 mx-auto mb-3 opacity-20" />
          <p>هنوز برچسبی تعریف نشده است</p>
        </div>
      ) : (
        <div className="flex flex-wrap gap-2">
          {tags.map(tag => (
            <div
              key={tag.id}
              className="inline-flex items-center gap-2 px-3 py-2 rounded-lg border group"
              style={{ borderColor: `${tag.color}40`, backgroundColor: `${tag.color}10` }}
            >
              <Tag className="size-4" style={{ color: tag.color }} />
              <span className="font-medium" style={{ color: tag.color }}>{tag.name}</span>
              <Badge variant="secondary" className="text-xs">{toPersianDigits(tag._count.articles)}</Badge>
              {canEdit && (
                <div className="flex items-center gap-1 mr-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => openEdit(tag)} className="size-6 rounded hover:bg-background/50 flex items-center justify-center">
                    <Edit className="size-3" />
                  </button>
                  <button onClick={() => setDeleteTarget(tag)} className="size-6 rounded hover:bg-background/50 flex items-center justify-center text-destructive">
                    <Trash2 className="size-3" />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      <Dialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>حذف برچسب</DialogTitle>
            <DialogDescription>
              آیا از حذف برچسب «{deleteTarget?.name}» مطمئن هستید؟
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>انصراف</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={loading}>
              {loading && <Loader2 className="size-4 ml-2 animate-spin" />}
              حذف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
