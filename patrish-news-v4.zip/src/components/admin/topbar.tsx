'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { ShieldCheck } from 'lucide-react'
import type { SessionUser } from '@/lib/types'

export function AdminTopbar({ user, siteName }: { user: SessionUser; siteName: string }) {
  return (
    <header className="sticky top-0 z-20 border-b bg-card/80 backdrop-blur-md">
      <div className="flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8 pr-16 lg:pr-8">
        <div className="flex items-center gap-3">
          <h1 className="text-base sm:text-lg font-semibold">{siteName}</h1>
          <Badge variant={user.role === 'SUPER_ADMIN' ? 'default' : 'secondary'} className="gap-1">
            <ShieldCheck className="size-3" />
            {user.role === 'SUPER_ADMIN' ? 'سوپر ادمین' : 'ادمین'}
          </Badge>
        </div>
        <div className="flex items-center gap-3">
          <Link href="/" target="_blank">
            <Button variant="outline" size="sm">
              مشاهده سایت
            </Button>
          </Link>
          <div className="hidden sm:flex items-center gap-2">
            <div className="size-8 rounded-full bg-primary/15 flex items-center justify-center text-sm font-bold text-primary">
              {(user.name || user.username).charAt(0)}
            </div>
            <span className="text-sm font-medium">{user.name || user.username}</span>
          </div>
        </div>
      </div>
    </header>
  )
}
