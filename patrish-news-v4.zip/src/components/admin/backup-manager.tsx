'use client'

import { useState, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Download, Upload, Database, AlertTriangle, CheckCircle2, Loader2, FileJson, Clock } from 'lucide-react'
import { toast } from 'sonner'
import { toPersianDigits } from '@/lib/persian'

interface BackupManagerProps {
  counts: {
    users: number
    articles: number
    categories: number
    tags: number
    comments: number
    likes: number
    bookmarks: number
    auditLogs: number
  }
}

export function BackupManager({ counts }: BackupManagerProps) {
  const [exporting, setExporting] = useState(false)
  const [importing, setImporting] = useState(false)
  const [importDialogOpen, setImportDialogOpen] = useState(false)
  const [importResult, setImportResult] = useState<{ success: boolean; message: string; counts?: Record<string, number> } | null>(null)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleExport = async () => {
    setExporting(true)
    try {
      const res = await fetch('/api/backup/export', { credentials: 'include' })
      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || 'خطا در بک‌آپ‌گیری')
      }
      // دانلود فایل
      const blob = await res.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      // استخراج نام فایل از header
      const contentDisposition = res.headers.get('Content-Disposition')
      const filenameMatch = contentDisposition?.match(/filename="?(.+?)"?$/)
      const filename = filenameMatch ? filenameMatch[1] : `patrish-backup-${new Date().toISOString().slice(0, 10)}.json`
      a.download = filename
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      window.URL.revokeObjectURL(url)
      toast.success('بک‌آپ با موفقیت دانلود شد')
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'خطا در بک‌آپ‌گیری')
    } finally {
      setExporting(false)
    }
  }

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      // بررسی نوع فایل
      if (!file.name.endsWith('.json')) {
        toast.error('فقط فایل JSON مجاز است')
        return
      }
      setSelectedFile(file)
      setImportResult(null)
    }
  }

  const handleImport = async () => {
    if (!selectedFile) {
      toast.error('ابتدا فایل بک‌آپ را انتخاب کنید')
      return
    }

    setImporting(true)
    try {
      const text = await selectedFile.text()
      const backup = JSON.parse(text)

      // اعتبارسنجی
      if (!backup.meta || !backup.data) {
        throw new Error('فایل بک‌آپ نامعتبر است')
      }

      const res = await fetch('/api/backup/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(backup),
        credentials: 'include',
      })
      const data = await res.json()

      if (data.success) {
        setImportResult({ success: true, message: data.message, counts: data.data })
        toast.success('بک‌آپ با موفقیت بازیابی شد')
        // reload صفحه بعد از ۳ ثانیه
        setTimeout(() => window.location.reload(), 3000)
      } else {
        throw new Error(data.error || 'خطا در بازیابی')
      }
    } catch (e) {
      setImportResult({ success: false, message: e instanceof Error ? e.message : 'خطا در بازیابی' })
      toast.error(e instanceof Error ? e.message : 'خطا در بازیابی')
    } finally {
      setImporting(false)
    }
  }

  const dataItems = [
    { label: 'کاربران', value: counts.users, icon: '👥', color: '#7C3AED' },
    { label: 'اخبار منتشر شده', value: counts.articles, icon: '📰', color: '#06B6D4' },
    { label: 'دسته‌بندی‌ها', value: counts.categories, icon: '📁', color: '#F59E0B' },
    { label: 'برچسب‌ها', value: counts.tags, icon: '🏷️', color: '#EC4899' },
    { label: 'نظرات', value: counts.comments, icon: '💬', color: '#F43F5E' },
    { label: 'لایک‌ها', value: counts.likes, icon: '❤️', color: '#F97316' },
    { label: 'ذخیره‌شده‌ها', value: counts.bookmarks, icon: '🔖', color: '#10B981' },
    { label: 'لاگ فعالیت‌ها', value: counts.auditLogs, icon: '📜', color: '#8B5CF6' },
  ]

  return (
    <div className="space-y-6">
      {/* آمار دیتابیس فعلی */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Database className="size-5 text-primary" />
            وضعیت فعلی پایگاه داده
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {dataItems.map((item) => (
              <div key={item.label} className="p-3 rounded-lg border bg-card">
                <div className="text-2xl mb-1">{item.icon}</div>
                <div className="text-xl font-bold font-mono">{toPersianDigits(item.value)}</div>
                <div className="text-xs text-muted-foreground">{item.label}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* بک‌آپ‌گیری */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Download className="size-5 text-emerald-500" />
            بک‌آپ‌گیری از پایگاه داده
          </CardTitle>
          <CardDescription>
            تمام داده‌های سایت (کاربران، اخبار، نظرات، تنظیمات و...) را به‌صورت یک فایل JSON دانلود کنید
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center">
            <Button onClick={handleExport} disabled={exporting} size="lg" className="gap-2">
              {exporting ? (
                <>
                  <Loader2 className="size-4 animate-spin" />
                  در حال بک‌آپ‌گیری...
                </>
              ) : (
                <>
                  <Download className="size-4" />
                  دانلود بک‌آپ کامل
                </>
              )}
            </Button>
            <div className="text-sm text-muted-foreground">
              <div className="flex items-center gap-1">
                <FileJson className="size-4" />
                فایل JSON شامل تمام داده‌ها
              </div>
              <div className="flex items-center gap-1 mt-1">
                <Clock className="size-3" />
                شامل رمزهای عبور هش شده کاربران
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* بازیابی */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Upload className="size-5 text-blue-500" />
            بازیابی از فایل بک‌آپ
          </CardTitle>
          <CardDescription>
            یک فایل بک‌آپ JSON را آپلود کنید تا داده‌های سایت از آن بازیابی شوند
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* هشدار */}
          <div className="flex items-start gap-3 p-3 rounded-lg bg-amber-500/10 border border-amber-500/30">
            <AlertTriangle className="size-5 text-amber-500 shrink-0 mt-0.5" />
            <div className="text-sm text-amber-700 dark:text-amber-400">
              <strong>هشدار مهم:</strong> بازیابی بک‌آپ تمام داده‌های فعلی را جایگزین می‌کند.
              این عملیات قابل بازگشت نیست. لطفاً قبل از بازیابی، از داده‌های فعلی بک‌آپ بگیرید.
            </div>
          </div>

          {/* انتخاب فایل */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed rounded-xl p-8 text-center cursor-pointer hover:border-primary hover:bg-muted/20 transition-all"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              className="hidden"
              onChange={handleFileSelect}
            />
            {selectedFile ? (
              <div className="space-y-2">
                <FileJson className="size-12 mx-auto text-primary" />
                <div className="font-medium">{selectedFile.name}</div>
                <div className="text-xs text-muted-foreground">
                  {(selectedFile.size / 1024).toFixed(1)} KB
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={(e) => { e.stopPropagation(); setSelectedFile(null); setImportResult(null) }}
                >
                  تغییر فایل
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                <Upload className="size-12 mx-auto text-muted-foreground/40" />
                <div className="font-medium">فایل بک‌آپ را اینجا کلیک کنید</div>
                <div className="text-xs text-muted-foreground">فقط فایل JSON</div>
              </div>
            )}
          </div>

          {/* دکمه بازیابی */}
          {selectedFile && (
            <Button
              onClick={() => setImportDialogOpen(true)}
              disabled={importing}
              size="lg"
              variant="destructive"
              className="w-full gap-2"
            >
              <Upload className="size-4" />
              بازیابی از فایل بک‌آپ
            </Button>
          )}

          {/* نتیجه بازیابی */}
          {importResult && (
            <div className={`p-4 rounded-lg border ${importResult.success ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-destructive/10 border-destructive/30'}`}>
              <div className="flex items-start gap-2">
                {importResult.success ? (
                  <CheckCircle2 className="size-5 text-emerald-500 shrink-0 mt-0.5" />
                ) : (
                  <AlertTriangle className="size-5 text-destructive shrink-0 mt-0.5" />
                )}
                <div className="text-sm">
                  <div className="font-medium">{importResult.message}</div>
                  {importResult.counts && (
                    <div className="mt-2 grid grid-cols-2 gap-1 text-xs">
                      {Object.entries(importResult.counts).map(([key, value]) => (
                        <div key={key}>
                          {key}: <span className="font-mono">{toPersianDigits(value)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {importResult.success && (
                    <div className="mt-2 text-xs text-muted-foreground">
                      صفحه در ۳ ثانیه بازخوانی می‌شود...
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* تأیید بازیابی */}
      <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="size-5 text-amber-500" />
              تأیید بازیابی
            </DialogTitle>
            <DialogDescription>
              آیا از بازیابی فایل بک‌آپ مطمئن هستید؟
              <br />
              <strong className="text-destructive">تمام داده‌های فعلی جایگزین خواهند شد.</strong>
              <br />
              این عملیات قابل بازگشت نیست.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setImportDialogOpen(false)} disabled={importing}>
              انصراف
            </Button>
            <Button variant="destructive" onClick={handleImport} disabled={importing}>
              {importing ? (
                <>
                  <Loader2 className="size-4 ml-2 animate-spin" />
                  در حال بازیابی...
                </>
              ) : (
                <>
                  <Upload className="size-4 ml-2" />
                  بله، بازیابی کن
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
