'use client'

import { useEditor, EditorContent } from '@tiptap/react'
import StarterKit from '@tiptap/starter-kit'
import Link from '@tiptap/extension-link'
import Image from '@tiptap/extension-image'
import TextAlign from '@tiptap/extension-text-align'
import Placeholder from '@tiptap/extension-placeholder'
import Underline from '@tiptap/extension-underline'
import { useEffect, useRef, useState } from 'react'
import {
  Bold, Italic, Underline as UnderlineIcon, Strikethrough, Code,
  Heading1, Heading2, Heading3, List, ListOrdered,
  Quote, Undo, Redo, Link as LinkIcon, Image as ImageIcon,
  AlignRight, AlignCenter, AlignLeft, AlignJustify, Minus,
  MoveRight, MoveLeft, AlignCenterHorizontal, Maximize2,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog'
import { toast } from 'sonner'

interface RichTextEditorProps {
  value: string
  onChange: (html: string) => void
  placeholder?: string
}

export function RichTextEditor({ value, onChange, placeholder = 'متن خبر را اینجا بنویسید...' }: RichTextEditorProps) {
  const [linkDialogOpen, setLinkDialogOpen] = useState(false)
  const [linkUrl, setLinkUrl] = useState('')
  const [imageDialogOpen, setImageDialogOpen] = useState(false)
  const [imageUrl, setImageUrl] = useState('')
  const [imageCaption, setImageCaption] = useState('')
  const [imageAlign, setImageAlign] = useState<'left' | 'center' | 'right' | 'full'>('center')
  const [imageUploadLoading, setImageUploadLoading] = useState(false)
  const [selectedImageAlign, setSelectedImageAlign] = useState<'left' | 'center' | 'right' | 'full'>('center')
  const fileInputRef = useRef<HTMLInputElement>(null)
  const dropZoneRef = useRef<HTMLDivElement>(null)

  const editor = useEditor({
    extensions: [
      StarterKit.configure({}),
      Underline,
      Link.configure({
        openOnClick: false,
        HTMLAttributes: { class: 'text-primary underline' },
      }),
      Image.configure({
        inline: false,
        allowBase64: true,
        HTMLAttributes: { class: 'rounded-lg max-w-full h-auto' },
      }),
      TextAlign.configure({
        types: ['heading', 'paragraph'],
        defaultAlignment: 'right',
      }),
      Placeholder.configure({ placeholder }),
    ],
    content: value,
    onUpdate: ({ editor }) => {
      onChange(editor.getHTML())
    },
    editorProps: {
      attributes: {
        class: 'prose prose-sm max-w-none min-h-[400px] p-4 focus:outline-none text-foreground',
        dir: 'rtl',
        lang: 'fa',
      },
      // پشتیبانی از drag & drop تصاویر
      handleDrop: (view, event, _, moved) => {
        if (!moved && event.dataTransfer && event.dataTransfer.files && event.dataTransfer.files.length > 0) {
          const files = Array.from(event.dataTransfer.files)
          const images = files.filter(file => file.type.startsWith('image/'))
          if (images.length > 0) {
            event.preventDefault()
            images.forEach(file => handleImageUpload(file))
            return true
          }
        }
        return false
      },
      handlePaste: (view, event) => {
        const items = event.clipboardData?.items
        if (items) {
          for (const item of items) {
            if (item.type.startsWith('image/')) {
              const file = item.getAsFile()
              if (file) {
                event.preventDefault()
                handleImageUpload(file)
                return true
              }
            }
          }
        }
        return false
      },
    },
    immediatelyRender: false,
  })

  // Sync external value changes
  useEffect(() => {
    if (editor && value !== editor.getHTML()) {
      editor.commands.setContent(value || '', { emitUpdate: false } as any)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editor])

  // آپدیت انتخاب تصویر وقتی کاربر روی تصویر کلیک می‌کنه
  useEffect(() => {
    if (!editor) return
    const updateImageSelection = () => {
      if (editor.isActive('image')) {
        // بررسی align تصویر فعلی
        const img = editor.view.dom.querySelector('img.ProseMirror-selectednode') as HTMLImageElement
        if (img) {
          if (img.style.float === 'right' || img.parentElement?.style.textAlign === 'right') {
            setSelectedImageAlign('right')
          } else if (img.style.float === 'left' || img.parentElement?.style.textAlign === 'left') {
            setSelectedImageAlign('left')
          } else if (img.style.width === '100%' || img.style.display === 'block') {
            setSelectedImageAlign('full')
          } else {
            setSelectedImageAlign('center')
          }
        }
      }
    }
    editor.on('selectionUpdate', updateImageSelection)
    editor.on('transaction', updateImageSelection)
    return () => {
      editor.off('selectionUpdate', updateImageSelection)
      editor.off('transaction', updateImageSelection)
    }
  }, [editor])

  if (!editor) return null

  const addLink = () => {
    if (linkUrl) {
      editor.chain().focus().setLink({ href: linkUrl }).run()
      setLinkUrl('')
      setLinkDialogOpen(false)
      toast.success('لینک اضافه شد')
    }
  }

  // اضافه‌کردن تصویر با align مشخص
  const addImageWithAlign = (url: string, align: 'left' | 'center' | 'right' | 'full', caption?: string) => {
    if (!url) return

    // ایجاد HTML سفارشی برای تصویر
    let imgHtml = ''
    const captionHtml = caption ? `<figcaption style="text-align:center;font-size:0.875rem;color:var(--muted-foreground);margin-top:0.5rem;font-style:italic;">${caption}</figcaption>` : ''

    if (align === 'full') {
      // تمام عرض
      imgHtml = `<figure style="margin:1.5rem 0;text-align:center;"><img src="${url}" alt="${caption || ''}" style="width:100%;height:auto;border-radius:0.75rem;display:block;" />${captionHtml}</figure>`
    } else if (align === 'center') {
      // وسط
      imgHtml = `<figure style="margin:1.5rem auto;text-align:center;max-width:600px;"><img src="${url}" alt="${caption || ''}" style="max-width:100%;height:auto;border-radius:0.75rem;display:block;margin:0 auto;" />${captionHtml}</figure>`
    } else if (align === 'right') {
      // راست - متن در سمت چپ
      imgHtml = `<figure style="float:right;margin:0 0 1rem 1.5rem;max-width:300px;"><img src="${url}" alt="${caption || ''}" style="max-width:100%;height:auto;border-radius:0.75rem;display:block;" />${captionHtml}</figure>`
    } else if (align === 'left') {
      // چپ - متن در سمت راست
      imgHtml = `<figure style="float:left;margin:0 1.5rem 1rem 0;max-width:300px;"><img src="${url}" alt="${caption || ''}" style="max-width:100%;height:auto;border-radius:0.75rem;display:block;" />${captionHtml}</figure>`
    }

    // درج تصویر در موقعیت فعلی
    editor.chain().focus().insertContent(imgHtml).run()

    setImageUrl('')
    setImageCaption('')
    setImageAlign('center')
    setImageDialogOpen(false)
    toast.success('تصویر اضافه شد')
  }

  const addImageFromUrl = () => {
    if (imageUrl) {
      addImageWithAlign(imageUrl, imageAlign, imageCaption)
    }
  }

  const handleImageUpload = async (file: File) => {
    setImageUploadLoading(true)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await fetch('/api/upload', { method: 'POST', body: formData, credentials: 'include' })
      const data = await res.json()
      if (data.success) {
        addImageWithAlign(data.data.url, 'center', file.name.replace(/\.[^/.]+$/, ''))
        toast.success('تصویر آپلود و اضافه شد')
      } else {
        toast.error(data.error || 'خطا در آپلود')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setImageUploadLoading(false)
    }
  }

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) handleImageUpload(file)
    e.target.value = ''
  }

  // تغییر align تصویر انتخاب‌شده
  const changeImageAlign = (align: 'left' | 'center' | 'right' | 'full') => {
    if (!editor.isActive('image')) {
      toast.info('ابتدا روی یک تصویر کلیک کنید')
      return
    }

    const img = editor.view.dom.querySelector('img.ProseMirror-selectednode') as HTMLImageElement
    if (!img) return

    const src = img.src
    const alt = img.alt || ''

    // حذف تصویر فعلی و درج مجدد با align جدید
    editor.chain().focus().deleteSelection().run()

    setTimeout(() => {
      addImageWithAlign(src, align, alt)
      setSelectedImageAlign(align)
    }, 50)
  }

  const ToolbarButton = ({
    onClick,
    isActive,
    disabled,
    title,
    children,
  }: {
    onClick: () => void
    isActive?: boolean
    disabled?: boolean
    title: string
    children: React.ReactNode
  }) => (
    <Button
      type="button"
      variant={isActive ? 'default' : 'ghost'}
      size="icon"
      className="size-8"
      onClick={onClick}
      disabled={disabled}
      title={title}
    >
      {children}
    </Button>
  )

  return (
    <div className="border rounded-lg overflow-hidden bg-background">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-0.5 p-2 border-b bg-muted/30 sticky top-0 z-10">
        <ToolbarButton onClick={() => editor.chain().focus().undo().run()} disabled={!editor.can().undo()} title="بازگشت">
          <Undo className="size-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().redo().run()} disabled={!editor.can().redo()} title="جلو">
          <Redo className="size-4" />
        </ToolbarButton>

        <div className="w-px h-6 bg-border mx-1" />

        <ToolbarButton onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()} isActive={editor.isActive('heading', { level: 1 })} title="تیتر ۱">
          <Heading1 className="size-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()} isActive={editor.isActive('heading', { level: 2 })} title="تیتر ۲">
          <Heading2 className="size-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()} isActive={editor.isActive('heading', { level: 3 })} title="تیتر ۳">
          <Heading3 className="size-4" />
        </ToolbarButton>

        <div className="w-px h-6 bg-border mx-1" />

        <ToolbarButton onClick={() => editor.chain().focus().toggleBold().run()} isActive={editor.isActive('bold')} title="ضخیم">
          <Bold className="size-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleItalic().run()} isActive={editor.isActive('italic')} title="کج">
          <Italic className="size-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleUnderline().run()} isActive={editor.isActive('underline')} title="زیرخط">
          <UnderlineIcon className="size-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleStrike().run()} isActive={editor.isActive('strike')} title="خط خورده">
          <Strikethrough className="size-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleCode().run()} isActive={editor.isActive('code')} title="کد">
          <Code className="size-4" />
        </ToolbarButton>

        <div className="w-px h-6 bg-border mx-1" />

        <ToolbarButton onClick={() => editor.chain().focus().toggleBulletList().run()} isActive={editor.isActive('bulletList')} title="لیست نقطه‌ای">
          <List className="size-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleOrderedList().run()} isActive={editor.isActive('orderedList')} title="لیست عددی">
          <ListOrdered className="size-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleBlockquote().run()} isActive={editor.isActive('blockquote')} title="نقل قول">
          <Quote className="size-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().setHorizontalRule().run()} title="خط جداکننده">
          <Minus className="size-4" />
        </ToolbarButton>

        <div className="w-px h-6 bg-border mx-1" />

        {/* چینش متن */}
        <ToolbarButton onClick={() => editor.chain().focus().setTextAlign('right').run()} isActive={editor.isActive({ textAlign: 'right' })} title="راست‌چین">
          <AlignRight className="size-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().setTextAlign('center').run()} isActive={editor.isActive({ textAlign: 'center' })} title="وسط‌چین">
          <AlignCenter className="size-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().setTextAlign('left').run()} isActive={editor.isActive({ textAlign: 'left' })} title="چپ‌چین">
          <AlignLeft className="size-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().setTextAlign('justify').run()} isActive={editor.isActive({ textAlign: 'justify' })} title="هم‌تراز">
          <AlignJustify className="size-4" />
        </ToolbarButton>

        <div className="w-px h-6 bg-border mx-1" />

        {/* چینش تصویر - فقط وقتی تصویر انتخاب شده */}
        {editor.isActive('image') && (
          <>
            <div className="text-xs text-muted-foreground px-2">چینش تصویر:</div>
            <ToolbarButton onClick={() => changeImageAlign('right')} isActive={selectedImageAlign === 'right'} title="راست (متن در چپ)">
              <MoveRight className="size-4" />
            </ToolbarButton>
            <ToolbarButton onClick={() => changeImageAlign('center')} isActive={selectedImageAlign === 'center'} title="وسط">
              <AlignCenterHorizontal className="size-4" />
            </ToolbarButton>
            <ToolbarButton onClick={() => changeImageAlign('left')} isActive={selectedImageAlign === 'left'} title="چپ (متن در راست)">
              <MoveLeft className="size-4" />
            </ToolbarButton>
            <ToolbarButton onClick={() => changeImageAlign('full')} isActive={selectedImageAlign === 'full'} title="تمام عرض">
              <Maximize2 className="size-4" />
            </ToolbarButton>
            <div className="w-px h-6 bg-border mx-1" />
          </>
        )}

        <ToolbarButton onClick={() => setLinkDialogOpen(true)} isActive={editor.isActive('link')} title="لینک">
          <LinkIcon className="size-4" />
        </ToolbarButton>
        <ToolbarButton onClick={() => setImageDialogOpen(true)} title="افزودن تصویر">
          <ImageIcon className="size-4" />
        </ToolbarButton>
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="gap-1.5"
          onClick={() => fileInputRef.current?.click()}
          disabled={imageUploadLoading}
          title="آپلود تصویر از سیستم"
        >
          {imageUploadLoading ? (
            <div className="size-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
          ) : (
            <ImageIcon className="size-4" />
          )}
          <span className="text-xs">آپلود</span>
        </Button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={onFileChange}
        />
      </div>

      {/* Editor */}
      <div className="bg-background article-content-editor" dir="rtl">
        <EditorContent editor={editor} />
      </div>

      {/* راهنما */}
      <div className="border-t bg-muted/20 px-4 py-2 text-xs text-muted-foreground flex items-center justify-between flex-wrap gap-2">
        <div>
          💡 برای آپلود تصویر، آن را از سیستم خود بکشید و در اینجا رها کنید
        </div>
        <div className="flex items-center gap-2">
          {editor.isActive('image') && (
            <span className="text-primary">✓ تصویر انتخاب شده - از دکمه‌های چینش استفاده کنید</span>
          )}
        </div>
      </div>

      {/* Link Dialog */}
      <Dialog open={linkDialogOpen} onOpenChange={setLinkDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>افزودن لینک</DialogTitle>
          </DialogHeader>
          <Input
            type="url"
            placeholder="https://example.com"
            value={linkUrl}
            onChange={(e) => setLinkUrl(e.target.value)}
            dir="ltr"
            autoFocus
            onKeyDown={(e) => e.key === 'Enter' && addLink()}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setLinkDialogOpen(false)}>انصراف</Button>
            <Button onClick={addLink}>افزودن</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Image Dialog */}
      <Dialog open={imageDialogOpen} onOpenChange={setImageDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>افزودن تصویر از URL</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Input
              type="url"
              placeholder="https://example.com/image.jpg"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              dir="ltr"
              autoFocus
            />
            <Input
              type="text"
              placeholder="کپشن تصویر (اختیاری)"
              value={imageCaption}
              onChange={(e) => setImageCaption(e.target.value)}
            />
            <div>
              <div className="text-sm font-medium mb-2">محل قرارگیری تصویر:</div>
              <div className="grid grid-cols-4 gap-2">
                <button
                  type="button"
                  onClick={() => setImageAlign('right')}
                  className={`p-2 rounded-lg border text-xs flex flex-col items-center gap-1 ${imageAlign === 'right' ? 'bg-primary text-primary-foreground border-primary' : 'hover:bg-muted'}`}
                >
                  <MoveRight className="size-4" />
                  راست
                </button>
                <button
                  type="button"
                  onClick={() => setImageAlign('center')}
                  className={`p-2 rounded-lg border text-xs flex flex-col items-center gap-1 ${imageAlign === 'center' ? 'bg-primary text-primary-foreground border-primary' : 'hover:bg-muted'}`}
                >
                  <AlignCenterHorizontal className="size-4" />
                  وسط
                </button>
                <button
                  type="button"
                  onClick={() => setImageAlign('left')}
                  className={`p-2 rounded-lg border text-xs flex flex-col items-center gap-1 ${imageAlign === 'left' ? 'bg-primary text-primary-foreground border-primary' : 'hover:bg-muted'}`}
                >
                  <MoveLeft className="size-4" />
                  چپ
                </button>
                <button
                  type="button"
                  onClick={() => setImageAlign('full')}
                  className={`p-2 rounded-lg border text-xs flex flex-col items-center gap-1 ${imageAlign === 'full' ? 'bg-primary text-primary-foreground border-primary' : 'hover:bg-muted'}`}
                >
                  <Maximize2 className="size-4" />
                  تمام عرض
                </button>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setImageDialogOpen(false)}>انصراف</Button>
            <Button onClick={addImageFromUrl}>افزودن</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <style jsx global>{`
        .article-content-editor .ProseMirror {
          min-height: 400px;
          padding: 1rem;
          outline: none;
          direction: rtl;
          text-align: right;
          line-height: 2;
          font-size: 1rem;
        }
        .article-content-editor .ProseMirror p {
          margin-bottom: 1rem;
        }
        .article-content-editor .ProseMirror h1 {
          font-size: 1.875rem;
          font-weight: 700;
          margin-top: 1.5rem;
          margin-bottom: 1rem;
        }
        .article-content-editor .ProseMirror h2 {
          font-size: 1.5rem;
          font-weight: 700;
          margin-top: 1.5rem;
          margin-bottom: 1rem;
        }
        .article-content-editor .ProseMirror h3 {
          font-size: 1.25rem;
          font-weight: 600;
          margin-top: 1rem;
          margin-bottom: 0.75rem;
        }
        .article-content-editor .ProseMirror ul,
        .article-content-editor .ProseMirror ol {
          padding-right: 1.5rem;
          margin-bottom: 1rem;
        }
        .article-content-editor .ProseMirror ul {
          list-style: disc;
        }
        .article-content-editor .ProseMirror ol {
          list-style: decimal;
        }
        .article-content-editor .ProseMirror li {
          margin-bottom: 0.5rem;
        }
        .article-content-editor .ProseMirror blockquote {
          border-right: 4px solid var(--primary);
          padding-right: 1rem;
          margin: 1rem 0;
          color: var(--muted-foreground);
          font-style: italic;
        }
        .article-content-editor .ProseMirror img {
          max-width: 100%;
          height: auto;
          border-radius: 0.5rem;
          margin: 1rem 0;
          display: block;
        }
        .article-content-editor .ProseMirror img.ProseMirror-selectednode {
          outline: 3px solid var(--primary);
          outline-offset: 2px;
        }
        .article-content-editor .ProseMirror figure {
          margin: 1.5rem 0;
        }
        .article-content-editor .ProseMirror figcaption {
          text-align: center;
          font-size: 0.875rem;
          color: var(--muted-foreground);
          margin-top: 0.5rem;
          font-style: italic;
        }
        .article-content-editor .ProseMirror a {
          color: var(--primary);
          text-decoration: underline;
        }
        .article-content-editor .ProseMirror code {
          background: var(--muted);
          padding: 0.15rem 0.4rem;
          border-radius: 0.25rem;
          font-family: var(--font-mono);
          font-size: 0.9em;
        }
        .article-content-editor .ProseMirror pre {
          background: var(--muted);
          padding: 1rem;
          border-radius: 0.5rem;
          overflow-x: auto;
        }
        .article-content-editor .ProseMirror hr {
          border: none;
          border-top: 2px solid var(--border);
          margin: 1.5rem 0;
        }
        .article-content-editor .ProseMirror p.is-editor-empty:first-child::before {
          content: attr(data-placeholder);
          float: right;
          color: var(--muted-foreground);
          pointer-events: none;
          height: 0;
        }
      `}</style>
    </div>
  )
}
