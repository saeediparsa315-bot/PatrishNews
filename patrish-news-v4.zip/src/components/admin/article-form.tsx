'use client'

import { useState, useRef } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { RichTextEditor } from '@/components/admin/rich-text-editor'
import { X, Save, Send, Image as ImageIcon, Loader2, Upload, AlertCircle } from 'lucide-react'
import { toast } from 'sonner'
import type { ArticleWithRelations } from '@/lib/types'

interface Category {
  id: string
  name: string
  slug: string
  color: string
  children?: { id: string; name: string; slug: string; color: string }[]
}

interface Tag {
  id: string
  name: string
  slug: string
  color: string
}

interface ArticleFormProps {
  article?: ArticleWithRelations & { tags?: Tag[] }
  categories: Category[]
  tags: Tag[]
  selectedTags?: Tag[]
}

export function ArticleForm({ article, categories, tags, selectedTags = [] }: ArticleFormProps) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [selectedTagIds, setSelectedTagIds] = useState<string[]>(selectedTags.map(t => t.id))
  const [coverImage, setCoverImage] = useState(article?.coverImage || '')
  const [coverUploadLoading, setCoverUploadLoading] = useState(false)
  const formRef = useRef<HTMLFormElement>(null)
  const coverFileRef = useRef<HTMLInputElement>(null)

  // State variables for form fields (controlled)
  const [categoryId, setCategoryId] = useState(article?.categoryId || '')
  const [isFeatured, setIsFeatured] = useState(article?.isFeatured || false)
  const [isBreaking, setIsBreaking] = useState(article?.isBreaking || false)
  const [isHomepage, setIsHomepage] = useState(article?.isHomepage || false)
  const [isMainHeadline, setIsMainHeadline] = useState(article?.isMainHeadline || false)
  const [readingTime, setReadingTime] = useState(article?.readingTime || 1)
  const [scheduledAt, setScheduledAt] = useState(
    article?.scheduledAt ? new Date(article.scheduledAt).toISOString().slice(0, 16) : ''
  )
  const [content, setContent] = useState(article?.content || '')
  // فیلدهای چیدمان
  const [layoutMode, setLayoutMode] = useState<'DEFAULT' | 'MANUAL'>(
    (article?.layoutMode as 'DEFAULT' | 'MANUAL') || 'DEFAULT'
  )
  const [position, setPosition] = useState(article?.position || 0)

  const allCategories = [
    ...categories.map(c => ({ id: c.id, name: c.name, color: c.color, depth: 0 })),
    ...categories.flatMap(c => (c.children || []).map(ch => ({ id: ch.id, name: `— ${ch.name}`, color: ch.color, depth: 1 }))),
  ]

  const toggleTag = (tagId: string) => {
    setSelectedTagIds(prev =>
      prev.includes(tagId) ? prev.filter(t => t !== tagId) : [...prev, tagId]
    )
  }

  const handleCoverUpload = async (file: File) => {
    setCoverUploadLoading(true)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await fetch('/api/upload', { method: 'POST', body: formData, credentials: 'include' })
      const data = await res.json()
      if (data.success) {
        setCoverImage(data.data.url)
        toast.success('تصویر کاور آپلود شد')
      } else {
        toast.error(data.error || 'خطا در آپلود')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setCoverUploadLoading(false)
    }
  }

  const onCoverFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) handleCoverUpload(file)
    e.target.value = ''
  }

  const handleSubmit = async (status: string) => {
    if (!categoryId) {
      toast.error('لطفاً دسته‌بندی را انتخاب کنید')
      return
    }
    setLoading(true)
    const formData = new FormData(formRef.current!)
    const body = {
      title: formData.get('title'),
      excerpt: formData.get('excerpt'),
      content,
      coverImage,
      categoryId,
      status,
      isFeatured,
      isBreaking,
      isHomepage,
      isMainHeadline,
      layoutMode,
      position: layoutMode === 'MANUAL' ? Number(position) : 0,
      readingTime: Number(readingTime),
      scheduledAt: scheduledAt || null,
      metaTitle: formData.get('metaTitle') || null,
      metaDescription: formData.get('metaDescription') || null,
      metaKeywords: formData.get('metaKeywords') || null,
      tags: selectedTagIds.map(id => ({ id })),
    }

    try {
      const url = article ? `/api/articles/${article.slug}` : '/api/articles'
      const method = article ? 'PUT' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        credentials: 'include',
      })
      const data = await res.json()
      if (data.success) {
        toast.success(article ? 'خبر به‌روزرسانی شد' : 'خبر ایجاد شد')
        router.push('/admin/articles')
        router.refresh()
      } else {
        toast.error(data.error || 'خطا')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form ref={formRef} className="space-y-6" onSubmit={(e) => { e.preventDefault(); handleSubmit(article?.status === 'PUBLISHED' ? 'PUBLISHED' : 'DRAFT') }}>
      <Tabs defaultValue="edit">
        <TabsList className="mb-4">
          <TabsTrigger value="edit">ویرایش محتوا</TabsTrigger>
          <TabsTrigger value="layout">چیدمان دستی</TabsTrigger>
          <TabsTrigger value="seo">سئو</TabsTrigger>
        </TabsList>

        {/* Edit tab */}
        <TabsContent value="edit" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main column */}
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardContent className="pt-6 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">عنوان خبر *</Label>
                    <Input
                      id="title"
                      name="title"
                      defaultValue={article?.title}
                      required
                      placeholder="عنوان جذاب خبر را وارد کنید..."
                      className="text-lg"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="excerpt">خلاصه خبر</Label>
                    <Textarea
                      id="excerpt"
                      name="excerpt"
                      defaultValue={article?.excerpt || ''}
                      placeholder="خلاصه‌ای کوتاه از خبر (در لیست اخبار نمایش داده می‌شود)"
                      rows={2}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>محتوای خبر (ویرایشگر حرفه‌ای)</Label>
                    <RichTextEditor
                      value={content}
                      onChange={setContent}
                      placeholder="متن کامل خبر را اینجا بنویسید... می‌توانید تصاویر را از سیستم خود آپلود کنید و در هر کجای متن قرار دهید."
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Tags */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">برچسب‌ها (تگ‌ها)</CardTitle>
                  <CardDescription>برچسب‌ها برای جستجوی بهتر کاربران استفاده می‌شوند</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {tags.length === 0 ? (
                      <p className="text-sm text-muted-foreground">برچسبی تعریف نشده. به بخش برچسب‌ها بروید.</p>
                    ) : tags.map(tag => {
                      const selected = selectedTagIds.includes(tag.id)
                      return (
                        <button
                          key={tag.id}
                          type="button"
                          onClick={() => toggleTag(tag.id)}
                          className={`px-3 py-1.5 rounded-md text-xs font-medium border transition-all ${
                            selected
                              ? 'bg-primary text-primary-foreground border-primary'
                              : 'hover:bg-muted'
                          }`}
                          style={!selected ? { color: tag.color, borderColor: `${tag.color}40` } : {}}
                        >
                          {tag.name}
                        </button>
                      )
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base">تنظیمات انتشار</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="categoryId">دسته‌بندی *</Label>
                    <Select value={categoryId} onValueChange={setCategoryId}>
                      <SelectTrigger>
                        <SelectValue placeholder="انتخاب دسته" />
                      </SelectTrigger>
                      <SelectContent>
                        {allCategories.map(c => (
                          <SelectItem key={c.id} value={c.id}>
                            <span className="flex items-center gap-2">
                              <span className="size-2 rounded-full" style={{ backgroundColor: c.color }} />
                              {c.name}
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="readingTime">زمان مطالعه (دقیقه)</Label>
                    <Input
                      id="readingTime"
                      type="number"
                      min={1}
                      max={120}
                      value={readingTime}
                      onChange={(e) => setReadingTime(Number(e.target.value))}
                    />
                    <p className="text-xs text-muted-foreground">زمان تخمینی مطالعه خبر توسط کاربر</p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="scheduledAt">زمان‌بندی انتشار</Label>
                    <Input
                      id="scheduledAt"
                      type="datetime-local"
                      value={scheduledAt}
                      onChange={(e) => setScheduledAt(e.target.value)}
                    />
                  </div>

                  <div className="space-y-3 pt-2 border-t">
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <Label htmlFor="isMainHeadline" className="cursor-pointer">🌟 تیتر اصلی</Label>
                        <p className="text-xs text-muted-foreground">خبر اصلی صفحه اول (فقط یک خبر)</p>
                      </div>
                      <Switch
                        id="isMainHeadline"
                        checked={isMainHeadline}
                        onCheckedChange={setIsMainHeadline}
                      />
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <Label htmlFor="isHomepage" className="cursor-pointer">📍 نمایش در صفحه اصلی</Label>
                        <p className="text-xs text-muted-foreground">این خبر در صفحه اول سایت نمایش داده شود</p>
                      </div>
                      <Switch
                        id="isHomepage"
                        checked={isHomepage}
                        onCheckedChange={setIsHomepage}
                      />
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <Label htmlFor="isBreaking" className="cursor-pointer">🚨 خبر فوری</Label>
                        <p className="text-xs text-muted-foreground">در تیکر اخبار فوری نمایش داده شود</p>
                      </div>
                      <Switch
                        id="isBreaking"
                        checked={isBreaking}
                        onCheckedChange={setIsBreaking}
                      />
                    </div>

                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <Label htmlFor="isFeatured" className="cursor-pointer">⭐ خبر ویژه</Label>
                        <p className="text-xs text-muted-foreground">در بخش اخبار ویژه</p>
                      </div>
                      <Switch
                        id="isFeatured"
                        checked={isFeatured}
                        onCheckedChange={setIsFeatured}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base">تصویر کاور</CardTitle>
                  <CardDescription>تصویر اصلی خبر که در ابتدای خبر نمایش داده می‌شود</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {/* Upload from system */}
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      className="flex-1"
                      onClick={() => coverFileRef.current?.click()}
                      disabled={coverUploadLoading}
                    >
                      {coverUploadLoading ? (
                        <Loader2 className="size-4 ml-2 animate-spin" />
                      ) : (
                        <Upload className="size-4 ml-2" />
                      )}
                      آپلود از سیستم
                    </Button>
                    <input
                      ref={coverFileRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={onCoverFileChange}
                    />
                  </div>

                  <div className="relative">
                    <ImageIcon className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                    <Input
                      type="url"
                      placeholder="یا آدرس URL تصویر"
                      value={coverImage.startsWith('/') ? '' : coverImage}
                      onChange={(e) => setCoverImage(e.target.value)}
                      className="pr-10"
                      dir="ltr"
                    />
                  </div>
                  {coverImage && (
                    <div className="relative aspect-video rounded-lg overflow-hidden border">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={coverImage} alt="پیش‌نمایش کاور" className="size-full object-cover" />
                      <button
                        type="button"
                        onClick={() => setCoverImage('')}
                        className="absolute top-2 right-2 size-7 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center hover:bg-destructive/90"
                      >
                        <X className="size-3.5" />
                      </button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Layout tab - چیدمان دستی */}
        <TabsContent value="layout" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>چیدمان دستی در صفحه اصلی</CardTitle>
              <CardDescription>
                این خبر را در موقعیت مشخصی از صفحه اصلی نمایش دهید (حداکثر ۵ خبر دستی)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* انتخاب نوع چیدمان */}
              <div>
                <Label className="text-sm font-semibold mb-3 block">🎯 نحوه قرارگیری در صفحه اصلی</Label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => { setLayoutMode('DEFAULT'); setPosition(0) }}
                    className={`p-4 rounded-xl border-2 text-sm font-medium transition-all ${
                      layoutMode === 'DEFAULT'
                        ? 'bg-primary text-primary-foreground border-primary shadow-md'
                        : 'bg-card hover:bg-muted border-border'
                    }`}
                  >
                    <div className="text-lg mb-1">⚙️ پیش‌فرض</div>
                    <div className="text-xs opacity-80">خبر بر اساس بازدید و تاریخ در صفحه اصلی نمایش داده می‌شود</div>
                  </button>
                  <button
                    type="button"
                    onClick={() => setLayoutMode('MANUAL')}
                    className={`p-4 rounded-xl border-2 text-sm font-medium transition-all ${
                      layoutMode === 'MANUAL'
                        ? 'bg-primary text-primary-foreground border-primary shadow-md'
                        : 'bg-card hover:bg-muted border-border'
                    }`}
                  >
                    <div className="text-lg mb-1">✋ دستی</div>
                    <div className="text-xs opacity-80">موقعیت دقیق خبر در صفحه اصلی را انتخاب کنید</div>
                  </button>
                </div>
              </div>

              {/* انتخاب موقعیت */}
              {layoutMode === 'MANUAL' && (
                <div className="space-y-4 p-4 rounded-lg border bg-muted/20">
                  <div>
                    <Label className="text-sm font-semibold mb-2 block">
                      📍 موقعیت در صفحه اصلی (۱ تا ۵)
                    </Label>
                    <p className="text-xs text-muted-foreground mb-3">
                      ۱ = بالا (تیتر اصلی بزرگ)، ۲-۵ = کناری
                      <br />
                      <span className="text-amber-600 font-medium">⚠️ حداکثر ۵ خبر دستی مجاز است</span>
                    </p>
                    <div className="grid grid-cols-5 gap-2">
                      {[1, 2, 3, 4, 5].map(pos => (
                        <button
                          key={pos}
                          type="button"
                          onClick={() => setPosition(pos)}
                          className={`aspect-square rounded-xl border-2 text-lg font-bold transition-all ${
                            position === pos
                              ? 'bg-primary text-primary-foreground border-primary scale-110 shadow-lg'
                              : 'bg-card hover:bg-muted hover:border-primary/50 border-border'
                          }`}
                        >
                          {pos}
                        </button>
                      ))}
                    </div>
                  </div>

                  {position > 0 && (
                    <div className="p-3 rounded-md bg-primary/10 text-sm text-primary flex items-center gap-2">
                      <span className="text-lg">✅</span>
                      <span>این خبر در موقعیت {position} صفحه اصلی نمایش داده خواهد شد</span>
                    </div>
                  )}

                  {position > 0 && (
                    <button
                      type="button"
                      onClick={() => setPosition(0)}
                      className="text-sm text-destructive hover:underline"
                    >
                      🗑️ حذف موقعیت (تبدیل به پیش‌فرض)
                    </button>
                  )}

                  {/* پیش‌نمایش موقعیت */}
                  <div className="mt-4 p-3 rounded-lg border">
                    <div className="text-xs font-semibold text-muted-foreground mb-2">پیش‌نمایش چیدمان:</div>
                    <div className="grid grid-cols-3 gap-2">
                      <div className={`col-span-2 row-span-2 aspect-video rounded-lg border-2 flex items-center justify-center text-xs font-bold ${position === 1 ? 'bg-primary/20 border-primary text-primary' : 'bg-muted border-border text-muted-foreground'}`}>
                        ۱ - تیتر اصلی
                      </div>
                      <div className={`aspect-video rounded-lg border-2 flex items-center justify-center text-xs font-bold ${position === 2 ? 'bg-primary/20 border-primary text-primary' : 'bg-muted border-border text-muted-foreground'}`}>
                        ۲
                      </div>
                      <div className={`aspect-video rounded-lg border-2 flex items-center justify-center text-xs font-bold ${position === 3 ? 'bg-primary/20 border-primary text-primary' : 'bg-muted border-border text-muted-foreground'}`}>
                        ۳
                      </div>
                      <div className={`aspect-video rounded-lg border-2 flex items-center justify-center text-xs font-bold ${position === 4 ? 'bg-primary/20 border-primary text-primary' : 'bg-muted border-border text-muted-foreground'}`}>
                        ۴
                      </div>
                      <div className={`aspect-video rounded-lg border-2 flex items-center justify-center text-xs font-bold ${position === 5 ? 'bg-primary/20 border-primary text-primary' : 'bg-muted border-border text-muted-foreground'}`}>
                        ۵
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {layoutMode === 'DEFAULT' && (
                <div className="p-4 rounded-lg border bg-muted/20 text-sm text-muted-foreground">
                  ℹ️ این خبر بر اساس بازدید و تاریخ به‌صورت خودکار در صفحه اصلی نمایش داده می‌شود (اگر در ۲۴ ساعت اخیر باشد).
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* SEO tab */}
        <TabsContent value="seo">
          <Card>
            <CardHeader>
              <CardTitle>تنظیمات سئو</CardTitle>
              <CardDescription>برای بهینه‌سازی در موتورهای جستجو</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 max-w-2xl">
              <div className="space-y-2">
                <Label htmlFor="metaTitle">عنوان متا (Meta Title)</Label>
                <Input
                  id="metaTitle"
                  name="metaTitle"
                  defaultValue={article?.metaTitle || ''}
                  placeholder="عنوان پیش‌فرض از عنوان خبر استفاده می‌شود"
                  maxLength={60}
                />
                <p className="text-xs text-muted-foreground">حداکثر ۶۰ کاراکتر</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="metaDescription">توضیحات متا (Meta Description)</Label>
                <Textarea
                  id="metaDescription"
                  name="metaDescription"
                  defaultValue={article?.metaDescription || ''}
                  placeholder="توضیحات کوتاه برای موتورهای جستجو"
                  rows={3}
                  maxLength={160}
                />
                <p className="text-xs text-muted-foreground">حداکثر ۱۶۰ کاراکتر</p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="metaKeywords">کلمات کلیدی (Meta Keywords)</Label>
                <Input
                  id="metaKeywords"
                  name="metaKeywords"
                  defaultValue={article?.metaKeywords || ''}
                  placeholder="کلمات با کاما جدا شوند"
                />
                <p className="text-xs text-muted-foreground">مثال: اخبار, تکنولوژی, گیم</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Action buttons */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between sticky bottom-4 p-4 bg-card/80 backdrop-blur-md rounded-xl border">
        <Link href="/admin/articles">
          <Button type="button" variant="outline">انصراف</Button>
        </Link>
        <div className="flex flex-col sm:flex-row gap-2">
          <Button
            type="button"
            variant="outline"
            onClick={() => handleSubmit('DRAFT')}
            disabled={loading}
          >
            {loading ? <Loader2 className="size-4 ml-2 animate-spin" /> : <Save className="size-4 ml-2" />}
            ذخیره پیش‌نویس
          </Button>
          <Button
            type="button"
            onClick={() => handleSubmit('PUBLISHED')}
            disabled={loading}
          >
            {loading ? <Loader2 className="size-4 ml-2 animate-spin" /> : <Send className="size-4 ml-2" />}
            {article?.status === 'PUBLISHED' ? 'به‌روزرسانی و انتشار' : 'انتشار خبر'}
          </Button>
        </div>
      </div>
    </form>
  )
}
