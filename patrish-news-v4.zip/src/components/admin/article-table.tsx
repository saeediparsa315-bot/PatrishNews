'use client'

import { useState, useMemo } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { Search, Edit, Trash2, ExternalLink, Plus, Filter, Star, Flame, Home, Zap } from 'lucide-react'
import { toast } from 'sonner'
import { formatRelativeTime, formatNumber, toPersianDigits } from '@/lib/persian'
import type { ArticleWithRelations } from '@/lib/types'

interface Category {
  id: string
  name: string
  slug: string
  color: string
}

interface ArticleTableProps {
  articles: ArticleWithRelations[]
  categories: Category[]
}

const statusMap: Record<string, { label: string; color: string }> = {
  PUBLISHED: { label: 'منتشر شده', color: 'bg-emerald-500/15 text-emerald-600' },
  DRAFT: { label: 'پیش‌نویس', color: 'bg-amber-500/15 text-amber-600' },
  SCHEDULED: { label: 'زمان‌بندی شده', color: 'bg-blue-500/15 text-blue-600' },
  ARCHIVED: { label: 'بایگانی', color: 'bg-gray-500/15 text-gray-600' },
}

export function ArticleTable({ articles, categories }: ArticleTableProps) {
  const router = useRouter()
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [categoryFilter, setCategoryFilter] = useState('all')
  const [deleteTarget, setDeleteTarget] = useState<ArticleWithRelations | null>(null)
  const [deleting, setDeleting] = useState(false)
  const [updatingId, setUpdatingId] = useState<string | null>(null)

  const filtered = useMemo(() => {
    return articles.filter(a => {
      if (search && !a.title.includes(search) && !(a.excerpt || '').includes(search)) return false
      if (statusFilter !== 'all' && a.status !== statusFilter) return false
      if (categoryFilter !== 'all' && a.categoryId !== categoryFilter) return false
      return true
    })
  }, [articles, search, statusFilter, categoryFilter])

  // درخواست ۴ و ۱۵: قابلیت ویرایش سریع isBreaking (و ساير پرچم‌ها)
  const handleToggleFlag = async (
    article: ArticleWithRelations,
    field: 'isBreaking' | 'isHomepage' | 'isMainHeadline' | 'isFeatured'
  ) => {
    setUpdatingId(article.id)
    try {
      const res = await fetch(`/api/articles/${article.slug}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ [field]: !article[field] }),
        credentials: 'include',
      })
      const data = await res.json()
      if (data.success) {
        toast.success('به‌روزرسانی شد')
        router.refresh()
      } else {
        toast.error(data.error || 'خطا')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setUpdatingId(null)
    }
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/articles/${deleteTarget.slug}`, { method: 'DELETE', credentials: 'include' })
      const data = await res.json()
      if (data.success) {
        toast.success('خبر حذف شد')
        setDeleteTarget(null)
        router.refresh()
      } else {
        toast.error(data.error || 'خطا در حذف')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <Input
            placeholder="جستجوی عنوان یا خلاصه..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pr-10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-44">
            <Filter className="size-4 ml-2" />
            <SelectValue placeholder="وضعیت" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه وضعیت‌ها</SelectItem>
            <SelectItem value="PUBLISHED">منتشر شده</SelectItem>
            <SelectItem value="DRAFT">پیش‌نویس</SelectItem>
            <SelectItem value="SCHEDULED">زمان‌بندی شده</SelectItem>
            <SelectItem value="ARCHIVED">بایگانی</SelectItem>
          </SelectContent>
        </Select>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-full sm:w-44">
            <SelectValue placeholder="دسته" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه دسته‌ها</SelectItem>
            {categories.map(c => (
              <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Desktop table */}
      <div className="hidden md:block rounded-xl border overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[35%]">عنوان خبر</TableHead>
              <TableHead>دسته</TableHead>
              <TableHead>وضعیت</TableHead>
              <TableHead>پرچم‌ها</TableHead>
              <TableHead>آمار</TableHead>
              <TableHead className="text-left">عملیات</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                  خبر یافت نشد
                </TableCell>
              </TableRow>
            ) : filtered.map(article => (
              <TableRow key={article.id}>
                <TableCell>
                  <Link
                    href={`/admin/articles/${article.id}`}
                    className="font-medium hover:text-primary line-clamp-1 block"
                  >
                    {article.title}
                  </Link>
                  {article.excerpt && (
                    <div className="text-xs text-muted-foreground line-clamp-1 mt-0.5">
                      {article.excerpt}
                    </div>
                  )}
                </TableCell>
                <TableCell>
                  {article.category && (
                    <Badge
                      variant="outline"
                      style={{ color: article.category.color, borderColor: `${article.category.color}40` }}
                    >
                      {article.category.name}
                    </Badge>
                  )}
                </TableCell>
                <TableCell>
                  <span className={`px-2 py-1 rounded-md text-xs font-medium ${statusMap[article.status]?.color}`}>
                    {statusMap[article.status]?.label || article.status}
                  </span>
                </TableCell>
                <TableCell>
                  <div className="flex flex-col gap-1.5">
                    <label className="flex items-center gap-1.5 text-xs cursor-pointer">
                      <Switch
                        checked={article.isMainHeadline}
                        onCheckedChange={() => handleToggleFlag(article, 'isMainHeadline')}
                        disabled={updatingId === article.id}
                        className="scale-75"
                      />
                      <span className="flex items-center gap-0.5">
                        <Star className="size-3 text-amber-500" />
                        تیتر اصلی
                      </span>
                    </label>
                    <label className="flex items-center gap-1.5 text-xs cursor-pointer">
                      <Switch
                        checked={article.isHomepage}
                        onCheckedChange={() => handleToggleFlag(article, 'isHomepage')}
                        disabled={updatingId === article.id}
                        className="scale-75"
                      />
                      <span className="flex items-center gap-0.5">
                        <Home className="size-3 text-blue-500" />
                        صفحه اصلی
                      </span>
                    </label>
                    <label className="flex items-center gap-1.5 text-xs cursor-pointer">
                      <Switch
                        checked={article.isBreaking}
                        onCheckedChange={() => handleToggleFlag(article, 'isBreaking')}
                        disabled={updatingId === article.id}
                        className="scale-75"
                      />
                      <span className="flex items-center gap-0.5">
                        <Zap className="size-3 text-destructive" />
                        فوری
                      </span>
                    </label>
                    <label className="flex items-center gap-1.5 text-xs cursor-pointer">
                      <Switch
                        checked={article.isFeatured}
                        onCheckedChange={() => handleToggleFlag(article, 'isFeatured')}
                        disabled={updatingId === article.id}
                        className="scale-75"
                      />
                      <span className="flex items-center gap-0.5">
                        <Flame className="size-3 text-primary" />
                        ویژه
                      </span>
                    </label>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex flex-col gap-0.5 text-xs text-muted-foreground">
                    <span>{toPersianDigits(article.viewCount)} بازدید</span>
                    <span>{toPersianDigits(article.commentCount)} نظر</span>
                    <span>{toPersianDigits(article.readingTime)} دقیقه</span>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-1 justify-end">
                    {article.status === 'PUBLISHED' && (
                      <Link href={`/article/${article.slug}`} target="_blank">
                        <Button variant="ghost" size="icon" className="size-8" title="مشاهده">
                          <ExternalLink className="size-4" />
                        </Button>
                      </Link>
                    )}
                    <Link href={`/admin/articles/${article.id}`}>
                      <Button variant="ghost" size="icon" className="size-8" title="ویرایش">
                        <Edit className="size-4" />
                      </Button>
                    </Link>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-8 text-destructive hover:text-destructive"
                      onClick={() => setDeleteTarget(article)}
                      title="حذف"
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Mobile cards */}
      <div className="md:hidden space-y-3">
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground border rounded-xl">
            خبر یافت نشد
          </div>
        ) : filtered.map(article => (
          <div key={article.id} className="p-4 rounded-xl border">
            <Link href={`/admin/articles/${article.id}`} className="font-medium line-clamp-2 block mb-2">
              {article.title}
            </Link>
            <div className="flex flex-wrap items-center gap-2 mb-3">
              {article.category && (
                <Badge
                  variant="outline"
                  style={{ color: article.category.color, borderColor: `${article.category.color}40` }}
                >
                  {article.category.name}
                </Badge>
              )}
              <span className={`px-2 py-0.5 rounded text-xs ${statusMap[article.status]?.color}`}>
                {statusMap[article.status]?.label}
              </span>
            </div>
            <div className="flex flex-col gap-2 mb-3 text-xs">
              <label className="flex items-center justify-between gap-2 cursor-pointer">
                <span className="flex items-center gap-1">
                  <Star className="size-3 text-amber-500" /> تیتر اصلی
                </span>
                <Switch
                  checked={article.isMainHeadline}
                  onCheckedChange={() => handleToggleFlag(article, 'isMainHeadline')}
                  disabled={updatingId === article.id}
                  className="scale-75"
                />
              </label>
              <label className="flex items-center justify-between gap-2 cursor-pointer">
                <span className="flex items-center gap-1">
                  <Home className="size-3 text-blue-500" /> صفحه اصلی
                </span>
                <Switch
                  checked={article.isHomepage}
                  onCheckedChange={() => handleToggleFlag(article, 'isHomepage')}
                  disabled={updatingId === article.id}
                  className="scale-75"
                />
              </label>
              <label className="flex items-center justify-between gap-2 cursor-pointer">
                <span className="flex items-center gap-1">
                  <Zap className="size-3 text-destructive" /> فوری
                </span>
                <Switch
                  checked={article.isBreaking}
                  onCheckedChange={() => handleToggleFlag(article, 'isBreaking')}
                  disabled={updatingId === article.id}
                  className="scale-75"
                />
              </label>
            </div>
            <div className="text-xs text-muted-foreground mb-3">
              {toPersianDigits(article.viewCount)} بازدید • {toPersianDigits(article.commentCount)} نظر • {formatRelativeTime(article.publishedAt || article.createdAt)}
            </div>
            <div className="flex gap-1">
              {article.status === 'PUBLISHED' && (
                <Link href={`/article/${article.slug}`} target="_blank">
                  <Button variant="outline" size="sm" className="flex-1">
                    <ExternalLink className="size-3 ml-1" />
                    مشاهده
                  </Button>
                </Link>
              )}
              <Link href={`/admin/articles/${article.id}`}>
                <Button variant="outline" size="sm" className="flex-1">
                  <Edit className="size-3 ml-1" />
                  ویرایش
                </Button>
              </Link>
              <Button
                variant="outline"
                size="sm"
                className="text-destructive"
                onClick={() => setDeleteTarget(article)}
              >
                <Trash2 className="size-3" />
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* Delete confirmation */}
      <Dialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>حذف خبر</DialogTitle>
            <DialogDescription>
              آیا از حذف خبر «{deleteTarget?.title}» مطمئن هستید؟ این عملیات قابل بازگشت نیست.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>انصراف</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={deleting}>
              {deleting ? 'در حال حذف...' : 'حذف'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
