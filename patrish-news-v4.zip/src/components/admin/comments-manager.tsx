'use client'

import { useState, useMemo } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select'
import { Check, X, Trash2, MessageSquare, Filter, ExternalLink } from 'lucide-react'
import { toast } from 'sonner'
import { formatRelativeTime, toPersianDigits } from '@/lib/persian'

interface Comment {
  id: string
  content: string
  status: string
  createdAt: string | Date
  user: { id: string; username: string; name: string | null; avatar: string | null }
  article: { id: string; title: string; slug: string }
}

const statusConfig: Record<string, { label: string; color: string }> = {
  PENDING: { label: 'در انتظار', color: 'bg-amber-500/15 text-amber-600' },
  APPROVED: { label: 'تأیید شده', color: 'bg-emerald-500/15 text-emerald-600' },
  REJECTED: { label: 'رد شده', color: 'bg-red-500/15 text-red-600' },
}

export function CommentsManager({ comments }: { comments: Comment[] }) {
  const router = useRouter()
  const [filter, setFilter] = useState('all')
  const [loading, setLoading] = useState<string | null>(null)

  const filtered = useMemo(() => {
    if (filter === 'all') return comments
    return comments.filter(c => c.status === filter)
  }, [comments, filter])

  const handleAction = async (commentId: string, action: 'APPROVED' | 'REJECTED' | 'DELETE') => {
    setLoading(commentId)
    try {
      if (action === 'DELETE') {
        const res = await fetch(`/api/comments/${commentId}`, { method: 'DELETE', credentials: 'include' })
        const data = await res.json()
        if (data.success) {
          toast.success('نظر حذف شد')
          router.refresh()
        } else {
          toast.error(data.error || 'خطا')
        }
      } else {
        const res = await fetch(`/api/comments/${commentId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: action }),
          credentials: 'include',
        })
        const data = await res.json()
        if (data.success) {
          toast.success(action === 'APPROVED' ? 'نظر تأیید شد' : 'نظر رد شد')
          router.refresh()
        } else {
          toast.error(data.error || 'خطا')
        }
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setLoading(null)
    }
  }

  const pendingCount = comments.filter(c => c.status === 'PENDING').length
  const approvedCount = comments.filter(c => c.status === 'APPROVED').length
  const rejectedCount = comments.filter(c => c.status === 'REJECTED').length

  return (
    <div className="space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <Card>
          <CardContent className="pt-4 pb-4">
            <div className="text-2xl font-bold">{toPersianDigits(comments.length)}</div>
            <div className="text-xs text-muted-foreground">کل نظرات</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <div className="text-2xl font-bold text-amber-600">{toPersianDigits(pendingCount)}</div>
            <div className="text-xs text-muted-foreground">در انتظار</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <div className="text-2xl font-bold text-emerald-600">{toPersianDigits(approvedCount)}</div>
            <div className="text-xs text-muted-foreground">تأیید شده</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4 pb-4">
            <div className="text-2xl font-bold text-red-600">{toPersianDigits(rejectedCount)}</div>
            <div className="text-xs text-muted-foreground">رد شده</div>
          </CardContent>
        </Card>
      </div>

      {/* Filter */}
      <div className="flex justify-end">
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-44">
            <Filter className="size-4 ml-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">همه ({toPersianDigits(comments.length)})</SelectItem>
            <SelectItem value="PENDING">در انتظار ({toPersianDigits(pendingCount)})</SelectItem>
            <SelectItem value="APPROVED">تأیید شده ({toPersianDigits(approvedCount)})</SelectItem>
            <SelectItem value="REJECTED">رد شده ({toPersianDigits(rejectedCount)})</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <MessageSquare className="size-12 mx-auto mb-3 opacity-20" />
          <p>نظری یافت نشد</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(comment => (
            <Card key={comment.id} className="overflow-hidden">
              <CardContent className="pt-4">
                <div className="flex items-start gap-3">
                  <div className="size-10 rounded-full bg-primary/15 flex items-center justify-center text-sm font-bold text-primary shrink-0">
                    {(comment.user.name || comment.user.username).charAt(0)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className="font-medium">{comment.user.name || comment.user.username}</span>
                      <span className="text-xs text-muted-foreground">{formatRelativeTime(comment.createdAt)}</span>
                      <span className={`px-2 py-0.5 rounded text-xs font-medium ${statusConfig[comment.status]?.color}`}>
                        {statusConfig[comment.status]?.label}
                      </span>
                    </div>
                    <p className="text-sm leading-relaxed mb-2 whitespace-pre-wrap">{comment.content}</p>
                    <Link
                      href={`/article/${comment.article.slug}`}
                      target="_blank"
                      className="text-xs text-primary hover:underline flex items-center gap-1"
                    >
                      <ExternalLink className="size-3" />
                      {comment.article.title}
                    </Link>
                  </div>
                  <div className="flex items-center gap-1">
                    {comment.status !== 'APPROVED' && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8 text-emerald-600"
                        onClick={() => handleAction(comment.id, 'APPROVED')}
                        disabled={loading === comment.id}
                        title="تأیید"
                      >
                        <Check className="size-4" />
                      </Button>
                    )}
                    {comment.status !== 'REJECTED' && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="size-8 text-amber-600"
                        onClick={() => handleAction(comment.id, 'REJECTED')}
                        disabled={loading === comment.id}
                        title="رد"
                      >
                        <X className="size-4" />
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-8 text-destructive"
                      onClick={() => handleAction(comment.id, 'DELETE')}
                      disabled={loading === comment.id}
                      title="حذف"
                    >
                      <Trash2 className="size-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
