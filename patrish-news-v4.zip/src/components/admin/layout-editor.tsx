'use client'

import { useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Save, RotateCcw, GripVertical, X, Clock, Eye, Search } from 'lucide-react'
import { toast } from 'sonner'
import { formatRelativeTime, formatNumber, toPersianDigits } from '@/lib/persian'
import type { ArticleWithRelations } from '@/lib/types'

interface LayoutEditorProps {
  articles: ArticleWithRelations[]
  canEdit?: boolean
}

const POSITIONS = [
  { id: 1, label: 'موقعیت ۱', description: 'تیتر اصلی بزرگ', span: 'lg:col-span-2 lg:row-span-2', minH: 'min-h-[300px]' },
  { id: 2, label: 'موقعیت ۲', description: 'کناری بالا', span: 'lg:col-span-1', minH: 'min-h-[140px]' },
  { id: 3, label: 'موقعیت ۳', description: 'کناری', span: 'lg:col-span-1', minH: 'min-h-[140px]' },
  { id: 4, label: 'موقعیت ۴', description: 'کناری', span: 'lg:col-span-1', minH: 'min-h-[140px]' },
  { id: 5, label: 'موقعیت ۵', description: 'کناری پایین', span: 'lg:col-span-1', minH: 'min-h-[140px]' },
]

export function LayoutEditor({ articles: initialArticles, canEdit = true }: LayoutEditorProps) {
  const router = useRouter()
  const [articles, setArticles] = useState(initialArticles)
  const [saving, setSaving] = useState(false)
  const [draggedId, setDraggedId] = useState<string | null>(null)
  const [dragOverPos, setDragOverPos] = useState<number | null>(null)
  const [searchQuery, setSearchQuery] = useState('')

  // تقسیم اخبار: آنهایی که موقعیت دارند و آنهایی که ندارند
  const positionedArticles = articles.filter(a => a.position > 0)
  const allUnpositioned = articles.filter(a => a.position === 0)

  // فیلتر اخبار بر اساس جستجو
  const unpositionedArticles = searchQuery.trim()
    ? allUnpositioned.filter(a =>
        a.title.includes(searchQuery) ||
        (a.excerpt || '').includes(searchQuery) ||
        (a.category?.name || '').includes(searchQuery)
      )
    : allUnpositioned

  const getArticleByPosition = (pos: number) => positionedArticles.find(a => a.position === pos)

  const handleDragStart = (articleId: string) => {
    setDraggedId(articleId)
  }

  const handleDragOver = (e: React.DragEvent, pos: number) => {
    e.preventDefault()
    setDragOverPos(pos)
  }

  const handleDrop = (e: React.DragEvent, pos: number) => {
    e.preventDefault()
    if (!draggedId) return
    setDragOverPos(null)

    const draggedArticle = articles.find(a => a.id === draggedId)
    if (!draggedArticle) return

    // اگر موقعیت قبلی یک خبر دیگه داره، اون رو به 0 تغییر بده
    const existingAtPos = articles.find(a => a.position === pos && a.id !== draggedId)

    setArticles(prev => prev.map(a => {
      if (a.id === draggedId) {
        return { ...a, position: pos, layoutMode: 'MANUAL' }
      }
      if (existingAtPos && a.id === existingAtPos.id) {
        return { ...a, position: 0 }
      }
      return a
    }))

    setDraggedId(null)
  }

  const handleRemoveFromPosition = (articleId: string) => {
    setArticles(prev => prev.map(a => {
      if (a.id === articleId) {
        return { ...a, position: 0, layoutMode: 'DEFAULT' }
      }
      return a
    }))
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const updates = articles.map(a => ({
        id: a.id,
        slug: a.slug,
        position: a.position,
        layoutMode: a.layoutMode,
      }))

      const res = await fetch('/api/articles/layout', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ updates }),
        credentials: 'include',
      })
      const data = await res.json()
      if (data.success) {
        toast.success('چیدمان ذخیره شد')
        router.refresh()
      } else {
        toast.error(data.error || 'خطا در ذخیره')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setSaving(false)
    }
  }

  const handleReset = () => {
    setArticles(prev => prev.map(a => ({ ...a, position: 0, layoutMode: 'DEFAULT' })))
    toast.info('چیدمان به حالت پیش‌فرض برگردانده شد (هنوز ذخیره نشده)')
  }

  return (
    <div className="space-y-6">
      {/* نوار ابزار */}
      <div className="flex items-center justify-between gap-2 p-3 rounded-lg border bg-card">
        <div className="text-sm text-muted-foreground">
          <span className="font-semibold text-foreground">{toPersianDigits(positionedArticles.length)}</span> از ۵ موقعیت پر شده
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleReset} disabled={saving}>
            <RotateCcw className="size-4 ml-2" />
            بازنشانی
          </Button>
          <Button size="sm" onClick={handleSave} disabled={saving}>
            <Save className="size-4 ml-2" />
            {saving ? 'در حال ذخیره...' : 'ذخیره چیدمان'}
          </Button>
        </div>
      </div>

      {/* گرید بصری موقعیت‌ها */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">گرید صفحه اصلی</CardTitle>
          <CardDescription>
            کارت‌ها را از بخش «اخبار موجود» به موقعیت‌های زیر بکشید و رها کنید
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
            {POSITIONS.map(pos => {
              const article = getArticleByPosition(pos.id)
              return (
                <div
                  key={pos.id}
                  onDragOver={(e) => handleDragOver(e, pos.id)}
                  onDragLeave={() => setDragOverPos(null)}
                  onDrop={(e) => handleDrop(e, pos.id)}
                  className={`relative rounded-lg border-2 border-dashed transition-all p-3 ${pos.span} ${pos.minH} ${
                    dragOverPos === pos.id
                      ? 'border-primary bg-primary/10 scale-[1.02]'
                      : 'border-border'
                  } ${article ? 'bg-card' : 'bg-muted/20'}`}
                >
                  <div className="absolute top-2 right-2 text-xs font-bold text-muted-foreground/50">
                    {toPersianDigits(pos.id)}
                  </div>
                  <div className="absolute top-2 left-2 text-xs text-muted-foreground/50">
                    {pos.description}
                  </div>

                  {article ? (
                    <div className="h-full flex flex-col pt-8">
                      <div
                        draggable
                        onDragStart={() => handleDragStart(article.id)}
                        className="flex-1 flex flex-col gap-2 cursor-move group"
                      >
                        {article.coverImage && (
                          <div className="relative aspect-video rounded-md overflow-hidden bg-muted">
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img src={article.coverImage} alt={article.title} className="size-full object-cover" />
                          </div>
                        )}
                        <div className="flex-1">
                          {article.category && (
                            <span className="text-xs font-semibold" style={{ color: article.category.color }}>
                              {article.category.name}
                            </span>
                          )}
                          <h4 className="text-sm font-bold line-clamp-2">{article.title}</h4>
                          <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Eye className="size-3" />
                              {formatNumber(article.viewCount)}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="size-3" />
                              {formatRelativeTime(article.publishedAt || article.createdAt)}
                            </span>
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => handleRemoveFromPosition(article.id)}
                        className="mt-2 self-end size-6 rounded-full bg-destructive/10 text-destructive hover:bg-destructive hover:text-destructive-foreground flex items-center justify-center transition-colors"
                        title="حذف از این موقعیت"
                      >
                        <X className="size-3" />
                      </button>
                    </div>
                  ) : (
                    <div className="h-full flex items-center justify-center pt-8">
                      <div className="text-center text-muted-foreground/40">
                        <GripVertical className="size-6 mx-auto mb-1" />
                        <span className="text-xs">موقعیت خالی</span>
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </CardContent>
      </Card>

      {/* اخبار موجود (بدون موقعیت) */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">اخبار موجود برای چیدمان</CardTitle>
          <CardDescription>
            این اخبار در ۲۴ ساعت اخیر منتشر شده‌اند. برای قرار دادن در موقعیت دلخواه، آن‌ها را به گرید بالا بکشید.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {/* جستجوی خبر */}
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="جستجوی خبر..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pr-10"
              />
            </div>
          </div>

          {unpositionedArticles.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground text-sm">
              {searchQuery.trim() ? 'نتیجه‌ای یافت نشد' : 'همه اخبار موقعیت دارند یا خبری موجود نیست'}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {unpositionedArticles.map(article => (
                <div
                  key={article.id}
                  draggable
                  onDragStart={() => handleDragStart(article.id)}
                  className="rounded-lg border bg-card p-3 cursor-move hover:border-primary hover:shadow-md transition-all"
                >
                  <div className="flex gap-3">
                    {article.coverImage && (
                      <div className="relative size-16 shrink-0 rounded-md overflow-hidden bg-muted">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src={article.coverImage} alt={article.title} className="size-full object-cover" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      {article.category && (
                        <span className="text-xs font-semibold" style={{ color: article.category.color }}>
                          {article.category.name}
                        </span>
                      )}
                      <h4 className="text-sm font-medium line-clamp-2">{article.title}</h4>
                      <div className="mt-1 flex items-center gap-2 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="size-3" />
                          {formatRelativeTime(article.publishedAt || article.createdAt)}
                        </span>
                      </div>
                    </div>
                    <GripVertical className="size-4 text-muted-foreground shrink-0" />
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
