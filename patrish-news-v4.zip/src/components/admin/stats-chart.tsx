'use client'

import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts'
import { toPersianDigits } from '@/lib/persian'

interface ChartData {
  date: string
  count: number
}

export function AdminStatsChart({ data, color, label }: { data: ChartData[]; color: string; label: string }) {
  // Convert dates to short format and limit to last 14 days for readability
  const chartData = data.slice(-14).map(d => {
    const date = new Date(d.date)
    return {
      ...d,
      label: `${toPersianDigits(date.getDate())}`,
    }
  })

  return (
    <ResponsiveContainer width="100%" height={220}>
      <BarChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
        <defs>
          <linearGradient id={`gradient-${label}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor={color} stopOpacity={0.8} />
            <stop offset="95%" stopColor={color} stopOpacity={0.3} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
        <XAxis
          dataKey="label"
          stroke="var(--muted-foreground)"
          fontSize={11}
          tickLine={false}
          axisLine={false}
        />
        <YAxis
          stroke="var(--muted-foreground)"
          fontSize={11}
          tickLine={false}
          axisLine={false}
          tickFormatter={(v) => toPersianDigits(v)}
        />
        <Tooltip
          contentStyle={{
            backgroundColor: 'var(--card)',
            border: '1px solid var(--border)',
            borderRadius: '8px',
            fontSize: '12px',
          }}
          labelStyle={{ color: 'var(--foreground)' }}
          formatter={(value: number) => [toPersianDigits(value), label]}
        />
        <Bar
          dataKey="count"
          fill={`url(#gradient-${label})`}
          radius={[4, 4, 0, 0]}
          maxBarSize={32}
        />
      </BarChart>
    </ResponsiveContainer>
  )
}
