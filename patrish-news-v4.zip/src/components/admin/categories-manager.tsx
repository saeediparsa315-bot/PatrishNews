'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import { Globe, Cpu, Gamepad2, Clapperboard, FlaskConical, Trophy, Bitcoin, HeartPulse, Rocket, Newspaper, Landmark, Plus, Edit, Trash2, X, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { toPersianDigits } from '@/lib/persian'

const iconOptions = [
  { value: 'Globe', label: 'جهان', Icon: Globe },
  { value: 'Cpu', label: 'تکنولوژی', Icon: Cpu },
  { value: 'Gamepad2', label: 'گیم', Icon: Gamepad2 },
  { value: 'Clapperboard', label: 'سرگرمی', Icon: Clapperboard },
  { value: 'FlaskConical', label: 'علمی', Icon: FlaskConical },
  { value: 'Trophy', label: 'ورزشی', Icon: Trophy },
  { value: 'Landmark', label: 'سیاسی', Icon: Landmark },
  { value: 'Bitcoin', label: 'اقتصاد', Icon: Bitcoin },
  { value: 'HeartPulse', label: 'سلامت', Icon: HeartPulse },
  { value: 'Rocket', label: 'فضایی', Icon: Rocket },
  { value: 'Newspaper', label: 'عمومی', Icon: Newspaper },
]

const colorOptions = ['#7C3AED', '#06B6D4', '#F43F5E', '#F59E0B', '#10B981', '#3B82F6', '#EC4899', '#8B5CF6', '#14B8A6', '#F97316', '#DC2626']

const iconMap: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  Globe, Cpu, Gamepad2, Clapperboard, FlaskConical, Trophy, Bitcoin, HeartPulse, Rocket, Newspaper, Landmark,
}

interface Category {
  id: string
  name: string
  slug: string
  description: string | null
  color: string
  icon: string | null
  order: number
  isActive: boolean
  parentId: string | null
  parent?: { id: string; name: string; slug: string } | null
  children?: { id: string; name: string; slug: string; color: string; icon: string | null; isActive: boolean }[]
  _count: { articles: number }
}

export function CategoriesManager({ categories, canEdit }: { categories: Category[]; canEdit: boolean }) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Category | null>(null)
  const [deleteTarget, setDeleteTarget] = useState<Category | null>(null)
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({
    name: '',
    description: '',
    color: '#7C3AED',
    icon: 'Newspaper',
    parentId: '',
    order: 0,
    isActive: true,
  })

  const openNew = () => {
    setEditing(null)
    setForm({ name: '', description: '', color: '#7C3AED', icon: 'Newspaper', parentId: '', order: 0, isActive: true })
    setOpen(true)
  }

  const openEdit = (cat: Category) => {
    setEditing(cat)
    setForm({
      name: cat.name,
      description: cat.description || '',
      color: cat.color,
      icon: cat.icon || 'Newspaper',
      parentId: cat.parentId || '',
      order: cat.order,
      isActive: cat.isActive,
    })
    setOpen(true)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const url = editing ? `/api/categories/${editing.id}` : '/api/categories'
      const method = editing ? 'PUT' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name,
          description: form.description,
          color: form.color,
          icon: form.icon,
          parentId: form.parentId || null,
          order: Number(form.order),
          isActive: form.isActive,
        }),
        credentials: 'include',
      })
      const data = await res.json()
      if (data.success) {
        toast.success(editing ? 'دسته به‌روزرسانی شد' : 'دسته ایجاد شد')
        setOpen(false)
        router.refresh()
      } else {
        toast.error(data.error || 'خطا')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async () => {
    if (!deleteTarget) return
    setLoading(true)
    try {
      const res = await fetch(`/api/categories/${deleteTarget.id}`, { method: 'DELETE', credentials: 'include' })
      const data = await res.json()
      if (data.success) {
        toast.success('دسته حذف شد')
        setDeleteTarget(null)
        router.refresh()
      } else {
        toast.error(data.error || 'خطا')
      }
    } catch {
      toast.error('خطا')
    } finally {
      setLoading(false)
    }
  }

  const rootCategories = categories.filter(c => !c.parentId)

  return (
    <div className="space-y-6">
      {canEdit && (
        <div className="flex justify-end">
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button onClick={openNew}>
                <Plus className="size-4 ml-2" />
                افزودن دسته جدید
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>{editing ? 'ویرایش دسته' : 'افزودن دسته جدید'}</DialogTitle>
                <DialogDescription>
                  {editing ? 'اطلاعات دسته را ویرایش کنید' : 'یک دسته‌بندی جدید ایجاد کنید'}
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">نام دسته *</Label>
                  <Input
                    id="name"
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    placeholder="مثال: تکنولوژی"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">توضیحات</Label>
                  <Textarea
                    id="description"
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    placeholder="توضیحات کوتاه"
                    rows={2}
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label>آیکون</Label>
                    <Select value={form.icon} onValueChange={(v) => setForm({ ...form, icon: v })}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {iconOptions.map(opt => (
                          <SelectItem key={opt.value} value={opt.value}>
                            <span className="flex items-center gap-2">
                              <opt.Icon className="size-4" />
                              {opt.label}
                            </span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="order">ترتیب</Label>
                    <Input
                      id="order"
                      type="number"
                      value={form.order}
                      onChange={(e) => setForm({ ...form, order: Number(e.target.value) })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>رنگ</Label>
                  <div className="flex flex-wrap gap-2">
                    {colorOptions.map(color => (
                      <button
                        key={color}
                        type="button"
                        onClick={() => setForm({ ...form, color })}
                        className={`size-8 rounded-lg transition-all ${form.color === color ? 'ring-2 ring-offset-2 ring-offset-background' : ''}`}
                        style={{ backgroundColor: color, boxShadow: form.color === color ? `0 0 0 2px ${color}` : 'none' }}
                      />
                    ))}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>دسته والد (اختیاری)</Label>
                  <Select value={form.parentId} onValueChange={(v) => setForm({ ...form, parentId: v })}>
                    <SelectTrigger><SelectValue placeholder="بدون والد" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">بدون والد</SelectItem>
                      {rootCategories.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between pt-2">
                  <Label htmlFor="isActive">فعال</Label>
                  <Switch
                    id="isActive"
                    checked={form.isActive}
                    onCheckedChange={(v) => setForm({ ...form, isActive: v })}
                  />
                </div>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setOpen(false)}>انصراف</Button>
                  <Button type="submit" disabled={loading}>
                    {loading && <Loader2 className="size-4 ml-2 animate-spin" />}
                    {editing ? 'به‌روزرسانی' : 'ایجاد'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      )}

      {/* Categories grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {rootCategories.map(cat => {
          const Icon = cat.icon ? iconMap[cat.icon] : Newspaper
          return (
            <Card key={cat.id} className="overflow-hidden">
              <div
                className="h-2"
                style={{ backgroundColor: cat.color }}
              />
              <CardContent className="pt-5">
                <div className="flex items-start justify-between mb-3">
                  <div
                    className="size-12 rounded-xl flex items-center justify-center"
                    style={{ backgroundColor: `${cat.color}20` }}
                  >
                    <Icon className="size-6" style={{ color: cat.color }} />
                  </div>
                  <div className="flex items-center gap-1">
                    {!cat.isActive && (
                      <Badge variant="outline" className="text-xs">غیرفعال</Badge>
                    )}
                    {canEdit && (
                      <>
                        <Button variant="ghost" size="icon" className="size-8" onClick={() => openEdit(cat)}>
                          <Edit className="size-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="size-8 text-destructive"
                          onClick={() => setDeleteTarget(cat)}
                        >
                          <Trash2 className="size-4" />
                        </Button>
                      </>
                    )}
                  </div>
                </div>
                <h3 className="font-bold text-lg mb-1">{cat.name}</h3>
                {cat.description && (
                  <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{cat.description}</p>
                )}
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span>{toPersianDigits(cat._count.articles)} خبر</span>
                  {cat.children && cat.children.length > 0 && (
                    <span>{toPersianDigits(cat.children.length)} زیردسته</span>
                  )}
                </div>

                {/* Children */}
                {cat.children && cat.children.length > 0 && (
                  <div className="mt-3 pt-3 border-t space-y-1">
                    {cat.children.map(child => {
                      const ChildIcon = child.icon ? iconMap[child.icon] : null
                      return (
                        <div key={child.id} className="flex items-center gap-2 text-sm">
                          {ChildIcon && <ChildIcon className="size-3" style={{ color: child.color }} />}
                          <span>{child.name}</span>
                          {!child.isActive && <Badge variant="outline" className="text-xs">غیرفعال</Badge>}
                        </div>
                      )
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Delete dialog */}
      <Dialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>حذف دسته</DialogTitle>
            <DialogDescription>
              آیا از حذف دسته «{deleteTarget?.name}» مطمئن هستید؟
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteTarget(null)}>انصراف</Button>
            <Button variant="destructive" onClick={handleDelete} disabled={loading}>
              {loading ? <Loader2 className="size-4 ml-2 animate-spin" /> : null}
              حذف
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
