'use client'

import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { Search, X, TrendingUp, Clock } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

interface SearchResult {
  id: string
  title: string
  slug: string
  excerpt: string | null
  category?: { name: string; color: string } | null
}

export function AdvancedSearch({ onClose }: { onClose?: () => void }) {
  const router = useRouter()
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<SearchResult[]>([])
  const [loading, setLoading] = useState(false)
  const [showResults, setShowResults] = useState(false)
  const [highlightedIndex, setHighlightedIndex] = useState(-1)
  const containerRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  // جستجوی debounce شده
  useEffect(() => {
    if (query.trim().length < 2) {
      setResults([])
      setShowResults(false)
      return
    }

    const timeoutId = setTimeout(async () => {
      setLoading(true)
      try {
        const res = await fetch(`/api/articles?search=${encodeURIComponent(query)}&limit=8`)
        const data = await res.json()
        if (data.success) {
          setResults(data.data)
          setShowResults(true)
        }
      } catch {
        setResults([])
      } finally {
        setLoading(false)
      }
    }, 300)

    return () => clearTimeout(timeoutId)
  }, [query])

  // بستن dropdown با کلیک خارج
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setShowResults(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  // keyboard navigation (درخواست ۲۳ - accessibility)
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!showResults || results.length === 0) return

    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setHighlightedIndex((prev) => (prev + 1) % results.length)
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setHighlightedIndex((prev) => (prev - 1 + results.length) % results.length)
    } else if (e.key === 'Enter' && highlightedIndex >= 0) {
      e.preventDefault()
      const selected = results[highlightedIndex]
      if (selected) {
        router.push(`/article/${selected.slug}`)
        setShowResults(false)
        onClose?.()
      }
    } else if (e.key === 'Escape') {
      setShowResults(false)
      inputRef.current?.blur()
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) {
      router.push(`/search?q=${encodeURIComponent(query.trim())}`)
      setShowResults(false)
      onClose?.()
    }
  }

  // highlight کلمه جستجو شده (درخواست ۱۲)
  const highlightText = (text: string, query: string) => {
    if (!query.trim()) return text
    const regex = new RegExp(`(${query.trim().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi')
    const parts = text.split(regex)
    return parts.map((part, i) =>
      regex.test(part) ? (
        <mark key={i} className="bg-primary/30 text-primary px-0.5 rounded">{part}</mark>
      ) : part
    )
  }

  return (
    <div ref={containerRef} className="relative w-full">
      <form onSubmit={handleSubmit}>
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <Input
            ref={inputRef}
            type="search"
            placeholder="جستجوی خبر..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => query.length >= 2 && setShowResults(true)}
            onKeyDown={handleKeyDown}
            className="pr-10 pl-10 h-10"
            aria-label="جستجو"
            aria-expanded={showResults}
            aria-controls="search-results"
            role="combobox"
            aria-autocomplete="list"
          />
          {query && (
            <button
              type="button"
              onClick={() => { setQuery(''); setResults([]); setShowResults(false); inputRef.current?.focus() }}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label="پاک کردن جستجو"
            >
              <X className="size-4" />
            </button>
          )}
          {loading && (
            <div className="absolute left-9 top-1/2 -translate-y-1/2">
              <div className="size-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            </div>
          )}
        </div>
      </form>

      {/* Dropdown نتایج (درخواست ۱۲) */}
      {showResults && results.length > 0 && (
        <div
          id="search-results"
          role="listbox"
          className="absolute top-full mt-2 w-full bg-popover border rounded-lg shadow-lg max-h-96 overflow-y-auto z-50 animate-fade-in"
        >
          <div className="p-2 text-xs text-muted-foreground border-b flex items-center gap-1">
            <TrendingUp className="size-3" />
            {results.length} نتیجه یافت شد
          </div>
          {results.map((result, idx) => (
            <Link
              key={result.id}
              href={`/article/${result.slug}`}
              onClick={() => { setShowResults(false); onClose?.() }}
              role="option"
              aria-selected={idx === highlightedIndex}
              className={`block p-3 hover:bg-accent/10 transition-colors border-b last:border-0 ${
                idx === highlightedIndex ? 'bg-accent/10' : ''
              }`}
            >
              <div className="flex items-start gap-2">
                {result.category && (
                  <span
                    className="text-xs font-semibold px-2 py-0.5 rounded shrink-0"
                    style={{ backgroundColor: `${result.category.color}20`, color: result.category.color }}
                  >
                    {result.category.name}
                  </span>
                )}
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm line-clamp-1">
                    {highlightText(result.title, query)}
                  </div>
                  {result.excerpt && (
                    <div className="text-xs text-muted-foreground line-clamp-1 mt-0.5">
                      {highlightText(result.excerpt, query)}
                    </div>
                  )}
                </div>
              </div>
            </Link>
          ))}
          <div className="p-2 border-t">
            <button
              onClick={handleSubmit}
              className="w-full text-center text-sm text-primary hover:underline"
            >
              مشاهده همه نتایج برای «{query}»
            </button>
          </div>
        </div>
      )}

      {showResults && results.length === 0 && !loading && query.length >= 2 && (
        <div className="absolute top-full mt-2 w-full bg-popover border rounded-lg shadow-lg p-6 text-center text-sm text-muted-foreground z-50">
          <Clock className="size-8 mx-auto mb-2 opacity-30" />
          نتیجه‌ای برای «{query}» یافت نشد
        </div>
      )}
    </div>
  )
}
