'use client'

import { useState, useEffect } from 'react'
import { Users, Eye, FileText, TrendingUp } from 'lucide-react'
import { toPersianDigits } from '@/lib/persian'

interface LiveStats {
  totalArticles: number
  totalViews: number
  totalUsers: number
  todayArticles: number
}

export function LiveStatsWidget() {
  const [stats, setStats] = useState<LiveStats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch('/api/stats/public')
        const data = await res.json()
        if (data.success) {
          setStats(data.data)
        }
      } catch {} finally {
        setLoading(false)
      }
    }

    fetchStats()
    // آپدیت هر ۳۰ ثانیه
    const interval = setInterval(fetchStats, 30000)
    return () => clearInterval(interval)
  }, [])

  if (loading || !stats) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[1, 2, 3, 4].map(i => (
          <div key={i} className="skeleton h-20 rounded-xl" />
        ))}
      </div>
    )
  }

  const items = [
    { label: 'کل اخبار', value: stats.totalArticles, icon: FileText, color: '#06B6D4' },
    { label: 'کل بازدیدها', value: stats.totalViews, icon: Eye, color: '#7C3AED' },
    { label: 'کاربران', value: stats.totalUsers, icon: Users, color: '#10B981' },
    { label: 'اخبار امروز', value: stats.todayArticles, icon: TrendingUp, color: '#F59E0B' },
  ]

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
      {items.map((item) => (
        <div
          key={item.label}
          className="p-4 rounded-xl border bg-card hover:shadow-md transition-all hover-scale"
        >
          <div className="flex items-center justify-between mb-2">
            <div
              className="size-9 rounded-lg flex items-center justify-center"
              style={{ backgroundColor: `${item.color}20` }}
            >
              <item.icon className="size-4" style={{ color: item.color }} />
            </div>
            <span className="live-dot" title="زنده" />
          </div>
          <div className="text-2xl font-bold font-mono">{toPersianDigits(item.value)}</div>
          <div className="text-xs text-muted-foreground">{item.label}</div>
        </div>
      ))}
    </div>
  )
}
