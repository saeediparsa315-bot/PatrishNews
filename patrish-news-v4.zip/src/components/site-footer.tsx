'use client'

import Link from 'next/link'
import { useSettings } from '@/components/settings-provider'
import { Mail, Twitter, Youtube, Send, Instagram } from 'lucide-react'

export function SiteFooter() {
  const { settings } = useSettings()

  return (
    <footer className="mt-auto border-t border-border/40 bg-muted/10">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="size-10 rounded-lg gradient-bg flex items-center justify-center text-white font-bold">
                {settings.site_logo_text?.charAt(0) || 'پ'}
              </div>
              <span className="text-xl font-bold">{settings.site_logo_text || 'پاتریش'}</span>
            </Link>
            <p className="text-sm text-muted-foreground mb-4 leading-7 max-w-md">
              {settings.site_description}
            </p>
            <div className="flex items-center gap-2">
              {settings.social_telegram && (
                <a href={settings.social_telegram} target="_blank" rel="noreferrer"
                  className="size-9 rounded-lg bg-muted flex items-center justify-center hover:bg-accent/20 transition-colors">
                  <Send className="h-4 w-4" />
                </a>
              )}
              {settings.social_instagram && (
                <a href={settings.social_instagram} target="_blank" rel="noreferrer"
                  className="size-9 rounded-lg bg-muted flex items-center justify-center hover:bg-accent/20 transition-colors">
                  <Instagram className="h-4 w-4" />
                </a>
              )}
              {settings.social_twitter && (
                <a href={settings.social_twitter} target="_blank" rel="noreferrer"
                  className="size-9 rounded-lg bg-muted flex items-center justify-center hover:bg-accent/20 transition-colors">
                  <Twitter className="h-4 w-4" />
                </a>
              )}
              {settings.social_youtube && (
                <a href={settings.social_youtube} target="_blank" rel="noreferrer"
                  className="size-9 rounded-lg bg-muted flex items-center justify-center hover:bg-accent/20 transition-colors">
                  <Youtube className="h-4 w-4" />
                </a>
              )}
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h3 className="font-semibold mb-4">دسترسی سریع</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link href="/" className="hover:text-foreground transition-colors">خانه</Link></li>
              <li><Link href="/breaking" className="hover:text-foreground transition-colors">اخبار فوری</Link></li>
              <li><Link href="/search" className="hover:text-foreground transition-colors">جستجو</Link></li>
              <li><Link href="/about" className="hover:text-foreground transition-colors">درباره ما</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold mb-4">تماس با ما</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {settings.contact_email && (
                <li className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <a href={`mailto:${settings.contact_email}`} className="hover:text-foreground">
                    {settings.contact_email}
                  </a>
                </li>
              )}
            </ul>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-border/40 text-center text-sm text-muted-foreground">
          {settings.footer_text}
        </div>
      </div>
    </footer>
  )
}
