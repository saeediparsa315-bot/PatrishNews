'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Menu, Moon, Sun, User, Bookmark, LogOut, LayoutDashboard } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet'
import { useTheme } from 'next-themes'
import Link from 'next/link'
import { useSettings } from '@/components/settings-provider'
import type { SessionUser } from '@/lib/types'
import {
  Globe, Cpu, Gamepad2, Clapperboard, FlaskConical, Trophy,
  Bitcoin, HeartPulse, Rocket, Newspaper, Landmark, ChevronLeft, Hash,
} from 'lucide-react'
import { toast } from 'sonner'

const iconMap: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  Globe, Cpu, Gamepad2, Clapperboard, FlaskConical, Trophy,
  Bitcoin, HeartPulse, Rocket, Newspaper, Landmark,
}

interface Category {
  id: string
  name: string
  slug: string
  color: string
  icon: string | null
  description?: string | null
  children?: { id: string; name: string; slug: string; color: string; icon: string | null }[]
}

export function SiteHeader({
  user,
  categories,
}: {
  user: SessionUser | null
  categories: Category[]
}) {
  const router = useRouter()
  const { theme, setTheme } = useTheme()
  const { settings } = useSettings()
  const [mounted, setMounted] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => setMounted(true), [])

  const handleLogout = async () => {
    // پاک کردن localStorage token و cookie
    try { localStorage.removeItem('patrish_auth_token') } catch {}
    try {
      document.cookie = 'news_session=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC; SameSite=Lax'
    } catch {}
    const res = await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' })
    if (res.ok) {
      toast.success('با موفقیت خارج شدید')
      setTimeout(() => {
        window.location.href = '/'
      }, 300)
    }
  }

  return (
    <header className="sticky top-0 z-40 w-full border-b border-border/40 glass">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between gap-3">
          {/* Right: Menu trigger (only icon, no text - درخواست ۷) */}
          <div className="flex items-center gap-2">
            <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" aria-label="منو">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[320px] sm:w-[400px] p-0 border-l-0">
                <SheetTitle className="sr-only">منوی اصلی پاتریش نیوز</SheetTitle>
                <MobileMenu
                  user={user}
                  categories={categories}
                  onNavigate={() => setMenuOpen(false)}
                  onLogout={handleLogout}
                />
              </SheetContent>
            </Sheet>

            <Link href="/" className="flex items-center gap-2">
              <div className="size-9 rounded-lg gradient-bg flex items-center justify-center text-white font-bold glow">
                {settings.site_logo_text?.charAt(0) || 'پ'}
              </div>
              <span className="hidden sm:block text-lg font-bold tracking-tight">
                {settings.site_logo_text || 'پاتریش'}
              </span>
            </Link>
          </div>

          {/* Center: Desktop nav (visible on tablet+ with icons, full text on desktop) */}
          <nav className="hidden md:flex items-center gap-0.5 lg:gap-1 flex-1 justify-center max-w-2xl overflow-x-auto no-scrollbar">
            {categories.slice(0, 7).map(cat => {
              const Icon = cat.icon ? iconMap[cat.icon] : null
              return (
                <Link
                  key={cat.id}
                  href={`/category/${cat.slug}`}
                  className="px-2 sm:px-2.5 lg:px-3 py-2 rounded-md text-xs lg:text-sm font-medium hover:bg-accent/10 hover:text-accent transition-colors flex items-center gap-1 lg:gap-1.5 whitespace-nowrap shrink-0"
                  title={cat.name}
                >
                  {Icon && <Icon className="size-4 shrink-0" style={{ color: cat.color }} />}
                  <span className="hidden lg:inline">{cat.name}</span>
                </Link>
              )
            })}
          </nav>

          {/* Left: theme + user */}
          <div className="flex items-center gap-1.5">
            {/* Theme toggle */}
            {mounted && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                aria-label="تغییر تم"
                className="h-9 w-9"
              >
                {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
            )}

            {/* User menu */}
            {user ? (
              <div className="flex items-center gap-1">
                {(user.role === 'ADMIN' || user.role === 'SUPER_ADMIN') && (
                  <Link href="/admin">
                    <Button variant="ghost" size="icon" className="h-9 w-9" title="پنل مدیریت">
                      <LayoutDashboard className="h-5 w-5" />
                    </Button>
                  </Link>
                )}
                <Link href="/bookmarks">
                  <Button variant="ghost" size="icon" className="h-9 w-9" title="ذخیره‌ها">
                    <Bookmark className="h-5 w-5" />
                  </Button>
                </Link>
                <Link href="/profile">
                  <Button variant="ghost" size="icon" className="h-9 w-9" title="پروفایل">
                    <User className="h-5 w-5" />
                  </Button>
                </Link>
                <Button variant="ghost" size="icon" onClick={handleLogout} className="h-9 w-9" title="خروج">
                  <LogOut className="h-5 w-5" />
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-1.5">
                <Link href="/login">
                  <Button variant="ghost" size="sm">ورود</Button>
                </Link>
                <Link href="/register" className="hidden sm:block">
                  <Button size="sm">ثبت‌نام</Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}

// Mobile menu content (also used for desktop drawer)
function MobileMenu({
  user,
  categories,
  onNavigate,
  onLogout,
}: {
  user: SessionUser | null
  categories: Category[]
  onNavigate: () => void
  onLogout: () => void
}) {
  const { settings } = useSettings()

  return (
    <div className="flex h-full flex-col bg-gradient-to-b from-background to-muted/20">
      {/* Header - درخواست ۹: دکمه ضربدر برای بستن */}
      <div className="border-b p-5 bg-gradient-to-l from-primary/10 to-accent/10 relative">
        <Link href="/" onClick={onNavigate} className="flex items-center gap-3">
          <div className="size-12 rounded-xl gradient-bg flex items-center justify-center text-white font-bold text-lg glow">
            {settings.site_logo_text?.charAt(0) || 'پ'}
          </div>
          <div>
            <div className="text-xl font-bold">{settings.site_name || 'پاتریش نیوز'}</div>
            <div className="text-xs text-muted-foreground">{settings.site_description}</div>
          </div>
        </Link>
      </div>

      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto p-4 no-scrollbar">
        {/* User section */}
        {user ? (
          <div className="mb-4 p-3 rounded-xl bg-card border">
            <Link href="/profile" onClick={onNavigate} className="flex items-center gap-3">
              <div className="size-10 rounded-full bg-primary/15 flex items-center justify-center font-bold text-primary">
                {(user.name || user.username).charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-semibold truncate">{user.name || user.username}</div>
                <div className="text-xs text-muted-foreground truncate">{user.email}</div>
              </div>
            </Link>
            <div className="mt-3 grid grid-cols-2 gap-2">
              {(user.role === 'ADMIN' || user.role === 'SUPER_ADMIN') && (
                <Link href="/admin" onClick={onNavigate}>
                  <Button variant="outline" size="sm" className="w-full">
                    <LayoutDashboard className="h-4 w-4 ml-1" />
                    پنل مدیریت
                  </Button>
                </Link>
              )}
              <Link href="/bookmarks" onClick={onNavigate}>
                <Button variant="outline" size="sm" className={user.role === 'ADMIN' || user.role === 'SUPER_ADMIN' ? 'w-full' : 'w-full col-span-2'}>
                  <Bookmark className="h-4 w-4 ml-1" />
                  ذخیره‌ها
                </Button>
              </Link>
              <Button variant="outline" size="sm" onClick={onLogout} className="col-span-2 text-destructive">
                <LogOut className="h-4 w-4 ml-1" />
                خروج از حساب
              </Button>
            </div>
          </div>
        ) : (
          <div className="mb-4 grid grid-cols-2 gap-2">
            <Link href="/login" onClick={onNavigate}>
              <Button variant="outline" className="w-full">ورود</Button>
            </Link>
            <Link href="/register" onClick={onNavigate}>
              <Button className="w-full">ثبت‌نام</Button>
            </Link>
          </div>
        )}

        {/* Navigation links */}
        <div className="space-y-1">
          <Link
            href="/"
            onClick={onNavigate}
            className="flex items-center gap-3 p-3 rounded-lg hover:bg-accent/10 transition-colors font-medium"
          >
            <Newspaper className="h-5 w-5 text-primary" />
            صفحه اصلی
            <ChevronLeft className="h-4 w-4 mr-auto text-muted-foreground" />
          </Link>
          <Link
            href="/breaking"
            onClick={onNavigate}
            className="flex items-center gap-3 p-3 rounded-lg hover:bg-accent/10 transition-colors font-medium"
          >
            <Hash className="h-5 w-5 text-destructive" />
            اخبار فوری
            <ChevronLeft className="h-4 w-4 mr-auto text-muted-foreground" />
          </Link>
        </div>

        {/* Categories section */}
        <div className="mt-6">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 px-3">
            دسته‌بندی‌ها
          </div>
          <div className="space-y-1">
            {categories.map(cat => {
              const Icon = cat.icon ? iconMap[cat.icon] : null
              return (
                <div key={cat.id}>
                  <Link
                    href={`/category/${cat.slug}`}
                    onClick={onNavigate}
                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-accent/10 transition-colors group"
                  >
                    {Icon ? (
                      <div
                        className="size-9 rounded-lg flex items-center justify-center"
                        style={{ backgroundColor: `${cat.color}20` }}
                      >
                        <Icon className="h-5 w-5" style={{ color: cat.color }} />
                      </div>
                    ) : (
                      <div className="size-9 rounded-lg bg-muted flex items-center justify-center">
                        <Hash className="h-5 w-5" />
                      </div>
                    )}
                    <div className="flex-1">
                      <div className="font-medium">{cat.name}</div>
                      {cat.description && (
                        <div className="text-xs text-muted-foreground truncate">{cat.description}</div>
                      )}
                    </div>
                    <ChevronLeft className="h-4 w-4 text-muted-foreground group-hover:translate-x-1 transition-transform" />
                  </Link>
                  {cat.children && cat.children.length > 0 && (
                    <div className="pr-12 py-1 space-y-0.5">
                      {cat.children.map(child => (
                        <Link
                          key={child.id}
                          href={`/category/${child.slug}`}
                          onClick={onNavigate}
                          className="flex items-center gap-2 p-2 rounded-md text-sm text-muted-foreground hover:text-foreground hover:bg-accent/5"
                        >
                          <ChevronLeft className="h-3 w-3" />
                          {child.name}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>

        {/* Footer info */}
        <div className="mt-6 p-3 rounded-lg bg-muted/30 text-xs text-muted-foreground text-center">
          <div className="font-semibold text-foreground mb-1">{settings.site_name}</div>
          <div>{settings.footer_text}</div>
          {settings.contact_email && (
            <a href={`mailto:${settings.contact_email}`} className="text-primary mt-1 inline-block">
              {settings.contact_email}
            </a>
          )}
        </div>
      </div>
    </div>
  )
}
