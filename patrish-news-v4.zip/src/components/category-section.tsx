'use client'

import Link from 'next/link'
import { ArticleCard } from '@/components/article-card'
import { ChevronLeft } from 'lucide-react'
import { Globe, Cpu, Gamepad2, Clapperboard, FlaskConical, Trophy, Bitcoin, HeartPulse, Rocket, Newspaper, Landmark } from 'lucide-react'
import type { ArticleWithRelations } from '@/lib/types'

const iconMap: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  Globe, Cpu, Gamepad2, Clapperboard, FlaskConical, Trophy, Bitcoin, HeartPulse, Rocket, Newspaper, Landmark,
}

interface CategorySectionProps {
  category: {
    id: string
    name: string
    slug: string
    color: string
    icon: string | null
    description?: string | null
  }
  articles: ArticleWithRelations[]
}

export function CategorySection({ category, articles }: CategorySectionProps) {
  if (articles.length === 0) return null

  const Icon = category.icon ? iconMap[category.icon] : Newspaper

  return (
    <section className="mb-12">
      <div className="flex items-center justify-between mb-6">
        <Link
          href={`/category/${category.slug}`}
          className="group flex items-center gap-3"
        >
          <div
            className="size-10 rounded-lg flex items-center justify-center"
            style={{ backgroundColor: `${category.color}20` }}
          >
            <Icon className="h-5 w-5" style={{ color: category.color }} />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold group-hover:text-primary transition-colors">
              {category.name}
            </h2>
            {category.description && (
              <p className="text-xs text-muted-foreground">{category.description}</p>
            )}
          </div>
        </Link>
        <Link
          href={`/category/${category.slug}`}
          className="text-sm text-primary hover:underline flex items-center gap-1"
        >
          مشاهده همه
          <ChevronLeft className="h-4 w-4" />
        </Link>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        {articles.map(article => (
          <ArticleCard key={article.id} article={article} variant="compact" showCategory={false} />
        ))}
      </div>
    </section>
  )
}
