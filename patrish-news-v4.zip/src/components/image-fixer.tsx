'use client'

import { useEffect } from 'react'

/**
 * رفع مشکل نمایش تصاویر در محتوای خبر
 * - اضافه‌کردن fallback برای تصاویر خراب
 * - اضافه‌کردن loading="lazy"
 * - بهبود نمایش
 */
export function ImageFixer() {
  useEffect(() => {
    const fixImages = () => {
      // تمام تصاویر داخل محتوای خبر
      const contentImages = document.querySelectorAll('.article-content img, .article-content-editor img, img[data-article-img]')
      contentImages.forEach((img) => {
        const el = img as HTMLImageElement
        // اگر قبلاً handler اضافه نشده
        if (!el.dataset.fixed) {
          el.dataset.fixed = 'true'
          el.loading = 'lazy'
          el.decoding = 'async'
          el.onerror = () => {
            // نمایش placeholder
            el.style.display = 'inline-block'
            el.style.minHeight = '200px'
            el.style.width = '100%'
            el.style.background = 'linear-gradient(135deg, var(--muted), var(--secondary))'
            el.style.borderRadius = '0.75rem'
            el.style.margin = '1.5rem 0'
            // اگر src خراب است، یک data URI placeholder قرار بده
            el.src = 'data:image/svg+xml;utf8,' + encodeURIComponent(`
              <svg xmlns="http://www.w3.org/2000/svg" width="800" height="400" viewBox="0 0 800 400">
                <defs>
                  <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" style="stop-color:#7C3AED;stop-opacity:0.3"/>
                    <stop offset="100%" style="stop-color:#06B6D4;stop-opacity:0.3"/>
                  </linearGradient>
                </defs>
                <rect width="800" height="400" fill="url(#g)"/>
                <text x="50%" y="50%" fill="#7C3AED" font-family="Arial" font-size="28" text-anchor="middle" dy=".3em" font-weight="bold">پاتریش نیوز</text>
                <text x="50%" y="58%" fill="#999" font-family="Arial" font-size="16" text-anchor="middle" dy=".3em">تصویر در دسترس نیست</text>
              </svg>
            `)
          }
          // اگر src خالی است یا خراب است
          if (!el.src || el.src === window.location.href) {
            el.onerror?.(new Event('error'))
          }
        }
      })

      // تمام تصاویر با کلاس article-image
      const articleImages = document.querySelectorAll('img.article-image, img[data-article-image]')
      articleImages.forEach((img) => {
        const el = img as HTMLImageElement
        if (!el.dataset.fixed) {
          el.dataset.fixed = 'true'
          el.loading = 'lazy'
          el.decoding = 'async'
        }
      })
    }

    // اولین اجرا
    fixImages()

    // در صورت تغییر DOM
    const observer = new MutationObserver(() => {
      fixImages()
    })
    observer.observe(document.body, { childList: true, subtree: true })

    return () => observer.disconnect()
  }, [])

  return null
}
