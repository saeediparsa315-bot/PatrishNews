'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Send, Loader2, CheckCircle2 } from 'lucide-react'
import { toast } from 'sonner'

export function ContactForm() {
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setLoading(true)
    const formData = new FormData(e.currentTarget)
    const data = {
      name: formData.get('name'),
      email: formData.get('email'),
      subject: formData.get('subject'),
      message: formData.get('message'),
    }
    // شبیه‌سازی ارسال
    setTimeout(() => {
      setLoading(false)
      setSuccess(true)
      toast.success('پیام شما ارسال شد! به‌زودی پاسخ می‌دهیم.')
      ;(e.target as HTMLFormElement).reset()
      setTimeout(() => setSuccess(false), 3000)
    }, 1000)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">نام شما *</Label>
        <Input id="name" name="name" required placeholder="نام و نام خانوادگی" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="email">ایمیل *</Label>
        <Input id="email" name="email" type="email" required placeholder="email@example.com" dir="ltr" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="subject">موضوع</Label>
        <Input id="subject" name="subject" placeholder="موضوع پیام" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="message">پیام *</Label>
        <Textarea id="message" name="message" required rows={5} placeholder="پیام خود را اینجا بنویسید..." />
      </div>
      <Button type="submit" className="w-full" disabled={loading || success}>
        {loading ? (
          <>
            <Loader2 className="size-4 ml-2 animate-spin" />
            در حال ارسال...
          </>
        ) : success ? (
          <>
            <CheckCircle2 className="size-4 ml-2" />
            ارسال شد!
          </>
        ) : (
          <>
            <Send className="size-4 ml-2" />
            ارسال پیام
          </>
        )}
      </Button>
    </form>
  )
}
