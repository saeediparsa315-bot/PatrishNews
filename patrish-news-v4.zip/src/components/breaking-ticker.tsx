'use client'

import Link from 'next/link'
import { Radio } from 'lucide-react'
import { formatRelativeTime } from '@/lib/persian'

interface BreakingArticle {
  id: string
  title: string
  slug: string
  publishedAt: Date | string | null
  category?: { name: string; slug: string; color: string } | null
}

export function BreakingTicker({ articles }: { articles: BreakingArticle[] }) {
  if (!articles.length) return null

  return (
    <div className="bg-destructive text-destructive-foreground border-y border-destructive/50">
      <div className="container mx-auto px-4">
        <div className="flex items-center gap-3 py-2">
          <div className="flex items-center gap-2 shrink-0 font-bold text-sm">
            <Radio className="h-4 w-4 animate-pulse" />
            <span className="hidden sm:inline">اخبار فوری</span>
          </div>
          <div className="flex-1 overflow-hidden">
            <div className="ticker">
              <div className="ticker-content">
                {articles.concat(articles).map((article, idx) => (
                  <Link
                    key={`${article.id}-${idx}`}
                    href={`/article/${article.slug}`}
                    className="inline-flex items-center gap-2 ml-8 text-sm hover:underline"
                    dir="rtl"
                  >
                    {article.category && (
                      <span className="font-semibold">[{article.category.name}]</span>
                    )}
                    {article.title}
                    {article.publishedAt && (
                      <span className="opacity-70 text-xs">— {formatRelativeTime(article.publishedAt)}</span>
                    )}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
