'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { User, Mail, Lock, Save, LogOut, AlertCircle } from 'lucide-react'
import { toast } from 'sonner'
import type { SessionUser } from '@/lib/types'

export function ProfileForm({ user }: { user: SessionUser }) {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [logoutLoading, setLogoutLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setLoading(true)
    const formData = new FormData(e.currentTarget)
    const body: Record<string, string> = {}
    if (formData.get('name')) body.name = formData.get('name') as string
    if (formData.get('username')) body.username = formData.get('username') as string
    if (formData.get('password')) body.password = formData.get('password') as string

    try {
      const res = await fetch('/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, action: 'UPDATE_PROFILE', ...body }),
        credentials: 'include',
      })
      const data = await res.json()
      if (data.success) {
        toast.success('پروفایل به‌روزرسانی شد')
        router.refresh()
      } else {
        toast.error(data.error || 'خطا در به‌روزرسانی')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = async () => {
    setLogoutLoading(true)
    try {
      // پاک کردن localStorage token
      try { localStorage.removeItem('patrish_auth_token') } catch {}
      await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' })
      toast.success('خارج شدید')
      setTimeout(() => {
        window.location.href = '/'
      }, 300)
    } catch {
      toast.error('خطا')
    } finally {
      setLogoutLoading(false)
    }
  }

  return (
    <div className="max-w-2xl space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>ویرایش پروفایل</CardTitle>
          <CardDescription>اطلاعات حساب کاربری خود را به‌روز کنید</CardDescription>
        </CardHeader>
        <form onSubmit={handleSubmit}>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">نام نمایشی</Label>
              <div className="relative">
                <User className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                <Input
                  id="name"
                  name="name"
                  type="text"
                  defaultValue={user.name || ''}
                  placeholder="نام شما"
                  className="pr-10"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="username">نام کاربری</Label>
              <div className="relative">
                <User className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                <Input
                  id="username"
                  name="username"
                  type="text"
                  defaultValue={user.username}
                  required
                  className="pr-10"
                  dir="ltr"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">ایمیل</Label>
              <div className="relative">
                <Mail className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  defaultValue={user.email}
                  disabled
                  className="pr-10 opacity-60"
                  dir="ltr"
                />
              </div>
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <AlertCircle className="size-3" />
                ایمیل قابل تغییر نیست
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">رمز عبور جدید (اختیاری)</Label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                <Input
                  id="password"
                  name="password"
                  type="password"
                  minLength={6}
                  placeholder="برای تغییر، رمز جدید وارد کنید"
                  className="pr-10"
                  dir="ltr"
                />
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button type="button" variant="destructive" onClick={handleLogout} disabled={logoutLoading}>
              <LogOut className="size-4 ml-2" />
              {logoutLoading ? 'در حال خروج...' : 'خروج از حساب'}
            </Button>
            <Button type="submit" disabled={loading}>
              <Save className="size-4 ml-2" />
              {loading ? 'در حال ذخیره...' : 'ذخیره تغییرات'}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  )
}
