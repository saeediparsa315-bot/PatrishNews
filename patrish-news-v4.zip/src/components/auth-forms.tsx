'use client'

import { useState, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { LogIn, UserPlus, Mail, Lock, User, AlertCircle, Loader2, CheckCircle2 } from 'lucide-react'
import { toast } from 'sonner'

const TOKEN_KEY = 'patrish_auth_token'

// ذخیره توکن در localStorage و cookie (به عنوان fallback)
function saveToken(token: string) {
  try {
    localStorage.setItem(TOKEN_KEY, token)
  } catch {}

  // ذخیره در cookie هم (برای request‌های server-side)
  try {
    const expires = new Date()
    expires.setDate(expires.getDate() + 30)
    document.cookie = `news_session=${token}; path=/; expires=${expires.toUTCString()}; SameSite=Lax`
  } catch {}
}

// پاک کردن توکن
export function clearToken() {
  try {
    localStorage.removeItem(TOKEN_KEY)
  } catch {}
  try {
    document.cookie = 'news_session=; path=/; expires=Thu, 01 Jan 1970 00:00:00 UTC; SameSite=Lax'
  } catch {}
}

// گرفتن توکن از localStorage یا cookie
export function getToken(): string | null {
  try {
    const localToken = localStorage.getItem(TOKEN_KEY)
    if (localToken) return localToken
  } catch {}

  // fallback به cookie
  try {
    const match = document.cookie.match(/(?:^|;\s*)news_session=([^;]+)/)
    if (match) return match[1]
  } catch {}

  return null
}

// تابع کمکی برای fetch با Authorization header (برای مواردی که cookie کار نمی‌کنه)
export async function authFetch(url: string, options: RequestInit = {}): Promise<Response> {
  const token = getToken()

  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string> || {}),
  }
  if (token) {
    headers['x-auth-token'] = token
  }

  return fetch(url, { ...options, headers, credentials: 'include' })
}

export function LoginForm() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  const handleSubmit = useCallback(async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    const formData = new FormData(e.currentTarget)
    const email = String(formData.get('email') || '').trim()
    const password = String(formData.get('password') || '')

    if (!email || !password) {
      setError('ایمیل و رمز عبور را وارد کنید')
      setLoading(false)
      return
    }

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
        credentials: 'include',
      })
      const data = await res.json()

      if (data.success) {
        // ذخیره توکن در localStorage و cookie برای fallback
        if (data.token) {
          saveToken(data.token)
        }
        toast.success('خوش آمدید!')
        setSuccess(true)

        // صبر کن تا cookie و localStorage ست شوند
        // بعد صفحه رو کامل reload کن (نه client-side navigation)
        // این مهمه چون در هاست واقعی، cookie باید با request بعدی فرستاده بشه
        setTimeout(() => {
          // force reload به صفحه اصلی
          window.location.href = '/'
        }, 800)
      } else {
        setError(data.error || 'خطا در ورود')
        setLoading(false)
      }
    } catch (err) {
      setError('خطا در ارتباط با سرور: ' + (err instanceof Error ? err.message : ''))
      setLoading(false)
    }
  }, [])

  return (
    <Card className="w-full max-w-md mx-auto shadow-xl">
      <CardHeader className="space-y-1 text-center">
        <div className="size-12 rounded-xl gradient-bg flex items-center justify-center mx-auto mb-2 glow">
          {success ? <CheckCircle2 className="size-6 text-white" /> : <LogIn className="size-6 text-white" />}
        </div>
        <CardTitle className="text-2xl">ورود به حساب</CardTitle>
        <CardDescription>
          {success ? 'با موفقیت وارد شدید! در حال انتقال...' : 'برای ادامه وارد حساب کاربری خود شوید'}
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
              <AlertCircle className="size-4 shrink-0" />
              {error}
            </div>
          )}
          <div className="space-y-2">
            <Label htmlFor="email">ایمیل</Label>
            <div className="relative">
              <Mail className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                id="email"
                name="email"
                type="email"
                required
                placeholder="email@example.com"
                className="pr-10"
                dir="ltr"
                disabled={loading || success}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">رمز عبور</Label>
            <div className="relative">
              <Lock className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                id="password"
                name="password"
                type="password"
                required
                placeholder="••••••••"
                className="pr-10"
                dir="ltr"
                disabled={loading || success}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col gap-3">
          <Button type="submit" className="w-full" disabled={loading || success}>
            {loading || success ? (
              <>
                <Loader2 className="size-4 ml-2 animate-spin" />
                {success ? 'در حال انتقال...' : 'در حال ورود...'}
              </>
            ) : (
              'ورود'
            )}
          </Button>
          <p className="text-sm text-muted-foreground text-center">
            حساب ندارید؟{' '}
            <Link href="/register" className="text-primary hover:underline font-medium">
              ثبت‌نام کنید
            </Link>
          </p>
          {success && (
            <a href="/" className="text-sm text-primary hover:underline mt-2 text-center">
              اگر منتقل نشدید، اینجا کلیک کنید
            </a>
          )}
        </CardFooter>
      </form>
    </Card>
  )
}

export function RegisterForm() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)

  const handleSubmit = useCallback(async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    const formData = new FormData(e.currentTarget)
    const email = String(formData.get('email') || '').trim()
    const username = String(formData.get('username') || '').trim()
    const password = String(formData.get('password') || '')
    const name = String(formData.get('name') || '').trim()

    if (!email || !username || !password) {
      setError('ایمیل، نام کاربری و رمز عبور الزامی هستند')
      setLoading(false)
      return
    }

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, username, password, name }),
        credentials: 'include',
      })
      const data = await res.json()

      if (data.success) {
        // ذخیره توکن در localStorage و cookie برای fallback
        if (data.token) {
          saveToken(data.token)
        }
        toast.success('ثبت‌نام موفقیت‌آمیز بود! خوش آمدید')
        setSuccess(true)
        setTimeout(() => {
          window.location.href = '/'
        }, 800)
      } else {
        setError(data.error || 'خطا در ثبت‌نام')
        setLoading(false)
      }
    } catch (err) {
      setError('خطا در ارتباط با سرور: ' + (err instanceof Error ? err.message : ''))
      setLoading(false)
    }
  }, [])

  return (
    <Card className="w-full max-w-md mx-auto shadow-xl">
      <CardHeader className="space-y-1 text-center">
        <div className="size-12 rounded-xl gradient-bg flex items-center justify-center mx-auto mb-2 glow">
          {success ? <CheckCircle2 className="size-6 text-white" /> : <UserPlus className="size-6 text-white" />}
        </div>
        <CardTitle className="text-2xl">ساخت حساب جدید</CardTitle>
        <CardDescription>
          {success ? 'ثبت‌نام موفقیت‌آمیز بود! در حال انتقال...' : 'برای استفاده از امکانات سایت ثبت‌نام کنید'}
        </CardDescription>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="space-y-4">
          {error && (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
              <AlertCircle className="size-4 shrink-0" />
              {error}
            </div>
          )}
          <div className="space-y-2">
            <Label htmlFor="name">نام نمایشی (اختیاری)</Label>
            <div className="relative">
              <User className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                id="name"
                name="name"
                type="text"
                placeholder="نام شما"
                className="pr-10"
                disabled={loading || success}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="username">نام کاربری</Label>
            <div className="relative">
              <User className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                id="username"
                name="username"
                type="text"
                required
                placeholder="username"
                className="pr-10"
                dir="ltr"
                disabled={loading || success}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">ایمیل</Label>
            <div className="relative">
              <Mail className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                id="email"
                name="email"
                type="email"
                required
                placeholder="email@example.com"
                className="pr-10"
                dir="ltr"
                disabled={loading || success}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">رمز عبور</Label>
            <div className="relative">
              <Lock className="absolute right-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                id="password"
                name="password"
                type="password"
                required
                minLength={6}
                placeholder="حداقل ۶ کاراکتر"
                className="pr-10"
                dir="ltr"
                disabled={loading || success}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex flex-col gap-3">
          <Button type="submit" className="w-full" disabled={loading || success}>
            {loading || success ? (
              <>
                <Loader2 className="size-4 ml-2 animate-spin" />
                {success ? 'در حال انتقال...' : 'در حال ثبت‌نام...'}
              </>
            ) : (
              'ثبت‌نام'
            )}
          </Button>
          <p className="text-sm text-muted-foreground text-center">
            قبلاً ثبت‌نام کرده‌اید؟{' '}
            <Link href="/login" className="text-primary hover:underline font-medium">
              وارد شوید
            </Link>
          </p>
          {success && (
            <a href="/" className="text-sm text-primary hover:underline mt-2 text-center">
              اگر منتقل نشدید، اینجا کلیک کنید
            </a>
          )}
        </CardFooter>
      </form>
    </Card>
  )
}
