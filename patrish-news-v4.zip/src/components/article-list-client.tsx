'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { ArticleCard } from '@/components/article-card'
import { Loader2, RefreshCw } from 'lucide-react'
import { toast } from 'sonner'
import type { ArticleWithRelations } from '@/lib/types'

interface ArticleListClientProps {
  categorySlug?: string
  tagSlug?: string
  searchQuery?: string
  initialCount: number
  sortBy?: 'publishedAt' | 'views' | 'likes'
}

export function ArticleListClient({
  categorySlug,
  tagSlug,
  searchQuery,
  initialCount,
  sortBy = 'publishedAt',
}: ArticleListClientProps) {
  const [articles, setArticles] = useState<ArticleWithRelations[]>([])
  const [loading, setLoading] = useState(false)
  const [page, setPage] = useState(2)
  const [hasMore, setHasMore] = useState(true)

  const loadMore = async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      params.set('page', String(page))
      params.set('limit', '12')
      params.set('sortBy', sortBy)
      if (categorySlug) params.set('category', categorySlug)
      if (tagSlug) params.set('tag', tagSlug)
      if (searchQuery) params.set('search', searchQuery)

      const res = await fetch(`/api/articles?${params.toString()}`)
      const data = await res.json()

      if (data.success) {
        setArticles(prev => [...prev, ...data.data])
        setPage(prev => prev + 1)
        setHasMore(page < data.pagination.totalPages)
      } else {
        toast.error('خطا در بارگذاری')
      }
    } catch {
      toast.error('خطا در ارتباط')
    } finally {
      setLoading(false)
    }
  }

  if (articles.length === 0 && !hasMore) return null

  return (
    <div className="space-y-6">
      {articles.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {articles.map(article => (
            <ArticleCard key={article.id} article={article} showCategory={!categorySlug} />
          ))}
        </div>
      )}
      {hasMore && (
        <div className="flex justify-center pt-4">
          <Button onClick={loadMore} disabled={loading} variant="outline" size="lg">
            {loading ? (
              <><Loader2 className="size-4 animate-spin ml-2" /> در حال بارگذاری...</>
            ) : (
              <><RefreshCw className="size-4 ml-2" /> بارگذاری بیشتر</>
            )}
          </Button>
        </div>
      )}
    </div>
  )
}
