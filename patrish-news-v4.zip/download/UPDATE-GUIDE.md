# 🔄 راهنمای آپدیت امن سایت (بدون از دست دادن داده‌ها)

## ⚠️ مشکل

وقتی سایت رو آپدیت می‌کنید، اگر مراحل درست انجام نشه، **همه اخبار، کاربران و رمزهای عبور از بین می‌روند**.

## ✅ راه‌حل‌ها

### راه‌حل ۱: PostgreSQL (توصیه‌شده) ⭐

بهترین راه‌حل اینه که از PostgreSQL استفاده کنید. داده‌ها در یک سرور جداگانه ذخیره می‌شن و با آپدیت کد، هیچ داده‌ای از بین نمی‌ره.

**مراحل:**

۱. در [Supabase](https://supabase.com) یا [Neon](https://neon.tech) ثبت‌نام کنید (رایگان)

۲. یک پروژه بسازید و connection string بگیرید:
```
postgresql://user:password@host:5432/dbname
```

۳. در فایل `prisma/schema.prisma`:
```prisma
datasource db {
  provider = "postgresql"  // به‌جای sqlite
  url      = env("DATABASE_URL")
}
```

۴. در فایل `.env`:
```env
DATABASE_URL="postgresql://user:password@host:5432/dbname"
```

۵. دیتابیس رو بسازید:
```bash
bun run db:push
```

۶. سوپر ادمین رو بسازید:
```bash
bun run scripts/seed.ts
```

**مزایا:**
- ✅ داده‌ها با آپدیت از بین نمی‌رن
- ✅ پشتیبانی از حجم بالای داده
- ✅ بک‌آپ خودکار (در Supabase/Neon)
- ✅ رایگان تا ۵۰۰MB

---

### راه‌حل ۲: بک‌آپ از SQLite قبل از آپدیت

اگه می‌خواهید SQLite رو نگه دارید:

```bash
# قبل از آپدیت:
bash scripts/backup.sh

# آپدیت کد (فقط فایل‌های کد رو آپلود کنید)
# فایل db/custom.db رو دست نزنید!

# آپدیت وابستگی‌ها و build:
bun install
bun run db:push  # داده‌ها رو حذف نمی‌کنه
bun run build

# restart سرور
bun run start
```

---

### راه‌حل ۳: اسکریپت آپدیت امن

یک اسکریپت آماده ساختم که همه کارها رو خودکار انجام می‌ده:

```bash
bash scripts/safe-update.sh
```

این اسکریپت:
۱. خودکار بک‌آپ می‌گیره
۲. وابستگی‌ها رو آپدیت می‌کنه
۳. دیتابیس رو آپدیت می‌کنه (بدون حذف داده‌ها)
۴. پروژه رو build می‌کنه
۵. سرور رو restart می‌کنه

---

## 📋 مراحل آپدیت امن قدم به قدم

### قبل از آپدیت:

```bash
# ۱. بک‌آپ بگیرید
bash scripts/backup.sh

# ۲. بک‌آپ رو در جای امنی دانلود کنید
# فایل: backups/backup_YYYYMMDD_HHMMSS.db.gz
```

### حین آپدیت:

```bash
# ۳. فایل‌های کد جدید رو آپلود کنید
# ⚠️ فایل‌های زیر رو آپلود نکنید:
#   - db/custom.db
#   - public/uploads/
#   - .env

# ۴. وابستگی‌ها رو نصب کنید
bun install

# ۵. دیتابیس رو آپدیت کنید (بدون حذف داده‌ها)
bun run db:push

# ۶. پروژه رو build کنید
bun run build

# ۷. سرور رو restart کنید
bun run start
# یا با PM2:
pm2 restart patrish-news
```

### بعد از آپدیت:

```bash
# ۸. تست کنید که داده‌ها موجود هستند
# - وارد سایت شوید
# - اخبار رو بررسی کنید
# - کاربران رو بررسی کنید

# ۹. اگر مشکلی بود:
# بک‌آپ رو بازگردانید:
gunzip backups/backup_YYYYMMDD_HHMMSS.db.gz
cp backups/backup_YYYYMMDD_HHMMSS.db db/custom.db
bun run start
```

---

## ⚠️ نکات مهم

### ❌ هرگز این کارها رو نکنید:

1. **فایل `db/custom.db` رو حذف نکنید**
2. **`prisma migrate reset` نزنید** (داده‌ها رو حذف می‌کنه)
3. **فایل `.env` رو آپلود نکنید** (تنظیمات هاست فرق داره)
4. **پوشه `public/uploads/` رو حذف نکنید** (تصاویر آپلود شده)

### ✅ همیشه این کارها رو بکنید:

1. **قبل از آپدیت بک‌آپ بگیرید**
2. **بک‌آپ رو در جای امنی ذخیره کنید**
3. **بعد از آپدیت تست کنید**
4. **اگه schema تغییر کرده، `db:push` بزنید** (داده‌ها حذف نمی‌شن)

---

## 🔄 Migration از SQLite به PostgreSQL

اگه الان SQLite دارید و می‌خواهید به PostgreSQL منتقل کنید:

```bash
# ۱. دیتابیس PostgreSQL رو بسازید
# ۲. schema.prisma رو به postgresql تغییر دهید
# ۳. DATABASE_URL رو ست کنید
# ۴. دیتابیس رو بسازید
bun run db:push

# ۵. داده‌های SQLite رو به PostgreSQL منتقل کنید
# (اسکریپت migration در حال آماده‌سازی است)
```

---

## 📞 پشتیبانی

اگه مشکلی پیش اومد:
1. بک‌آپ رو بازگردانید
2. نسخه قبلی کد رو آپلود کنید
3. سرور رو restart کنید
