# 🚀 راهنمای بارگذاری پاتریش نیوز روی هاست

## 📋 پیش‌نیازها

- Node.js 18+ یا Bun
- هاست با پشتیبانی Node.js (یا VPS)
- دامنه (اختیاری)

## 📦 فایل‌های مورد نیاز برای بارگذاری

تمام فایل‌های پروژه به‌جز موارد زیر:

```
❌ node_modules/          (نصب مجدد needed)
❌ .next/                 (build مجدد needed)
❌ db/                    (دیتابیس محلی)
❌ .env                   (باید جدید ساخته شود)
❌ upload/                (فایل‌های آپلود موقت)
❌ scripts/               (اسکریپت‌های توسعه)
❌ .zscripts/             (اسکریپت‌های sandbox)
❌ examples/              (فایل‌های نمونه)
```

## 🔧 مراحل نصب

### ۱. آماده‌سازی فایل‌ها

تمام فایل‌های پروژه (به‌جز موارد بالا) رو روی هاست آپلود کنید.

### ۲. تنظیم متغیرهای محیط

فایل `.env` در ریشه پروژه بسازید:

```env
DATABASE_URL="file:./production.db"
NEXT_PUBLIC_BASE_URL="https://yourdomain.com"
NODE_ENV="production"
```

### ۳. نصب وابستگی‌ها

```bash
bun install
# یا
npm install
```

### ۴. تنظیم دیتابیس

```bash
bun run db:push
# یا
npx prisma db push
```

### ۵. ساخت پروژه

```bash
bun run build
# یا
npm run build
```

### ۶. اجرای پروژه

```bash
bun run start
# یا
npm run start
```

پروژه روی پورت ۳۰۰۰ اجرا می‌شود.

### ۷. ایجاد سوپر ادمین

اولین کاربری که ثبت‌نام می‌کند، خودکار سوپر ادمین می‌شود.

یا می‌توانید از اسکریپت seed استفاده کنید:

```bash
bun run scripts/seed.ts
```

**ورود پیش‌فرض:**
- ایمیل: `admin@news24.ir`
- رمز: `admin123`

⚠️ **مهم:** پس از اولین ورود، رمز عبور را تغییر کنید!

## 🔄 با Nginx (Reverse Proxy)

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 🔄 با PM2 (Process Manager)

```bash
npm install -g pm2
pm2 start npm --name "patrish-news" -- start
pm2 startup
pm2 save
```

## 🔄 با Docker

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npx prisma generate
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

## 📁 ساختار پروژه

```
patrish-news/
├── src/
│   ├── app/                 # صفحات و API routes
│   │   ├── page.tsx         # صفحه اصلی
│   │   ├── article/[slug]/  # صفحه خبر
│   │   ├── category/[slug]/ # صفحه دسته‌بندی
│   │   ├── admin/           # پنل مدیریت
│   │   ├── api/             # API routes
│   │   ├── about/           # درباره ما
│   │   ├── contact/         # تماس با ما
│   │   ├── login/           # ورود
│   │   └── register/        # ثبت‌نام
│   ├── components/          # کامپوننت‌ها
│   ├── lib/                 # توابع کمکی
│   └── hooks/               # React hooks
├── prisma/
│   └── schema.prisma        # اسکیمای دیتابیس
├── public/                  # فایل‌های استاتیک
│   ├── logo.svg
│   ├── manifest.json
│   ├── sw.js
│   └── uploads/             # تصاویر آپلود شده
├── package.json
├── next.config.ts
├── tailwind.config.ts
├── tsconfig.json
└── .env
```

## ⚙️ تنظیمات پس از نصب

۱. وارد پنل مدیریت شوید (`/admin`)
۲. به تنظیمات سایت بروید (`/admin/settings`)
۳. نام سایت، ایمیل تماس و شبکه‌های اجتماعی را تنظیم کنید
۴. دسته‌بندی‌ها را بررسی/ویرایش کنید (`/admin/categories`)
۵. اولین خبر را بسازید (`/admin/articles/new`)

## 🛡️ نکات امنیتی

- رمز عبور سوپر ادمین را تغییر دهید
- `NODE_ENV=production` را تنظیم کنید
- HTTPS را فعال کنید
- فایروال را تنظیم کنید
- بک‌آپ منظم از دیتابیس بگیرید

## 📊 آمار سیستم

- **فریم‌ورک:** Next.js 16 با App Router
- **زبان:** TypeScript
- **دیتابیس:** Prisma ORM + SQLite (قابل تغییر به PostgreSQL)
- **استایل:** Tailwind CSS 4 + shadcn/ui
- **فونت:** Vazirmatn (فارسی)
- **PWA:** پشتیبانی می‌شود
- **SEO:** sitemap.xml + robots.txt + Schema.org
