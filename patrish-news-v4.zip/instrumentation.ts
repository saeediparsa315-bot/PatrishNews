/**
 * این فایل توسط Next.js در زمان startup سرور اجرا می‌شود
 * فقط schema دیتابیس رو اعمال می‌کنه (نه ساخت ادمین)
 */

export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    try {
      const { ensureSchema } = await import('./src/lib/db')
      await ensureSchema()
      console.log('[Startup] Schema دیتابیس اعمال شد')
    } catch (e) {
      console.error('[Startup] خطا در اعمال schema:', (e as Error).message?.substring(0, 200))
      // ادامه می‌دیم چون ensureSchema در اولین request هم اجرا می‌شه
    }
  }
}
