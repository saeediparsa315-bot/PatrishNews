import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",

  // مهم: build errors نباید ignore بشن
  // قبلاً ignoreBuildErrors: true بود که خطاهای واقعی رو پنهان می‌کرد
  typescript: {
    ignoreBuildErrors: false,
  },

  reactStrictMode: false,

  images: {
    remotePatterns: [
      { protocol: "https", hostname: "**" },
      { protocol: "http", hostname: "**" },
    ],
    unoptimized: true,
  },

  // افزایش body size برای آپلود تصاویر
  experimental: {
    serverActions: {
      bodySizeLimit: '15mb',
    },
  },

  async headers() {
    return [
      {
        source: '/api/:path*',
        headers: [
          { key: 'Cache-Control', value: 'no-store, no-cache, must-revalidate' },
        ],
      },
      {
        source: '/api/files/:path*',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' },
        ],
      },
    ]
  },
};

export default nextConfig;
