/**
 * اسکریپت راه‌اندازی اولیه دیتابیس - v4
 *
 * این اسکریپت:
 * 1. پوشه db و uploads رو می‌سازه
 * 2. permission‌ها رو درست می‌کنه (chmod 777)
 * 3. owner رو درست می‌کنه (chown به user فعلی)
 * 4. DATABASE_URL رو ست می‌کنه
 * 5. prisma generate و db push رو اجرا می‌کنه
 * 6. ادمین پیش‌فرض رو می‌سازه
 *
 * استفاده:
 *   node scripts/setup.js
 */

const { execSync } = require('child_process')
const { mkdirSync, existsSync, writeFileSync, unlinkSync, chmodSync, chownSync, statSync } = require('fs')
const { join } = require('path')
const { createHash } = require('crypto')

const cwd = process.cwd()
const dbDir = join(cwd, 'db')
const dbFile = join(dbDir, 'production.db')
const uploadsDir = join(cwd, 'uploads')

console.log('=== راه‌اندازی اولیه پاتریش نیوز v4 ===\n')

// 1. ساخت پوشه‌ها با permission درست
console.log('۱. ساخت پوشه‌های db و uploads...')
try {
  if (!existsSync(dbDir)) mkdirSync(dbDir, { recursive: true })
  if (!existsSync(uploadsDir)) mkdirSync(uploadsDir, { recursive: true })

  // chmod 777 برای اطمینان از قابل نوشتن بودن
  try { chmodSync(dbDir, 0o777) } catch (e) { console.warn('   ⚠️ chmod db ناموفق:', e.message) }
  try { chmodSync(uploadsDir, 0o777) } catch (e) { console.warn('   ⚠️ chmod uploads ناموفق:', e.message) }

  // chown به user فعلی
  const uid = process.getuid?.()
  const gid = process.getgid?.()
  if (uid && gid) {
    try {
      chownSync(dbDir, uid, gid)
      chownSync(uploadsDir, uid, gid)
    } catch (e) {
      // شاید root نباشیم - مشکلی نیست
    }
  }

  // تست قابل نوشتن بودن
  const testFile = join(dbDir, '.write_test')
  writeFileSync(testFile, 'test')
  unlinkSync(testFile)
  console.log('   ✅ پوشه‌ها ساخته شدند و قابل نوشتن هستند')
  console.log('   ℹ️ مسیر db:', dbDir)
  console.log('   ℹ️ مسیر uploads:', uploadsDir)
} catch (e) {
  console.error('   ❌ خطا در ساخت/permission پوشه‌ها:', e.message)
  console.error('   💡 دستورات پیشنهادی:')
  console.error('      sudo mkdir -p db uploads')
  console.error('      sudo chmod -R 777 db uploads')
  console.error('      sudo chown -R $(whoami) db uploads')
  process.exit(1)
}

// 2. تنظیم DATABASE_URL
process.env.DATABASE_URL = `file:${dbFile}`
console.log('   ✅ DATABASE_URL:', process.env.DATABASE_URL)

// 3. prisma generate
console.log('\n۲. اجرای prisma generate...')
try {
  execSync('npx prisma generate', { stdio: 'inherit', cwd, env: process.env })
  console.log('   ✅ Prisma Client ساخته شد')
} catch (e) {
  console.error('   ❌ خطا در prisma generate')
  process.exit(1)
}

// 4. prisma db push (ساخت table‌ها)
console.log('\n۳. اعمال schema به دیتابیس...')
try {
  execSync('npx prisma db push --accept-data-loss', { stdio: 'inherit', cwd, env: process.env })
  console.log('   ✅ Table‌ها ساخته شدند')
} catch (e) {
  console.error('   ❌ خطا در prisma db push')
  console.error('   💡 ممکنه مشکل permission باشه. اجرا کنید:')
  console.error('      sudo chown -R $(whoami) db')
  console.error('      sudo chmod -R 777 db')
  process.exit(1)
}

// 5. chmod روی فایل دیتابیس
try {
  if (existsSync(dbFile)) {
    chmodSync(dbFile, 0o666)
    console.log('   ✅ Permission فایل دیتابیس تنظیم شد (666)')
  }
} catch (e) {
  console.warn('   ⚠️ chmod فایل db ناموفق:', e.message)
}

// 6. ساخت ادمین پیش‌فرض
console.log('\n۴. ساخت سوپر ادمین پیش‌فرض...')
try {
  const { PrismaClient } = require('@prisma/client')
  const prisma = new PrismaClient()

  const adminEmail = 'admin@news24.ir'
  const adminPassword = 'admin123'

  const existing = await prisma.user.findUnique({ where: { email: adminEmail } })
  if (existing) {
    console.log(`   ℹ️ ادمین از قبل وجود دارد: ${adminEmail}`)
    // اگه موجود ولی نقش نداره، درست کن
    if (existing.role !== 'SUPER_ADMIN') {
      await prisma.user.update({
        where: { id: existing.id },
        data: { role: 'SUPER_ADMIN', isBlocked: false },
      })
      console.log('   ✅ نقش ادمین درست شد')
    }
    // ریست رمز برای اطمینان
    const hash = createHash('sha256').update(adminPassword + 'news_salt_2024').digest('hex')
    await prisma.user.update({
      where: { email: adminEmail },
      data: { passwordHash: hash },
    })
    console.log(`   ✅ رمز ادمین ریست شد: ${adminPassword}`)
  } else {
    const hash = createHash('sha256').update(adminPassword + 'news_salt_2024').digest('hex')
    await prisma.user.create({
      data: {
        email: adminEmail,
        username: 'superadmin',
        passwordHash: hash,
        name: 'مدیر کل',
        role: 'SUPER_ADMIN',
      },
    })
    console.log(`   ✅ سوپر ادمین ساخته شد: ${adminEmail} / ${adminPassword}`)
  }

  await prisma.$disconnect()
} catch (e) {
  console.error('   ❌ خطا در ساخت ادمین:', e.message)
}

// 7. تست write واقعی
console.log('\n۵. تست write دیتابیس...')
try {
  const { PrismaClient } = require('@prisma/client')
  const prisma = new PrismaClient()

  const testUser = await prisma.user.findFirst()
  if (testUser) {
    await prisma.auditLog.create({
      data: {
        userId: testUser.id,
        action: 'SETUP_TEST',
        entity: 'SYSTEM',
      },
    })
    await prisma.auditLog.deleteMany({ where: { action: 'SETUP_TEST' } })
    console.log('   ✅ Write دیتابیس کار می‌کنه')
  } else {
    console.log('   ⚠️ کاربری برای تست وجود ندارد')
  }

  await prisma.$disconnect()
} catch (e) {
  console.error('   ❌ Write دیتابیس خطا داد:', e.message)
  if (e.message.includes('readonly') || e.message.includes('read-only')) {
    console.error('   💡 دیتابیس readonly است! اجرا کنید:')
    console.error('      chmod -R 777 db')
    console.error('      chown -R $(whoami) db')
  }
  process.exit(1)
}

console.log('\n=== راه‌اندازی کامل شد! ===')
console.log('\nبرای اجرای پروژه:')
console.log('  npm run build')
console.log('  NODE_ENV=production npm start')
console.log('\nسپس با این اطلاعات وارد شوید:')
console.log('  ایمیل: admin@news24.ir')
console.log('  رمز: admin123')
console.log('\nبعد از deploy، این URL‌ها رو چک کنید:')
console.log('  /api/diagnose - دیاگنوستیک کامل')
console.log('  /api/health - وضعیت کلی')
