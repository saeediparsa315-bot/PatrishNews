import { db } from '@/lib/db'
import { DEFAULT_SETTINGS } from '@/lib/settings'

async function updateSettings() {
  console.log('🔄 Updating settings to "پاتریش نیوز"...')
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    const existing = await db.siteSetting.findUnique({ where: { key } })
    if (existing) {
      await db.siteSetting.update({ where: { key }, data: { value } })
      console.log(`  ✓ Updated: ${key}`)
    } else {
      await db.siteSetting.create({ data: { key, value } })
      console.log(`  ✓ Created: ${key}`)
    }
  }
  console.log('✅ Settings updated successfully')
  await db.$disconnect()
}

updateSettings().catch(e => {
  console.error(e)
  process.exit(1)
})
