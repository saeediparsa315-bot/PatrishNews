#!/bin/bash
# اسکریپت بک‌آپ‌گیری از دیتابیس قبل از آپدیت
# استفاده: bash scripts/backup.sh

set -e

echo "🔄 شروع بک‌آپ‌گیری..."

# ایجاد پوشه بک‌آپ
BACKUP_DIR="backups"
mkdir -p "$BACKUP_DIR"

# نام فایل بک‌آپ با تاریخ
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_DIR/backup_$TIMESTAMP.db"

# بررسی وجود دیتابیس
if [ -f "db/production.db" ]; then
    # کپی دیتابیس
    cp db/production.db "$BACKUP_FILE"
    echo "✅ بک‌آپ ایجاد شد: $BACKUP_FILE"

    # فشرده‌سازی
    gzip "$BACKUP_FILE"
    echo "✅ فشرده‌سازی شد: $BACKUP_FILE.gz"

    # نگه‌داشتن فقط ۱۰ بک‌آپ آخر
    ls -t "$BACKUP_DIR"/backup_*.db.gz 2>/dev/null | tail -n +11 | xargs rm -f 2>/dev/null || true

    echo ""
    echo "📊 بک‌آپ‌های موجود:"
    ls -lh "$BACKUP_DIR"/backup_*.db.gz 2>/dev/null | head -10

    echo ""
    echo "✅ بک‌آپ‌گیری کامل شد!"
    echo "⚠️ حالا می‌توانید با خیال راحت آپدیت کنید"
else
    echo "⚠️ فایل دیتابیس پیدا نشد: db/production.db"
    echo "⚠️ اگر از PostgreSQL استفاده می‌کنید، از pg_dump استفاده کنید"
fi
