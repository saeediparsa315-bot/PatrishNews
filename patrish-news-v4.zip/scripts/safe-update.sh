#!/bin/bash
# اسکریپت آپدیت امن سایت (بدون از دست دادن داده‌ها)
# استفاده: bash scripts/safe-update.sh

set -e

echo "🚀 شروع آپدیت امن سایت..."
echo ""

# مرحله ۱: بک‌آپ‌گیری
echo "📋 مرحله ۱: بک‌آپ‌گیری از دیتابیس..."
bash scripts/backup.sh
echo ""

# مرحله ۲: آپدیت وابستگی‌ها
echo "📦 مرحله ۲: آپدیت وابستگی‌ها..."
bun install
echo "✅ وابستگی‌ها نصب شدند"
echo ""

# مرحله ۳: آپدیت دیتابیس (بدون حذف داده‌ها)
echo "🗄️ مرحله ۳: آپدیت schema دیتابیس..."
echo "⚠️ این عمل داده‌ها را حذف نمی‌کند، فقط ساختار را آپدیت می‌کند"
bun run db:push
echo "✅ دیتابیس آپدیت شد"
echo ""

# مرحله ۴: build پروژه
echo "🏗️ مرحله ۴: ساخت پروژه..."
bun run build
echo "✅ پروژه ساخته شد"
echo ""

# مرحله ۵: restart سرور
echo "🔄 مرحله ۵: راه‌اندازی مجدد سرور..."
if command -v pm2 &> /dev/null; then
    pm2 restart patrish-news
    echo "✅ سرور با PM2 راه‌اندازی مجدد شد"
else
    echo "⚠️ برای راه‌اندازی مجدد، سرور را restart کنید"
    echo "   bun run start"
fi
echo ""

echo "🎉 آپدیت با موفقیت کامل شد!"
echo "📊 داده‌ها حفظ شدند ✅"
echo ""
echo "⚠️ اگر مشکلی پیش آمد، بک‌آپ در پوشه backups/ موجود است"
