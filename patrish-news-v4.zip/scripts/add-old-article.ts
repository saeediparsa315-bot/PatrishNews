import { db } from '@/lib/db'
import { slugify } from '@/lib/persian'

async function addOldArticle() {
  console.log('📝 Adding old article (48 hours ago)...')

  const superAdmin = await db.user.findFirst({ where: { role: 'SUPER_ADMIN' } })
  if (!superAdmin) {
    console.log('No super admin found')
    return
  }

  const category = await db.category.findUnique({ where: { slug: 'technology' } })
  if (!category) {
    console.log('Category not found')
    return
  }

  // خبری که ۴۸ ساعت پیش منتشر شده (باید از صفحه اصلی خارج شده باشد)
  const oldDate = new Date(Date.now() - 48 * 60 * 60 * 1000)

  const article = await db.article.create({
    data: {
      title: 'خبر قدیمی تست - باید از صفحه اصلی خارج شده باشد',
      slug: slugify('خبر قدیمی تست') + '-' + Math.random().toString(36).substring(2, 6),
      excerpt: 'این خبر ۴۸ ساعت پیش منتشر شده و نباید در صفحه اصلی نمایش داده شود',
      content: '<p>این خبر برای تست منطق ۲۴ ساعت ساخته شده است.</p>',
      coverImage: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=1200',
      categoryId: category.id,
      authorId: superAdmin.id,
      status: 'PUBLISHED',
      isFeatured: true,
      isBreaking: false,
      isHomepage: true,
      isMainHeadline: false,
      readingTime: 1,
      viewCount: 0,
      likeCount: 0,
      commentCount: 0,
      publishedAt: oldDate,
    },
  })

  console.log(`✓ Created old article: ${article.title}`)
  console.log(`  Published at: ${oldDate.toISOString()}`)
  console.log('✅ This article should NOT appear on homepage (24h expired)')
  console.log('✅ But SHOULD appear in /category/technology')
  await db.$disconnect()
}

addOldArticle().catch(e => {
  console.error(e)
  process.exit(1)
})
