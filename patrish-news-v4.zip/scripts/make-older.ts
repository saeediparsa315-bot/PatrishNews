import { db } from '@/lib/db'

async function makeOlder() {
  const oldArticle = await db.article.findFirst({
    where: { title: { contains: 'خبر قدیمی تست' } },
  })

  if (!oldArticle) {
    console.log('Old article not found')
    return
  }

  // ۵ روز پیش
  const fiveDaysAgo = new Date(Date.now() - 5 * 24 * 60 * 60 * 1000)

  await db.article.update({
    where: { id: oldArticle.id },
    data: { publishedAt: fiveDaysAgo },
  })

  console.log(`✓ Updated article publishedAt to 5 days ago: ${fiveDaysAgo.toISOString()}`)
  await db.$disconnect()
}

makeOlder().catch(e => {
  console.error(e)
  process.exit(1)
})
