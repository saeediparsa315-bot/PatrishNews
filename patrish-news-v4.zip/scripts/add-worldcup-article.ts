import { db } from '@/lib/db'
import { hashPassword } from '@/lib/auth'
import { slugify } from '@/lib/persian'
import { DEFAULT_SETTINGS, ensureDefaultSettings } from '@/lib/settings'

const worldCup2026Article = {
  title: 'داغ‌ترین‌های جام جهانی ۲۰۲۶؛ برزیل مقتدر، هائیتی اولین اخراجی جام!',
  excerpt: 'برزیل با درخشش متئوس کونیا و وینیسیوس جونیور هائیتی را ۳ بر صفر در هم کوبید. مراکش با تک گل صیباری اسکاتلند را زمین‌گیر کرد و صدرنشین گروه C شد.',
  content: `<p>در ادامه رقابت‌های جام جهانی ۲۰۲۶، شنبه ۳۰ خرداد ۱۴۰۵ (۲۰ ژوئن ۲۰۲۶) دو بازی حساس در گروه C برگزار شد که نتایج آن‌ها وضعیت جدول را به شکل چشمگیری تغییر داد.</p>

<h2>🇧🇷 برزیل ۳ - ۰ هائیتی | گروه C</h2>

<p>سامباها برگشتند! برزیل که پس از تساوی ناامیدکننده بازی اول زیر فشار شدید انتقادات بود، امروز با ارائه‌ یک بازی هجومی و درخشش <strong>متئوس کونیا</strong> (با ۲ گل) و <strong>وینیسیوس جونیور</strong>، هائیتی را ۳ بر صفر در هم کوبید تا شانس صعود خود را به شکل چشمگیری افزایش دهد.</p>

<p>این برد اولین پیروزی قاطع برزیل در این جام جهانی محسوب می‌شود و به بازیکنان این تیم اعتماد به نفس زیادی بخشید. کونیا که در بازی اول نیز عملکرد قابل قبولی داشت، امروز با دو گل زیبا خود را به عنوان ستاره اصلی خط حمله برزیل تثبیت کرد.</p>

<h2>🇲🇦 مراکش ۱ - ۰ اسکاتلند | گروه C</h2>

<p>شگفتی‌سازی <strong>شیرهای اطلس</strong> ادامه دارد! مراکش با تک گل فوق‌العاده <strong>اسماعیل صیباری</strong> در همان دقیقه ۲ بازی، اسکاتلند را زمین‌گیر کرد. این گل تا اینجای کار به عنوان <em>سریع‌ترین گل جام جهانی ۲۰۲۶</em> ثبت شده است.</p>

<blockquote>مراکشی‌ها با این برد ۴ امتیازی شدند و به صدر جدول گروه C تکیه زدند.</blockquote>

<p>صیباری که از بازیکنان جوان و آینده‌دار مراکش محسوب می‌شود، با این گل تاریخ‌ساز خود نامش را در فهرست ستاران جام جهانی ۲۰۲۶ ثبت کرد. تیم مراکش که در جام جهانی ۲۰۲۲ قطر به نیمه‌نهایی رسیده بود، نشان داد که همچنان یکی از قدرت‌های فوتبال جهان است.</p>

<h2>⚠️ وداع تلخ هائیتی با جام</h2>

<p>تیم هائیتی با این شکست سوم، رسماً به اولین تیم حذف شده از جام جهانی ۲۰۲۶ تبدیل شد. بازیکنان این تیم پس از پایان بازی بسیار ناراحت بودند و سرمربی هائیتی در نشست خبری پس از بازی گفت:</p>

<blockquote>ما برای این جام جهانی بسیار تلاش کردیم اما سطح حریفان ما بسیار بالاتر بود. این تجربه برای بازیکنان جوانمان ارزشمند خواهد بود.</blockquote>

<h2>جدول گروه C پس از این نتایج</h2>

<ol>
<li>مراکش - ۴ امتیاز</li>
<li>برزیل - ۴ امتیاز</li>
<li>اسکاتلند - ۱ امتیاز</li>
<li>هائیتی - ۰ امتیاز (حذف شده)</li>
</ol>

<p>هفته آینده بازی‌های تعیین‌کننده‌ای در گروه C برگزار خواهد شد. برزیل و مراکش با تساوی یا برد در بازی‌های پایانی، صعود خود را قطعی می‌کنند. اسکاتلند نیز باید در بازی آخر خود پیروز شود تا امیدوار به صعود باقی بماند.</p>`,
  coverImage: 'https://images.unsplash.com/photo-1551958219-acbc608c6377?w=1200',
  category: 'sports',
  isMainHeadline: true,
  isHomepage: true,
  isBreaking: true,
  isFeatured: true,
  readingTime: 4,
  tags: ['economy'],
}

async function addWorldCupArticle() {
  console.log('⚽ Adding World Cup 2026 article...')

  await ensureDefaultSettings()

  // Get super admin
  const superAdmin = await db.user.findFirst({ where: { role: 'SUPER_ADMIN' } })
  if (!superAdmin) {
    console.log('No super admin found')
    return
  }

  // Get sports category
  const category = await db.category.findUnique({ where: { slug: worldCup2026Article.category } })
  if (!category) {
    console.log('Sports category not found')
    return
  }

  // Check if article already exists
  const existing = await db.article.findFirst({
    where: { title: { contains: 'جام جهانی ۲۰۲۶' } },
  })
  if (existing) {
    console.log('Article already exists, skipping')
    return
  }

  // Reset all main headlines
  await db.article.updateMany({
    where: { isMainHeadline: true },
    data: { isMainHeadline: false },
  })

  // Create article
  const article = await db.article.create({
    data: {
      title: worldCup2026Article.title,
      slug: slugify(worldCup2026Article.title) + '-' + Math.random().toString(36).substring(2, 6),
      excerpt: worldCup2026Article.excerpt,
      content: worldCup2026Article.content,
      coverImage: worldCup2026Article.coverImage,
      categoryId: category.id,
      authorId: superAdmin.id,
      status: 'PUBLISHED',
      isFeatured: worldCup2026Article.isFeatured,
      isBreaking: worldCup2026Article.isBreaking,
      isHomepage: worldCup2026Article.isHomepage,
      isMainHeadline: worldCup2026Article.isMainHeadline,
      readingTime: worldCup2026Article.readingTime,
      viewCount: 0,
      likeCount: 0,
      commentCount: 0,
      publishedAt: new Date(),
      metaTitle: 'جام جهانی ۲۰۲۶: برزیل ۳-۰ هائیتی، مراکش ۱-۰ اسکاتلند',
      metaDescription: 'نتایج بازی‌های گروه C جام جهانی ۲۰۲۶: برزیل با ۳ گل هائیتی را در هم کوبید، مراکش با تک گل صیباری اسکاتلند را شکست داد.',
      metaKeywords: 'جام جهانی ۲۰۲۶,برزیل,هائیتی,مراکش,اسکاتلند,فوتبال,گروه C',
    },
  })

  console.log(`✓ Created article: ${article.title}`)
  console.log(`  Slug: ${article.slug}`)
  console.log('✅ Done')
  await db.$disconnect()
}

addWorldCupArticle().catch(e => {
  console.error(e)
  process.exit(1)
})
