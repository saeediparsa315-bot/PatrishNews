import { db } from '@/lib/db'
import { slugify } from '@/lib/persian'

async function fixArticles() {
  console.log('🔄 Updating articles with homepage/mainHeadline flags...')

  const articles = await db.article.findMany({
    where: { status: 'PUBLISHED' },
    orderBy: { publishedAt: 'desc' },
    take: 8,
  })

  if (articles.length === 0) {
    console.log('No published articles found')
    return
  }

  // اولین خبر را به عنوان mainHeadline (تیتر اصلی) تنظیم می‌کنیم
  await db.article.update({
    where: { id: articles[0].id },
    data: { isMainHeadline: true, isHomepage: true, isFeatured: true },
  })
  console.log(`✓ Set "${articles[0].title}" as MAIN HEADLINE`)

  // ۶ خبر بعدی را برای صفحه اصلی انتخاب می‌کنیم
  for (let i = 1; i < Math.min(7, articles.length); i++) {
    await db.article.update({
      where: { id: articles[i].id },
      data: { isHomepage: true },
    })
    console.log(`✓ Set "${articles[i].title}" for homepage`)
  }

  // ۲ خبر را به عنوان خبر فوری تنظیم می‌کنیم
  const breakingArticle1 = articles.find(a => a.isBreaking)
  if (!breakingArticle1) {
    await db.article.update({
      where: { id: articles[1].id },
      data: { isBreaking: true },
    })
    console.log(`✓ Set "${articles[1].title}" as BREAKING`)
  }

  console.log('✅ Done')
  await db.$disconnect()
}

fixArticles().catch(e => {
  console.error(e)
  process.exit(1)
})
