import { db } from '@/lib/db'

async function cleanupForProduction() {
  console.log('🧹 شروع پاک‌سازی برای آماده‌سازی تولید...')

  // 1. حذف تمام اخبار
  const articles = await db.article.count()
  console.log(`📰 ${articles} خبر برای حذف...`)
  await db.article.deleteMany({})
  console.log('✅ تمام اخبار حذف شدند')

  // 2. حذف تمام کامنت‌ها
  const comments = await db.comment.count()
  if (comments > 0) {
    await db.comment.deleteMany()
    console.log(`✅ ${comments} نظر حذف شد`)
  }

  // 3. حذف تمام لایک‌ها
  const likes = await db.like.count()
  if (likes > 0) {
    await db.like.deleteMany()
    console.log(`✅ ${likes} لایک حذف شد`)
  }

  // 4. حذف تمام بوک‌مارک‌ها
  const bookmarks = await db.bookmark.count()
  if (bookmarks > 0) {
    await db.bookmark.deleteMany()
    console.log(`✅ ${bookmarks} بوک‌مارک حذف شد`)
  }

  // 5. حذف تمام نشست‌ها
  await db.session.deleteMany()
  console.log('✅ نشست‌ها پاک‌سازی شدند')

  // 6. حذف لاگ‌ها
  await db.auditLog.deleteMany()
  console.log('✅ لاگ‌ها پاک‌سازی شدند')

  // 7. حذف کاربران عادی (فقط سوپر ادمین باقی بماند)
  const regularUsers = await db.user.findMany({ where: { role: { not: 'SUPER_ADMIN' } } })
  if (regularUsers.length > 0) {
    for (const user of regularUsers) {
      await db.user.delete({ where: { id: user.id } })
    }
    console.log(`✅ ${regularUsers.length} کاربر عادی حذف شد`)
  }

  // گزارش نهایی
  const finalCounts = {
    articles: await db.article.count(),
    users: await db.user.count(),
    categories: await db.category.count(),
    tags: await db.tag.count(),
    comments: await db.comment.count(),
    likes: await db.like.count(),
    bookmarks: await db.bookmark.count(),
  }
  console.log('\n📊 وضعیت نهایی:')
  console.log(JSON.stringify(finalCounts, null, 2))

  // لیست کاربران باقی‌مانده
  const remainingUsers = await db.user.findMany({ select: { email: true, username: true, name: true, role: true } })
  console.log('\n👥 کاربران باقی‌مانده:')
  remainingUsers.forEach(u => {
    console.log(`  ${u.role}: ${u.name} (@${u.username}) - ${u.email}`)
  })

  console.log('\n✅ پاک‌سازی کامل شد!')
  console.log('⚠️ آماده بارگذاری روی هاست')
  console.log('⚠️ ورود سوپر ادمین: admin@news24.ir / admin123')

  await db.$disconnect()
}

cleanupForProduction().catch(e => {
  console.error(e)
  process.exit(1)
})
