import { db } from '@/lib/db'
import { slugify } from '@/lib/persian'

async function addMoreArticles() {
  console.log('📝 Adding more articles for homepage...')

  const superAdmin = await db.user.findFirst({ where: { role: 'SUPER_ADMIN' } })
  if (!superAdmin) {
    console.log('No super admin found')
    return
  }

  const categories = await db.category.findMany()
  const catMap: Record<string, string> = {}
  categories.forEach(c => { catMap[c.slug] = c.id })

  const articles = [
    { title: 'واکسن جدید سرطان پوست با موفقیت ۹۰ درصدی در آزمایشات', category: 'science', excerpt: 'محققان موفق به توسعه واکسنی شدند که در آزمایشات بالینی ۹۰ درصد موثر بوده است.' },
    { title: 'موزila فایرفاکس ۱۲۰ با قابلیت‌های جدید حریم خصوصی', category: 'technology', excerpt: 'نسخه جدید مرورگر فایرفاکس با بهبودهای امنیتی و حریم خصوصی منتشر شد.' },
    { title: 'فیلم جدید کریستوفر نولان رکورد فروش را شکست', category: 'entertainment', excerpt: 'آخرین فیلم کریستوفر نولان در اولین هفته اکران رکورد فروش را شکست.' },
    { title: 'المپیک ۲۰۲۸ لس آنجلس: ورزش‌های جدید اضافه شد', category: 'sports', excerpt: 'کمیته بین‌المللی المپیک ورزش‌های جدیدی را به المپیک ۲۰۲۸ اضافه کرد.' },
    { title: 'اجلاس سران G7: توافق بر سر کاهش انتشار کربن', category: 'world', excerpt: 'سران کشورهای G7 بر سر کاهش ۵۰ درصدی انتشار کربن تا ۲۰۳۰ توافق کردند.' },
    { title: 'PlayStation 6: جزئیات سخت‌افزاری فاش شد', category: 'gaming', excerpt: 'جزئیات سخت‌افزاری کنسول جدید سونی فاش شد که انقلابی در صنعت بازی خواهد بود.' },
    { title: 'انتخابات پارلمانی بریتانیا: حزب کارگر پیروز شد', category: 'politics', excerpt: 'حزب کارگر در انتخابات پارلمانی بریتانیا با اکثریت آرا پیروز شد.' },
    { title: 'هوش مصنوعی گوگل می‌تواند تصاویر را به ویدیو تبدیل کند', category: 'technology', excerpt: 'گوگل ابزار جدیدی معرفی کرد که تصاویر ثابت را به ویدیوهای کوتاه تبدیل می‌کند.' },
    { title: 'کشف آب در مریخ: شواهد جدید علمی', category: 'science', excerpt: 'دانشمندان شواهد جدیدی از وجود آب مایع در مریخ کشف کردند.' },
    { title: 'جام جهانی ۲۰۲۶: افزایش تعداد تیم‌ها به ۴۸', category: 'sports', excerpt: 'فدراسیون بین‌المللی فوتبال تعداد تیم‌های حاضر در جام جهانی ۲۰۲۶ را به ۴۸ افزایش داد.' },
    { title: 'فیلم Avatar 3 تاریخ انتشار خود را اعلام کرد', category: 'entertainment', excerpt: 'جیمز کامرون تاریخ انتشار فیلم آواتار ۳ را اعلام کرد.' },
  ]

  for (const article of articles) {
    const catId = catMap[article.category]
    if (!catId) continue

    const existing = await db.article.findFirst({ where: { title: article.title } })
    if (existing) continue

    const publishedAt = new Date(Date.now() - Math.random() * 12 * 60 * 60 * 1000)

    await db.article.create({
      data: {
        title: article.title,
        slug: slugify(article.title) + '-' + Math.random().toString(36).substring(2, 6),
        excerpt: article.excerpt,
        content: `<p>${article.excerpt}</p><p>این خبر به‌صورت تستی اضافه شده است.</p>`,
        coverImage: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=1200',
        categoryId: catId,
        authorId: superAdmin.id,
        status: 'PUBLISHED',
        isFeatured: false,
        isBreaking: false,
        isHomepage: true,
        isMainHeadline: false,
        layoutMode: 'DEFAULT',
        position: 0,
        readingTime: 2,
        viewCount: Math.floor(Math.random() * 100),
        likeCount: Math.floor(Math.random() * 20),
        commentCount: 0,
        publishedAt,
      },
    })
    console.log(`✓ Created: ${article.title}`)
  }

  console.log('✅ Done!')
  await db.$disconnect()
}

addMoreArticles().catch(e => {
  console.error(e)
  process.exit(1)
})
