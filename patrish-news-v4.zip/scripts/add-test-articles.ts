import { db } from '@/lib/db'
import { slugify } from '@/lib/persian'

async function addTestArticles() {
  console.log('📝 Adding test articles...')

  const superAdmin = await db.user.findFirst({ where: { role: 'SUPER_ADMIN' } })
  if (!superAdmin) {
    console.log('No super admin found')
    return
  }

  const categoryTech = await db.category.findUnique({ where: { slug: 'technology' } })
  const categoryGaming = await db.category.findUnique({ where: { slug: 'gaming' } })
  const categoryWorld = await db.category.findUnique({ where: { slug: 'world' } })

  if (!categoryTech || !categoryGaming || !categoryWorld) {
    console.log('Categories not found')
    return
  }

  const articles = [
    {
      title: 'رونمایی رسمی از iPhone 17 Pro با دوربین ۴۸ مگاپیکسلی و تراشه A19',
      excerpt: 'اپل از نسل جدید آیفون با تغییرات اساسی در طراحی و بهبود چشمگیر دوربین رونمایی کرد.',
      content: `<p>اپل در رویدادی ویژه از نسل جدید آیفون ۱۷ پرو رونمایی کرد. این گوشی با تراشه A19، دوربین اصلی ۴۸ مگاپیکسلی و طراحی کاملاً جدید عرضه می‌شود.</p><h2>ویژگی‌های کلیدی</h2><p>آیفون ۱۷ پرو دارای نمایشگر ۶.۳ اینچی OLED با نرخ نوسازی ۱۲۰ هرتز، تراشه A19 با ۸ هسته پردازشی و ۱۶ هسته GPU است. باتری ۴۵۰۰ میلی‌آمپری آن تا ۳۰ ساعت پخش ویدیو را پشتیبانی می‌کند.</p><h2>قیمت</h2><p>قیمت آیفون ۱۷ پرو از ۹۹۹ دلار آغاز می‌شود و پیش‌خرید از هفته آینده آغاز خواهد شد.</p>`,
      coverImage: 'https://images.unsplash.com/photo-1592286927505-1def25115558?w=1200',
      category: categoryTech,
      isMainHeadline: true,
      isHomepage: true,
      isBreaking: true,
      isFeatured: true,
      readingTime: 3,
    },
    {
      title: 'GTA VI در پاییز ۲۰۲۵ منتشر می‌شود - راک‌استار تاریخ رسمی را اعلام کرد',
      excerpt: 'راک‌استار گیمز سرانجام تاریخ انتشار رسمی GTA VI را اعلام کرد.',
      content: `<p>راک‌استار گیمز طی نشست خبری از تاریخ انتشار رسمی GTA VI خبر داد. این بازی در پاییز ۲۰۲۵ برای PS5 و Xbox Series X عرضه خواهد شد.</p><h2>جزئیات</h2><p>GTA VI در شهر خیالی وایس‌سیتی روایت می‌شود. بودجه توسعه بیش از ۲ میلیارد دلار بوده است.</p>`,
      coverImage: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200',
      category: categoryGaming,
      isHomepage: true,
      isFeatured: true,
      readingTime: 2,
    },
    {
      title: 'کشف سیاره‌ای شبیه زمین در فاصله ۴۰ سال نوری',
      excerpt: 'تلسکوپ جیمز وب موفق به کشف سیاره‌ای شد که شرایط آن برای حیات مناسب است.',
      content: `<p>محققان ناسا با استفاده از تلسکوپ جیمز وب سیاره‌ای خارج از منظومه شمسی کشف کردند.</p><h2>ویژگی‌ها</h2><p>این سیاره ۱.۵ برابر بزرگتر از زمین است و دمای سطح آن بین ۵ تا ۲۵ درجه سانتی‌گراد است.</p>`,
      coverImage: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1200',
      category: categoryWorld,
      isHomepage: true,
      isFeatured: true,
      readingTime: 4,
    },
  ]

  // حذف اخبار قبلی
  await db.article.deleteMany({})
  console.log('✓ Old articles deleted')

  for (const article of articles) {
    const created = await db.article.create({
      data: {
        title: article.title,
        slug: slugify(article.title) + '-' + Math.random().toString(36).substring(2, 6),
        excerpt: article.excerpt,
        content: article.content,
        coverImage: article.coverImage,
        categoryId: article.category.id,
        authorId: superAdmin.id,
        status: 'PUBLISHED',
        isFeatured: article.isFeatured,
        isBreaking: article.isBreaking || false,
        isHomepage: article.isHomepage,
        isMainHeadline: article.isMainHeadline || false,
        readingTime: article.readingTime,
        viewCount: 0,
        likeCount: 0,
        commentCount: 0,
        publishedAt: new Date(),
      },
    })
    console.log(`✓ Created: ${created.title}`)
  }

  console.log('✅ Done!')
  await db.$disconnect()
}

addTestArticles().catch(e => {
  console.error(e)
  process.exit(1)
})
