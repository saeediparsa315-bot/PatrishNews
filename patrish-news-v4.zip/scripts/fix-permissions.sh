#!/bin/bash
#
# اسکریپت fix permission برای هاست
#
# استفاده:
#   chmod +x scripts/fix-permissions.sh
#   ./scripts/fix-permissions.sh
#
# یا اگه نیاز به sudo داره:
#   sudo ./scripts/fix-permissions.sh
#

set -e

echo "=== fix permissions پاتریش نیوز ==="
echo ""

CWD="$(pwd)"
echo "مسیر فعلی: $CWD"
echo ""

# ۱. ساخت پوشه‌ها اگه وجود ندارن
echo "۱. ساخت پوشه‌های db و uploads..."
mkdir -p "$CWD/db"
mkdir -p "$CWD/uploads"
echo "   ✅ ساخته شدند"
echo ""

# ۲. chmod پوشه‌ها
echo "۲. تنظیم permission پوشه‌ها..."
chmod -R 777 "$CWD/db" 2>/dev/null || {
  echo "   ⚠️ نیاز به sudo:"
  sudo chmod -R 777 "$CWD/db"
}
chmod -R 777 "$CWD/uploads" 2>/dev/null || {
  echo "   ⚠️ نیاز به sudo:"
  sudo chmod -R 777 "$CWD/uploads"
}
echo "   ✅ permission تنظیم شد"
echo ""

# ۳. chown به user فعلی
echo "۳. تنظیم owner..."
CURRENT_USER="$(whoami)"
chown -R "$CURRENT_USER:$CURRENT_USER" "$CWD/db" 2>/dev/null || {
  echo "   ⚠️ نیاز به sudo:"
  sudo chown -R "$CURRENT_USER:$CURRENT_USER" "$CWD/db"
}
chown -R "$CURRENT_USER:$CURRENT_USER" "$CWD/uploads" 2>/dev/null || {
  echo "   ⚠️ نیاز به sudo:"
  sudo chown -R "$CURRENT_USER:$CURRENT_USER" "$CWD/uploads"
}
echo "   ✅ owner تنظیم شد به $CURRENT_USER"
echo ""

# ۴. chmod فایل دیتابیس اگه وجود داره
if [ -f "$CWD/db/production.db" ]; then
  echo "۴. تنظیم permission فایل دیتابیس..."
  chmod 666 "$CWD/db/production.db" 2>/dev/null || {
    echo "   ⚠️ نیاز به sudo:"
    sudo chmod 666 "$CWD/db/production.db"
  }
  chown "$CURRENT_USER:$CURRENT_USER" "$CWD/db/production.db" 2>/dev/null || {
    sudo chown "$CURRENT_USER:$CURRENT_USER" "$CWD/db/production.db"
  }
  echo "   ✅ permission فایل دیتابیس تنظیم شد"
  echo ""
fi

# ۵. نمایش وضعیت نهایی
echo "=== وضعیت نهایی ==="
ls -la "$CWD/db/" 2>/dev/null || echo "پوشه db موجود نیست"
ls -la "$CWD/uploads/" 2>/dev/null || echo "پوشه uploads موجود نیست"
echo ""

echo "=== تست قابل نوشتن بودن ==="
if touch "$CWD/db/.test_write" 2>/dev/null; then
  rm "$CWD/db/.test_write"
  echo "✅ پوشه db قابل نوشتن است"
else
  echo "❌ پوشه db قابل نوشتن نیست!"
  echo "   اجرا کنید: sudo chmod -R 777 $CWD/db"
  exit 1
fi

if touch "$CWD/uploads/.test_write" 2>/dev/null; then
  rm "$CWD/uploads/.test_write"
  echo "✅ پوشه uploads قابل نوشتن است"
else
  echo "❌ پوشه uploads قابل نوشتن نیست!"
  echo "   اجرا کنید: sudo chmod -R 777 $CWD/uploads"
  exit 1
fi

echo ""
echo "=== تمام شد! ==="
echo "حالا می‌تونی setup رو اجرا کنی:"
echo "  node scripts/setup.js"
echo ""
echo "و بعد build و run:"
echo "  npm run build"
echo "  NODE_ENV=production npm start"
