import { db } from '@/lib/db'

async function removeNewsletterSetting() {
  console.log('🔄 Removing newsletter_enabled setting from DB...')
  try {
    await db.siteSetting.deleteMany({ where: { key: 'newsletter_enabled' } })
    console.log('✅ newsletter_enabled removed')
  } catch (e) {
    console.log('Note:', e)
  }

  // Verify
  const all = await db.siteSetting.findMany()
  console.log('\nCurrent settings:')
  for (const s of all) {
    console.log(`  ${s.key}: ${s.value}`)
  }

  await db.$disconnect()
}

removeNewsletterSetting().catch(e => {
  console.error(e)
  process.exit(1)
})
