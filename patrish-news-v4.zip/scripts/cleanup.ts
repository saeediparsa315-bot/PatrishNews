import { db } from '@/lib/db'

async function cleanup() {
  console.log('🧹 شروع پاک‌سازی...')

  // 1. حذف تمام اخبار موجود
  const articles = await db.article.findMany({ select: { id: true, title: true } })
  console.log(`📰 ${articles.length} خبر برای حذف یافت شد`)
  for (const article of articles) {
    await db.article.delete({ where: { id: article.id } })
  }
  console.log('✅ تمام اخبار حذف شدند')

  // 2. حذف تمام کامنت‌ها
  const comments = await db.comment.count()
  if (comments > 0) {
    await db.comment.deleteMany()
    console.log(`✅ ${comments} نظر حذف شد`)
  }

  // 3. حذف تمام لایک‌ها
  const likes = await db.like.count()
  if (likes > 0) {
    await db.like.deleteMany()
    console.log(`✅ ${likes} لایک حذف شد`)
  }

  // 4. حذف تمام بوک‌مارک‌ها
  const bookmarks = await db.bookmark.count()
  if (bookmarks > 0) {
    await db.bookmark.deleteMany()
    console.log(`✅ ${bookmarks} بوک‌مارک حذف شد`)
  }

  // 5. حذف تمام مشترکین خبرنامه
  const subs = await db.newsletterSub.count()
  if (subs > 0) {
    await db.newsletterSub.deleteMany()
    console.log(`✅ ${subs} مشترک خبرنامه حذف شد`)
  }

  // 6. ریست آمار کاربران (به‌جز سوپر ادمین)
  const users = await db.user.findMany({ where: { role: { not: 'SUPER_ADMIN' } } })
  if (users.length > 0) {
    console.log(`👥 ${users.length} کاربر عادی برای حذف یافت شد`)
    for (const user of users) {
      await db.user.delete({ where: { id: user.id } })
    }
    console.log('✅ کاربران عادی حذف شدند')
  }

  // 7. حذف session های قدیمی
  await db.session.deleteMany()
  console.log('✅ نشست‌ها پاک‌سازی شدند')

  // 8. حذف audit log های قدیمی
  await db.auditLog.deleteMany()
  console.log('✅ لاگ‌ها پاک‌سازی شدند')

  // گزارش نهایی
  const finalCounts = {
    articles: await db.article.count(),
    users: await db.user.count(),
    comments: await db.comment.count(),
    likes: await db.like.count(),
    bookmarks: await db.bookmark.count(),
    newsletterSubs: await db.newsletterSub.count(),
  }
  console.log('\n📊 وضعیت نهایی:')
  console.log(JSON.stringify(finalCounts, null, 2))

  console.log('\n✅ پاک‌سازی کامل شد')
  console.log('⚠️ حالا هیچ خبری در سایت نیست - سوپر ادمین باید خبر جدید بسازد')
  console.log('⚠️ ورود: admin@news24.ir / admin123')

  await db.$disconnect()
}

cleanup().catch(e => {
  console.error(e)
  process.exit(1)
})
