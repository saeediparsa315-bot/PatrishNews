import { db } from '@/lib/db'
import { slugify } from '@/lib/persian'

async function addPoliticsCategory() {
  console.log('📝 Adding "سیاسی" category...')

  // بررسی اینکه آیا دسته وجود دارد
  const existing = await db.category.findUnique({ where: { slug: 'politics' } })
  if (existing) {
    console.log('✓ Category already exists, updating...')
    await db.category.update({
      where: { id: existing.id },
      data: {
        name: 'سیاسی',
        description: 'اخبار سیاسی داخلی و خارجی',
        color: '#DC2626', // قرمز تیره
        icon: 'Landmark', // آیکون ساختمان پارلمان
        order: 7,
        isActive: true,
      },
    })
  } else {
    await db.category.create({
      data: {
        name: 'سیاسی',
        slug: 'politics',
        description: 'اخبار سیاسی داخلی و خارجی',
        color: '#DC2626',
        icon: 'Landmark',
        order: 7,
        isActive: true,
      },
    })
  }

  console.log('✅ Category "سیاسی" added/updated successfully')

  // لیست همه دسته‌ها
  const all = await db.category.findMany({ orderBy: { order: 'asc' } })
  console.log('\nAll categories:')
  all.forEach(c => {
    console.log(`  ${c.order}. ${c.name} (${c.slug}) - color: ${c.color}, icon: ${c.icon}`)
  })

  await db.$disconnect()
}

addPoliticsCategory().catch(e => {
  console.error(e)
  process.exit(1)
})
